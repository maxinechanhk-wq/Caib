# CAIB 2 Quiz App — GitHub Pages version

Files:
- index.html
- style.css
- app.js
- question-bank.js

How to publish:
1. Create a new GitHub repository.
2. Upload all files from this folder to the repository root.
3. Go to Settings → Pages.
4. Under “Build and deployment”, choose “Deploy from a branch”.
5. Select branch: main, folder: /root.
6. Open the Pages URL on iPhone Safari.

Features:
- Random 50 questions
- Chapter filter or all chapters
- MCQ with instant correct/incorrect feedback
- Fill in the blanks with typed answer checking
- Flashcards
- Score tracking
