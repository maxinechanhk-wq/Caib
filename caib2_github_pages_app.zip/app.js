
(function(){
  const DATA = window.CAIB2_QUESTION_BANK || {mcq:[], fill:[], flashcards:[]};

  const modeEl = document.getElementById('mode');
  const chapterEl = document.getElementById('chapter');
  const startBtn = document.getElementById('startBtn');
  const nextBtn = document.getElementById('nextBtn');
  const main = document.getElementById('main');
  const stats = document.getElementById('stats');
  const bar = document.getElementById('bar');

  let quiz = [];
  let index = 0;
  let score = 0;
  let answered = false;
  let flashFlipped = false;

  function esc(value){
    return String(value ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }

  function chapters(){
    const seen = new Set();
    ['mcq','fill','flashcards'].forEach(type => {
      (DATA[type] || []).forEach(item => {
        if (item.chapter) seen.add(item.chapter);
      });
    });
    return Array.from(seen).sort((a,b) => {
      const an = Number((a.match(/Chapter\s+(\d+)/)||[])[1] || 99);
      const bn = Number((b.match(/Chapter\s+(\d+)/)||[])[1] || 99);
      return an - bn || a.localeCompare(b);
    });
  }

  function init(){
    chapterEl.innerHTML = '<option value="ALL">Random / All Chapters</option>';
    chapters().forEach(ch => {
      const opt = document.createElement('option');
      opt.value = ch;
      opt.textContent = ch;
      chapterEl.appendChild(opt);
    });
    reset();
  }

  function reset(){
    quiz = [];
    index = 0;
    score = 0;
    answered = false;
    updateStats();
    main.innerHTML = '<p class="small">Choose a mode/chapter and press Start.</p>';
  }

  function getPool(){
    const mode = modeEl.value;
    const selectedChapter = chapterEl.value;
    let pool = (DATA[mode] || []).slice();
    if (selectedChapter !== 'ALL') {
      pool = pool.filter(item => item.chapter === selectedChapter);
    }
    return pool;
  }

  function shuffle(arr){
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  function start(){
    quiz = shuffle(getPool()).slice(0, 50);
    index = 0;
    score = 0;
    answered = false;

    if (!quiz.length) {
      main.innerHTML = '<b>No questions in this selection.</b>';
      updateStats();
      return;
    }
    render();
  }

  function updateStats(){
    const total = quiz.length;
    if (!total) {
      stats.textContent = 'Not started';
      bar.style.width = '0%';
      return;
    }
    const done = answered ? index + 1 : index;
    stats.textContent = `Question ${Math.min(index + 1, total)}/${total} | Score: ${score}/${done}`;
    bar.style.width = `${Math.round((done / total) * 100)}%`;
  }

  function render(){
    answered = false;
    flashFlipped = false;
    updateStats();
    const item = quiz[index];

    if (modeEl.value === 'mcq') renderMCQ(item);
    else if (modeEl.value === 'fill') renderFill(item);
    else renderFlash(item);
  }

  function renderMCQ(q){
    const opts = q.options || {};
    let html = `<span class="badge">${esc(q.chapter)}</span><div class="qtitle">${esc(q.question)}</div>`;

    Object.keys(opts).forEach(key => {
      html += `<button class="option" data-key="${esc(key)}"><b>${esc(key)}.</b> ${esc(opts[key])}</button>`;
    });
    html += '<div class="feedback" id="feedback"></div>';
    main.innerHTML = html;

    const buttons = Array.from(main.querySelectorAll('.option'));
    buttons.forEach(button => {
      button.addEventListener('click', () => {
        if (answered) return;
        answered = true;

        const chosen = button.dataset.key.toLowerCase();
        const correct = String(q.answer || '').toLowerCase();
        const correctText = opts[correct] || '';

        buttons.forEach(btn => {
          const key = btn.dataset.key.toLowerCase();
          if (key === correct) btn.classList.add('correct');
          if (key === chosen && chosen !== correct) btn.classList.add('wrong');
          btn.disabled = true;
        });

        if (chosen === correct) score++;

        const fb = document.getElementById('feedback');
        fb.style.display = 'block';
        fb.textContent =
          `${chosen === correct ? 'Correct' : 'Incorrect'}\n` +
          `Correct answer: ${correct}. ${correctText}\n\n` +
          `Explanation: ${q.explanation || ''}`;
        updateStats();
      });
    });
  }

  function renderFill(q){
    main.innerHTML =
      `<span class="badge">${esc(q.chapter)}</span>` +
      `<div class="qtitle">${esc(q.question)}</div>` +
      `<input class="fillInput" id="fillInput" type="text" placeholder="Type your answer">` +
      `<button id="checkBtn">Check</button>` +
      `<div class="feedback" id="feedback"></div>`;

    document.getElementById('checkBtn').addEventListener('click', () => {
      if (answered) return;
      answered = true;

      const typed = document.getElementById('fillInput').value.trim().toLowerCase();
      const answer = String(q.answer || '').trim().toLowerCase();

      if (typed === answer) score++;

      const fb = document.getElementById('feedback');
      fb.style.display = 'block';
      fb.textContent =
        `${typed === answer ? 'Correct' : 'Incorrect'}\n` +
        `Correct answer: ${q.answer || ''}\n\n` +
        `Explanation: ${q.explanation || ''}`;
      updateStats();
    });
  }

  function renderFlash(q){
    main.innerHTML =
      `<span class="badge">${esc(q.chapter)}</span>` +
      `<div class="flash" id="flashBox">${esc(q.front)}</div>` +
      `<div class="row"><button id="flipBtn">Flip</button></div>`;

    document.getElementById('flipBtn').addEventListener('click', () => {
      flashFlipped = !flashFlipped;
      document.getElementById('flashBox').textContent = flashFlipped ? (q.back || '') : (q.front || '');
    });
  }

  function next(){
    if (!quiz.length) return;

    if (index < quiz.length - 1) {
      index++;
      render();
      return;
    }

    main.innerHTML =
      `<h2>Finished</h2>` +
      `<p>Your score: <b>${score}/${quiz.length}</b></p>` +
      `<p class="small">Press Start to draw another random set.</p>`;
    stats.textContent = `Finished | Score: ${score}/${quiz.length}`;
    bar.style.width = '100%';
  }

  startBtn.addEventListener('click', start);
  nextBtn.addEventListener('click', next);
  modeEl.addEventListener('change', reset);
  chapterEl.addEventListener('change', reset);

  init();
})();
