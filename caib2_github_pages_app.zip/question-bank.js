window.CAIB2_QUESTION_BANK = {
  "mcq": [
    {
      "id": 1,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "When insuring building, building, stock and equipment on an “all property-blanket” basis",
      "options": {
        "a": "All property owned by the insured is covered by a single limit of insurance",
        "b": "Coverage is usually subject to a minimum 90% Co-insurance requirement",
        "c": "Coverage limits can be extended to include property at more than one location",
        "d": "All of the above",
        "e": "None of the above"
      },
      "answer": "a",
      "answer_text": "All property owned by the insured is covered by a single limit of insurance",
      "explanation": "A: All property owned by the insured is covered by a single limit of insurance"
    },
    {
      "id": 2,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Your client, who operates the business out of leased premises, is undertaking major renovations which include new flooring, wall panelling and light fixtures. The total cost of the renovations which include new flooring, wall panelling and light fixtures. The total cost of the renovations is $25,000. You advise her that these values",
      "options": {
        "a": "Are insured under the landlord’s building insurance",
        "b": "Must be added to her own policy as building coverage",
        "c": "Must be added to equipment insured under her own policy",
        "d": "Cannot be insured because she does not own the building",
        "e": "None of the above"
      },
      "answer": "c",
      "answer_text": "Must be added to equipment insured under her own policy",
      "explanation": "C: Must be added to equipment insured under her own policy"
    },
    {
      "id": 3,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following is not used in determining an amount of insurance for property?",
      "options": {
        "a": "Book Value",
        "b": "True Value to the Owner",
        "c": "Income Approach",
        "d": "Market Value / Direct Sales Approach",
        "e": "Broad Evidence Rule"
      },
      "answer": "a",
      "answer_text": "Book Value",
      "explanation": "A: Book Value"
    },
    {
      "id": 4,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Insurers can use both Reinsurance and Subscription policies to limit their exposure on risks. Select the answer which best describes Reinsurance.",
      "options": {
        "a": "The insurer cedes part of the risk it has assumed to one or more insurers",
        "b": "Each agreement is negotiated separately with the participating insurers",
        "c": "The policy is controlled by the primary insurer and all claims are paid by it",
        "d": "A and b",
        "e": "A and c"
      },
      "answer": "e",
      "answer_text": "A and c",
      "explanation": "E: A and c"
    },
    {
      "id": 5,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "The amount of a claim payment made to the insured is",
      "options": {
        "a": "The least of the actual cash value, the interest of the insured, and the replacement cost",
        "b": "Not limited to the amount of insurance specified",
        "c": "The actual cash value, the interest of the insured, and the amount of insurance specified, whichever is the least",
        "d": "Limited to the actual cash value only",
        "e": "Always based on the replacement value"
      },
      "answer": "c",
      "answer_text": "The actual cash value, the interest of the insured, and the amount of insurance specified, whichever is the least",
      "explanation": "C: The actual cash value, the interest of the insured, and the amount of insurance specified, whichever is the least"
    },
    {
      "id": 6,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "The co-insurance requirement is waived when",
      "options": {
        "a": "The loss is less than $5000",
        "b": "The loss is more than $5000 but less than 2% of the amount of insurance",
        "c": "The loss is less than the Actual Cash Value",
        "d": "The loss is less than 2% of the amount of insurance and less than $5000",
        "e": "None of the above"
      },
      "answer": "d",
      "answer_text": "The loss is less than 2% of the amount of insurance and less than $5000",
      "explanation": "D: The loss is less than 2% of the amount of insurance and less than $5000"
    },
    {
      "id": 7,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following does not apply to the stated amount co-insurance clause?",
      "options": {
        "a": "The stated amount co-insurance clause replaces the standard co-insurance clause normally contained in the policy",
        "b": "The stated amount co-insurance clause does not require the insured to insure values to 100%",
        "c": "The insured files a statement of values representing 100% of the value of the property insured",
        "d": "Values are verified by appraisal or other means acceptable to the insurer",
        "e": "The insured must maintain those values throughout the policy term"
      },
      "answer": "b",
      "answer_text": "The stated amount co-insurance clause does not require the insured to insure values to 100%",
      "explanation": "B, only the standard co-insurance clause permits the amount of insurance to be less than 100% of the value of the property insured"
    },
    {
      "id": 8,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "The “property protection systems” clause requires the insured to:",
      "options": {
        "a": "Notify the insurer immediately when becoming aware of any interruption, flaw or defect in property protection systems",
        "b": "Notify the insurer as soon as possible when becoming aware of any interruption, flaw or defect in property protection systems",
        "c": "Notify the insurer within 30 days when becoming aware of any interruption, flaw or defect in property protection systems",
        "d": "Notify the insurer within 15 days when becoming aware of any interruption, flaw or defect in property protection systems",
        "e": "Notify the insurer immediately after repairs have been made"
      },
      "answer": "a",
      "answer_text": "Notify the insurer immediately when becoming aware of any interruption, flaw or defect in property protection systems",
      "explanation": "A: Notify the insurer immediately when becoming aware of any interruption, flaw or defect in property protection systems"
    },
    {
      "id": 9,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "The locked vehicle warranty:",
      "options": {
        "a": "Requires that the vehicle containing the property insured by equipped with a fully enclosed metal body or compartment of the vehicle",
        "b": "Requires that the doors and windows of the vehicle must be securely locked when the vehicle is unattended, only when away from the insured’s premises",
        "c": "Requires that the doors and windows of the vehicle must be securely locked when be securely locked when the vehicle is unattended",
        "d": "There must be visible signs of force used to gain entry into the body or compartment of the vehicle",
        "e": "A, c and d"
      },
      "answer": "e",
      "answer_text": "A, c and d",
      "explanation": "E: A, c and d"
    },
    {
      "id": 10,
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "The Statutory Condition One, Misrepresentation identifies breaches of good faith. A breach of good faith is deemed to have occurred when:",
      "options": {
        "a": "The quality of the risk is superior to what has been described on the application",
        "b": "The insured fails to disclose previous claims",
        "c": "The insured does not disclose facts which the insurer has waived the requirement for information",
        "d": "The insured does not disclose facts which are known to the insurer",
        "e": "The insured does disclose facts which need not be disclosed by reason of a policy condition"
      },
      "answer": "b",
      "answer_text": "The insured fails to disclose previous claims",
      "explanation": "B: The insured fails to disclose previous claims"
    },
    {
      "id": 11,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes why brokers are referred to as the insurer’s first line underwriter?",
      "options": {
        "a": "They have binding authority on all commercial risks",
        "b": "They have the first opportunity to qualify a prospect for insurance",
        "c": "They select risks that are most profitable to the insurer",
        "d": "They carry out the inspections of risks",
        "e": "They have the first contact with the prospect"
      },
      "answer": "b",
      "answer_text": "They have the first opportunity to qualify a prospect for insurance",
      "explanation": "B: They have the first opportunity to qualify a prospect for insurance"
    },
    {
      "id": 12,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "A submission is",
      "options": {
        "a": "An application for insurance",
        "b": "Written information provided to the underwriter",
        "c": "Verbal information provided to the underwriter",
        "d": "A proposal for insurance which has been presented to the underwriter for consideration",
        "e": "None of the above"
      },
      "answer": "d",
      "answer_text": "A proposal for insurance which has been presented to the underwriter for consideration",
      "explanation": "D: A proposal for insurance which has been presented to the underwriter for consideration"
    },
    {
      "id": 13,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "What is the purpose of conducting a fact find or survey?",
      "options": {
        "a": "To reduce errors and omissions claims",
        "b": "To assist in the identification of loss exposures",
        "c": "To eliminate the purchase of coverages not needed",
        "d": "A and c",
        "e": "B and c"
      },
      "answer": "e",
      "answer_text": "B and c",
      "explanation": "E: B and c"
    },
    {
      "id": 14,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Fire resistive means",
      "options": {
        "a": "A building has met minimum standards in terms of hours it can withstand a controlled test fire",
        "b": "A building which is constructed of non-combustible materials",
        "c": "A building which is constructed of concrete block with the roof, floors and interior framing constructed of wood or other combustible materials",
        "d": "A building which is constructed of heavy timber",
        "e": "None of the above"
      },
      "answer": "a",
      "answer_text": "A building has met minimum standards in terms of hours it can withstand a controlled test fire",
      "explanation": "A: A building has met minimum standards in terms of hours it can withstand a controlled test fire"
    },
    {
      "id": 15,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "When a building is more than 25 years old additional information is normally requested by the underwriter. Which of the following items is not part of this information?",
      "options": {
        "a": "Over-current protection, such as circuit breakers or fuses",
        "b": "The roof",
        "c": "The plumbing and heating",
        "d": "The detachment",
        "e": "The wiring"
      },
      "answer": "d",
      "answer_text": "The detachment",
      "explanation": "D: The detachment"
    },
    {
      "id": 16,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "The primary function of an underwriter is",
      "options": {
        "a": "To classify risks according to their probability for loss as a class",
        "b": "To determine the rate or premium to be charged",
        "c": "To select those risks most likely to suffer a loss",
        "d": "To provide policyholders’ service"
      },
      "answer": "c",
      "answer_text": "To select those risks most likely to suffer a loss",
      "explanation": "C: To select those risks most likely to suffer a loss"
    },
    {
      "id": 17,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "An underwriter must assess the hazards of a risk which can increase the chance of losses. In addition to the physical hazards, the existence of potential moral hazards is also determined. Which of the following conditions is not considered a moral hazard?",
      "options": {
        "a": "The financial condition of the insured",
        "b": "The housekeeping",
        "c": "The associates of the insured",
        "d": "All of the above",
        "e": "None of the above"
      },
      "answer": "b",
      "answer_text": "The housekeeping",
      "explanation": "B: The housekeeping"
    },
    {
      "id": 18,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Physical hazards are:",
      "options": {
        "a": "Subjective characteristics of the applicant that may cause a peril to occur",
        "b": "Characteristics of the risk itself",
        "c": "Characteristics of the environment in which the risk is located",
        "d": "Conditions relating to the use of tangible property which may cause a peril to occur",
        "e": "All of the above"
      },
      "answer": "d",
      "answer_text": "Conditions relating to the use of tangible property which may cause a peril to occur",
      "explanation": "D: Conditions relating to the use of tangible property which may cause a peril to occur"
    },
    {
      "id": 19,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Underwriters may use external sources of information to supplement the information provided on an application. Which of the following is not an external source of information?",
      "options": {
        "a": "The broker’s production records",
        "b": "Financial rating services",
        "c": "Consumer investigation reports",
        "d": "Government records",
        "e": "The broker"
      },
      "answer": "a",
      "answer_text": "The broker’s production records",
      "explanation": "A: The broker’s production records"
    },
    {
      "id": 20,
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "The purpose of an inspection report is",
      "options": {
        "a": "To provide data on the physical characteristics of the risk",
        "b": "To provide an indication of the character of the applicant or insured",
        "c": "To provide the insurer with a list of mandatory recommendations",
        "d": "To provide the insurer with a list of suggested recommendations",
        "e": "All of the above"
      },
      "answer": "e",
      "answer_text": "All of the above",
      "explanation": "E: All of the above"
    },
    {
      "id": 21,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "One of the statutory requirements pertaining to contracts of insurance is that insurers state the policy period on the declarations page. The insurance acts of the common law provinces state that the coverage commences at a specific time on the effective date of the policy. Select the effective time.",
      "options": {
        "a": "12:01 am standard time at the address of the broker",
        "b": "12:01 am standard time at the address of the named insured as stated on the declarations page",
        "c": "12:01 pm standard time at the address of the location insured",
        "d": "12:01 am standard time at the address of the insurer’s head office",
        "e": "12:01 pm standard time at the address of the named insured as stated on the declaration page"
      },
      "answer": "b",
      "answer_text": "12:01 am standard time at the address of the named insured as stated on the declarations page",
      "explanation": "B: 12:01 am standard time at the address of the named insured as stated on the declarations page"
    },
    {
      "id": 22,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "The removal clause is one of the extensions of coverage provided in the fire policy of the following provisions which one is not part of the removal clause:",
      "options": {
        "a": "The insurer extends coverage for 30 days when property is at a location not indicated on the declarations page, and which is a newly acquired location of the insured",
        "b": "The insurer extends coverage when property is at a location not indicated on teh declarations page and which was necessarily removed to prevent loss",
        "c": "The insurer extends coverage at an unnamed location for a maximum of 7 days or until expiry of the policy, whichever is the least",
        "d": "In the event of a loss at an unnamed location the amount of payment is restricted to the amount of insurance remaining after the payment of any losses at the location insured",
        "e": "None of the above"
      },
      "answer": "a",
      "answer_text": "The insurer extends coverage for 30 days when property is at a location not indicated on the declarations page, and which is a newly acquired location of the insured",
      "explanation": "A, Coverage is not automatically extended to newly acquired location of the Insured. This clause will only respond when property was necessarily removed to protect insured property from loss or further loss."
    },
    {
      "id": 23,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "The peril of explosion in the fire and extended coverage form excludes explosions due to:",
      "options": {
        "a": "natural , coal or manufactured gas",
        "b": "Pressure vessels with a maximum internal working pressure of no more than 15 pounds per square inch",
        "c": "Pressure vessels with a maximum internal working pressure in excess of 15 pounds per square inch",
        "d": "Damage to insured stock or equipment that is caused by an explosion occurring during pressure testing",
        "e": "All of the above"
      },
      "answer": "c",
      "answer_text": "Pressure vessels with a maximum internal working pressure in excess of 15 pounds per square inch",
      "explanation": "C: Pressure vessels with a maximum internal working pressure in excess of 15 pounds per square inch"
    },
    {
      "id": 24,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Fire and extended coverage insures loss or damage caused by riot, vandalism and malicious acts. Select the conditions that constitute a riot",
      "options": {
        "a": "There was clear and present danger or, or which would result in damage to property or injury to persons",
        "b": "There was a group of no less than two persons involved causing injury or damage",
        "c": "There was an act or acts of violence or threatened violence",
        "d": "There were at least three or more persons involved, even though only one may have caused damage or injury",
        "e": "A, c & d"
      },
      "answer": "e",
      "answer_text": "A, c & d",
      "explanation": "E: A, c & d"
    },
    {
      "id": 25,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "The broad form policy",
      "options": {
        "a": "Is the most extensive standard coverage from available",
        "b": "Insures against all risks except those that are specifically excluded",
        "c": "Excludes all losses that are partially or totally in the insured’s control",
        "d": "Includes losses directly caused by a named peril",
        "e": "All of the above"
      },
      "answer": "e",
      "answer_text": "All of the above",
      "explanation": "E: All of the above"
    },
    {
      "id": 26,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Inherent vice is considered to be",
      "options": {
        "a": "A criminal act perpetrated by the insured or their employees",
        "b": "Claiming for multiple damages under a single claim",
        "c": "The same as moral hazard",
        "d": "Something within a commodity or other kind of property that causes it to spoil over time",
        "e": "Poor or negligent management"
      },
      "answer": "d",
      "answer_text": "Something within a commodity or other kind of property that causes it to spoil over time",
      "explanation": "D, inherent vice is something which causes the spoilage of perishable goods."
    },
    {
      "id": 27,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Loss due to delay or loss of market is not covered because",
      "options": {
        "a": "It is an uninsurable risk",
        "b": "It is a trade risk",
        "c": "It is directly under the control of the insured",
        "d": "It is cumulative damage, and this policy covers single occurrence damage only",
        "e": "It is an indirect loss"
      },
      "answer": "e",
      "answer_text": "It is an indirect loss",
      "explanation": "E, The Broad Form Policy covers direct loss only."
    },
    {
      "id": 28,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following properties are not excluded in the broad form?",
      "options": {
        "a": "Lottery tickets, tickets, or token for public transit",
        "b": "Unlicensed automobiles used on the insured’s premises",
        "c": "Property in the custody of a sales representative outside the insured’s premises",
        "d": "Boats and watercraft, not for sale",
        "e": "Property on loan or on rental or sold under a conditional sale, installment payment or other deferred payment plan"
      },
      "answer": "b",
      "answer_text": "Unlicensed automobiles used on the insured’s premises",
      "explanation": "B, Unlicensed vehicles that are used exclusively on the premises are insured."
    },
    {
      "id": 29,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following losses is insured under the broad form policy?",
      "options": {
        "a": "Damage to insured’s building caused by the explosion of a steam boiler",
        "b": "Damage to equipment caused by the rupture of a hot water heater with an internal diameter of 20 inches which is used for production purposes",
        "c": "Bursting of a pressure vessel with an internal pressure over 15 pounds per square inch",
        "d": "Damage caused by the explosion of a hot water heater with diameter of 24 inches and an internal pressure of over 25 pounds per square inch used for domestic purposes",
        "e": "Damage due to mechanical breakdown of machinery"
      },
      "answer": "d",
      "answer_text": "Damage caused by the explosion of a hot water heater with diameter of 24 inches and an internal pressure of over 25 pounds per square inch used for domestic purposes",
      "explanation": "D, Explosion of a hot water heater with an internal diameter of 24 inches or less is covered regardless of the internal pressure, provided the use is strictly for domestic purposes."
    },
    {
      "id": 30,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Extensions of coverage",
      "options": {
        "a": "Broaden the scope of coverage",
        "b": "Increase the insurer’s liability for loss",
        "c": "Are added to the policy at the request of the insured",
        "d": "Are not subject to a deductible",
        "e": "Are provided strictly at the discretion of the insurer"
      },
      "answer": "a",
      "answer_text": "Broaden the scope of coverage",
      "explanation": "A: Broaden the scope of coverage"
    },
    {
      "id": 31,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "An endorsement",
      "options": {
        "a": "Is a separate policy, issued to cover previously excluded items",
        "b": "Is approval in principle of the terms of the policy",
        "c": "Changes the terms or conditions of the policy",
        "d": "Adds additional coverage to what is already",
        "e": "Is a preliminary agreement by the insurer to pay the insured’s claim"
      },
      "answer": "a",
      "answer_text": "Is a separate policy, issued to cover previously excluded items",
      "explanation": "A: Is a separate policy, issued to cover previously excluded items"
    },
    {
      "id": 32,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "To get coverage for breakdown of computer hardware, the insured must",
      "options": {
        "a": "Have a valid maintenance contract for the equipment",
        "b": "There is no coverage for mechanical breakdown",
        "c": "Must get a boiler and machinery policy",
        "d": "Must have replacement cost endorsement",
        "e": "Must have an electronic data processing policy"
      },
      "answer": "a",
      "answer_text": "Have a valid maintenance contract for the equipment",
      "explanation": "A, Even with an Electronic Data Processing Policy, the Insurer can refuse to cover the loss if the Insured does not have a valid maintenance contract."
    },
    {
      "id": 33,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "The accounts receivable form does not cover",
      "options": {
        "a": "Collection expenses that arise due to the loss, for debt collection by collection agencies",
        "b": "Outstanding debts that cannot be collected as a result of the loss",
        "c": "Reasonable expenses incurred in re-establishing the accounts receivable records",
        "d": "Interest charges on money that the insured was forced to borrow due to an impaired cash flow",
        "e": "The actual costs of copying accounts receivable information from other source documents"
      },
      "answer": "e",
      "answer_text": "The actual costs of copying accounts receivable information from other source documents",
      "explanation": "E, The costs of copying the information from other sources are covered under the standard commercial property forms."
    },
    {
      "id": 34,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "The boiler and machinery policies cover losses arising out of",
      "options": {
        "a": "Explosions",
        "b": "Interruption of business operations",
        "c": "Accidents",
        "d": "Spoilage",
        "e": "All of the above"
      },
      "answer": "c",
      "answer_text": "Accidents",
      "explanation": "C, These policies cover loss due to accidents to objects. An accident is defined as the sudden and accidental breakdown of an object, with simultaneous physical damage."
    },
    {
      "id": 35,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Expediting expenses refer to",
      "options": {
        "a": "The cost of shipping goods via canada post",
        "b": "Debris removal",
        "c": "An extra payment by the insured to speed up approval of the policy",
        "d": "Payments to the insured to help them return to business as quickly as possible",
        "e": "Expenses incurred in recreating the accounts receivable records"
      },
      "answer": "d",
      "answer_text": "Payments to the insured to help them return to business as quickly as possible",
      "explanation": "D, Expediting Expenses are paid out under the Boiler and Machinery policies, to pay for reasonable expenses incurred in making the necessary temporary repairs, and expediting the permanent repairs."
    },
    {
      "id": 36,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Losses incurred to the stock, when the cooler breaks down in a dairy are covered if:",
      "options": {
        "a": "They are caused because of a lightning strike",
        "b": "The insured has a consequential loss assumption clause",
        "c": "The storage facility is off the premises",
        "d": "It was due to the neglectful act of an employee",
        "e": "It was due to the malicious act of an employee"
      },
      "answer": "b",
      "answer_text": "The insured has a consequential loss assumption clause",
      "explanation": "B, The Consequential Loss Assumption Clause covers loss to stock due to a change in temperature, which was a result of damage to the cooling apparatus."
    },
    {
      "id": 37,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which is not true in respect to the by-laws coverages?",
      "options": {
        "a": "The insured must also have the replacement cost endorsement to eliminate the effects of depreciation",
        "b": "The broker should be aware of the various by-laws affecting his or her clients",
        "c": "The basis of settlement is actual cash value",
        "d": "The insured should select an amount of insurance that is sufficient to bring the building up to the new standards",
        "e": "The insured is permitted to rebuild at a different location"
      },
      "answer": "e",
      "answer_text": "The insured is permitted to rebuild at a different location",
      "explanation": "E, There is a same site restriction, which would have to be waived if the by-laws no longer permitted the existing type of building to be erected on the site."
    },
    {
      "id": 38,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Should the stock of a sales representative be stolen out of his home",
      "options": {
        "a": "The loss is covered under the home owner’s policy",
        "b": "The loss is covered under the sales representative coverage",
        "c": "The loss is covered only if the home is listed as a location on the declarations page",
        "d": "The loss is covered under the installment sales contract floater",
        "e": "The loss is covered under the standard commercial property insurance policy"
      },
      "answer": "b",
      "answer_text": "The loss is covered under the sales representative coverage",
      "explanation": "B, The Sales Representative Coverage will pay for losses in the Sales Representative's home."
    },
    {
      "id": 39,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "The peak season endorsement covers which of the following",
      "options": {
        "a": "Peak periods where there are increases in stock",
        "b": "Regularly fluctuating stock amounts",
        "c": "Occasions when the insured informs the insurer of the increase in stock",
        "d": "A and b",
        "e": "All of the above"
      },
      "answer": "a",
      "answer_text": "Peak periods where there are increases in stock",
      "explanation": "A, This coverage is only for businesses that experience increases in stock on a few, well-defined occasions, which are detailed in the policy, so that the coverage is automatically in place on those dates."
    },
    {
      "id": 40,
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which is not true concerning the replacement cost endorse ment?",
      "options": {
        "a": "There is no replacement cost endorsement for stock",
        "b": "It is site specific",
        "c": "Delays in replacement may mean that the insured is disqualified from coverage",
        "d": "If like property cannot be obtained, the policy will pay for new property that is as similar as possible",
        "e": "Payments cannot be greater than what is actually spent in replacing the property, even if the value of the property is greater than the expenses"
      },
      "answer": "a",
      "answer_text": "There is no replacement cost endorsement for stock",
      "explanation": "A, There is a Replacement Cost Endorsement available for stock, although it is less common, and applies to selected items only."
    },
    {
      "id": 41,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Building?",
      "options": {
        "a": "3. War, Invasion, act of foreign enemy",
        "b": "owner/employees control it, the weakness is they can forget to",
        "c": "Excludes jewellery, fur, paintings, livestock, etc",
        "d": "Property is itemized",
        "e": "Equipment"
      },
      "answer": "e",
      "answer_text": "Equipment",
      "explanation": "E: Equipment"
    },
    {
      "id": 42,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Stock?",
      "options": {
        "a": "can be endorsed.",
        "b": "Inherent Vice - something within a commodity that causes demise over time",
        "c": "3 ways to insure commercial property",
        "d": "when income is produced from down buildings, net annual rent",
        "e": "Rental value"
      },
      "answer": "c",
      "answer_text": "3 ways to insure commercial property",
      "explanation": "C: 3 ways to insure commercial property"
    },
    {
      "id": 43,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3 ways to insure commercial property?",
      "options": {
        "a": "13. Difference between reinsurance and subscription",
        "b": "Identify coverages needed, help determine cvgs needed",
        "c": "definition differs from legal, there has to be marks of forcible entry or exit.",
        "d": "Scheduled - items specifically identified on policy",
        "e": "each insurer contracts with the insured for a specific limit of liability. If one"
      },
      "answer": "d",
      "answer_text": "Scheduled - items specifically identified on policy",
      "explanation": "D: Scheduled - items specifically identified on policy"
    },
    {
      "id": 44,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Scheduled?",
      "options": {
        "a": "Property is itemized",
        "b": "3. Rate-Making - factors that influence the premium are application info, internal and",
        "c": "items specifically identified on policy",
        "d": "Replacement value",
        "e": "Does not apply if property is insured by the owner unless he is obligated to insure it"
      },
      "answer": "c",
      "answer_text": "items specifically identified on policy",
      "explanation": "C: items specifically identified on policy"
    },
    {
      "id": 45,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Scheduled - items specifically identified on policy?",
      "options": {
        "a": "on standard policy, vacant/unoccupied is not covered after 30 days.",
        "b": "if repaired with due diligence and dispatch, the insured is entitled to claim all costs",
        "c": "loss does not apply to first $1000 of any loss and does not",
        "d": "POED - A single limit of insurance is stated on the policy",
        "e": "c) Damage to electrical devices caused by artificially generated electrical currants."
      },
      "answer": "d",
      "answer_text": "POED - A single limit of insurance is stated on the policy",
      "explanation": "D: POED - A single limit of insurance is stated on the policy"
    },
    {
      "id": 46,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes POED?",
      "options": {
        "a": "A single limit of insurance is stated on the policy",
        "b": "Reinsurance",
        "c": "Stock Burglary Rider - insures stock and equipment against actual/attempted burglary, robbery",
        "d": "if not, the insurer will reduce the payable amount.",
        "e": "p) Bylaws - no coverage for increased cost through enforcement of bylaw"
      },
      "answer": "a",
      "answer_text": "A single limit of insurance is stated on the policy",
      "explanation": "A: A single limit of insurance is stated on the policy"
    },
    {
      "id": 47,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes All property (Blanket)?",
      "options": {
        "a": "document issued by insurer that adds coverages.",
        "b": "b) Property at locations which to the knowledge of the insured are vacant/shut",
        "c": "protects the interests of business that sells goods",
        "d": "all property owned by the insured is covered by a single limit of insurance",
        "e": "Limit of Insurance Required/Premium Adjustement Provision"
      },
      "answer": "d",
      "answer_text": "all property owned by the insured is covered by a single limit of insurance",
      "explanation": "D: all property owned by the insured is covered by a single limit of insurance"
    },
    {
      "id": 48,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Stock?",
      "options": {
        "a": "designed to insured movable equipment owned by",
        "b": "Must make application for refund within 12 months of expiry of policy",
        "c": "Pre-employment - written application, security checks, investigation of personal finances,",
        "d": "It sets the parameters of coverage on stock to items that are usual to the insured’s business",
        "e": "Increase in cost of construction"
      },
      "answer": "d",
      "answer_text": "It sets the parameters of coverage on stock to items that are usual to the insured’s business",
      "explanation": "D: It sets the parameters of coverage on stock to items that are usual to the insured’s business"
    },
    {
      "id": 49,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Similar property belonging to others?",
      "options": {
        "a": "Excludes mechanical breakdown and centrifugal force",
        "b": "Ordinary Payroll - Limited Coverage - 90 or 180 day Option",
        "c": "2. Contractor’s Equipment Floater - designed to insured movable equipment owned by",
        "d": "When the insured is under obligation to keep insured or for which he is legally liable",
        "e": "3. War, Invasion, act of foreign enemy"
      },
      "answer": "d",
      "answer_text": "When the insured is under obligation to keep insured or for which he is legally liable",
      "explanation": "D: When the insured is under obligation to keep insured or for which he is legally liable"
    },
    {
      "id": 50,
      "source": "Notes docx",
      "chapter": "Chapter 5: Misc. Property Forms",
      "type": "mcq",
      "question": "Which of the following best describes Contractual obligations for the stock of suppliers?",
      "options": {
        "a": "Liable for loss to costumer’s property when ordinary care is breached",
        "b": "extends coverage to off premises use of tools. Has two forms",
        "c": "Exercise ordinary care as a bailee for hire",
        "d": "Rust/corrosion",
        "e": "if not, the insurer will reduce the payable amount."
      },
      "answer": "c",
      "answer_text": "Exercise ordinary care as a bailee for hire",
      "explanation": "C: Exercise ordinary care as a bailee for hire"
    },
    {
      "id": 51,
      "source": "Notes docx",
      "chapter": "Chapter 5: Misc. Property Forms",
      "type": "mcq",
      "question": "Which of the following best describes Exercise ordinary care as a bailee for hire?",
      "options": {
        "a": "leased/ borrowed / loaned equipment",
        "b": "All insurers share in premiums and losses",
        "c": "explosion of boilers",
        "d": "Subscription",
        "e": "financial statement is used. But it is important to"
      },
      "answer": "a",
      "answer_text": "leased/ borrowed / loaned equipment",
      "explanation": "A: leased/ borrowed / loaned equipment"
    },
    {
      "id": 52,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes leased/ borrowed / loaned equipment?",
      "options": {
        "a": "No bearing on the amount of payment made by the insurer",
        "b": "2. They don’t stand alone - they take form of an endorsement",
        "c": "Contractor’s tools and equipment",
        "d": "Items that are covered",
        "e": "Wear/tear/loss due to the designed operation"
      },
      "answer": "d",
      "answer_text": "Items that are covered",
      "explanation": "D: Items that are covered"
    },
    {
      "id": 53,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Items that are covered?",
      "options": {
        "a": "Loss of value of the undamaged portion of the building",
        "b": "Equipment",
        "c": "3. Personal Property of Officers and Employees - allows personal property to fit into the",
        "d": "document issued by insurer that adds coverages.",
        "e": "1. Risk Selection"
      },
      "answer": "b",
      "answer_text": "Equipment",
      "explanation": "B: Equipment"
    },
    {
      "id": 54,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Equipment?",
      "options": {
        "a": "Cash register used in insured’s business",
        "b": "9. Flood",
        "c": "Pre-employment - written application, security checks, investigation of personal finances,",
        "d": "owner controls it and do not send to a control center.",
        "e": "Impact losses only"
      },
      "answer": "a",
      "answer_text": "Cash register used in insured’s business",
      "explanation": "A: Cash register used in insured’s business"
    },
    {
      "id": 55,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Cash register used in insured’s business?",
      "options": {
        "a": "lack of habitual presence. Complete with contents but owner is absent.",
        "b": "limited to Canada and continental US",
        "c": "2. Forcible entry into protected enclosures",
        "d": "Portable wall dividers separating work areas in a sales office",
        "e": "1 year after expiry to make a claim."
      },
      "answer": "d",
      "answer_text": "Portable wall dividers separating work areas in a sales office",
      "explanation": "D: Portable wall dividers separating work areas in a sales office"
    },
    {
      "id": 56,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Building?",
      "options": {
        "a": "Two bundles of shingles stored in the insured’s basement that were left over after a roof was re-shingled",
        "b": "Loading - rate over and above the fire rate",
        "c": "Equipment",
        "d": "contents removed also",
        "e": "Identification - any employee who has special skills not easily replaced is not ordinary"
      },
      "answer": "a",
      "answer_text": "Two bundles of shingles stored in the insured’s basement that were left over after a roof was re-shingled",
      "explanation": "A: Two bundles of shingles stored in the insured’s basement that were left over after a roof was re-shingled"
    },
    {
      "id": 57,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Stock?",
      "options": {
        "a": "POED - A single limit of insurance is stated on the policy",
        "b": "if insured had similar policies before,",
        "c": "Plastic bags used by a business to package",
        "d": "will not ignite or burn when subjected to fire",
        "e": "Not provided while on locations leased or owned by insured"
      },
      "answer": "c",
      "answer_text": "Plastic bags used by a business to package",
      "explanation": "C: Plastic bags used by a business to package"
    },
    {
      "id": 58,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Plastic bags used by a business to package?",
      "options": {
        "a": "same as above, but no guard is dispatched.",
        "b": "methods used to secure access when business is closed.",
        "c": "Covers acceptance of money orders not honored upon presentation.",
        "d": "Customer’s funishings held on consignment sale bases by local furniture store",
        "e": "a central station ensures it is turned on at arranged times."
      },
      "answer": "d",
      "answer_text": "Customer’s funishings held on consignment sale bases by local furniture store",
      "explanation": "D: Customer’s funishings held on consignment sale bases by local furniture store"
    },
    {
      "id": 59,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Sales brochures?",
      "options": {
        "a": "a) Earthquake - loss caused by earthquake. Except for ensuing loss or damage which",
        "b": "Data Exclusion",
        "c": "3 ways of valuing property",
        "d": "Between the primary insurer and the reinsurer",
        "e": "Separate payments are provided from all companies to the clamant"
      },
      "answer": "c",
      "answer_text": "3 ways of valuing property",
      "explanation": "C: 3 ways of valuing property"
    },
    {
      "id": 60,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3 ways of valuing property?",
      "options": {
        "a": "1. Tenant’s Improvements",
        "b": "Equipment",
        "c": "Method used to insure commercial building, equipment and stock under a single limit of insurance",
        "d": "ACV - repair, replace or rebuild less depreciation",
        "e": "considered in control of insured and are trade risks. Except if fire"
      },
      "answer": "d",
      "answer_text": "ACV - repair, replace or rebuild less depreciation",
      "explanation": "D: ACV - repair, replace or rebuild less depreciation"
    },
    {
      "id": 61,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes ACV?",
      "options": {
        "a": "repair, replace or rebuild less depreciation",
        "b": "Not greater than either of 2% of the amount of insurance or $5,000",
        "c": "No coverage when storing property of others, which can be endorsed through a",
        "d": "Perils Excluded",
        "e": "If the insured peril is the cause of pollution, the loss is NOT excluded"
      },
      "answer": "a",
      "answer_text": "repair, replace or rebuild less depreciation",
      "explanation": "A: repair, replace or rebuild less depreciation"
    },
    {
      "id": 62,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes ACV - repair, replace or rebuild less depreciation?",
      "options": {
        "a": "Replacement Value - repair, replace or rebuild without deduction for depreciation",
        "b": "Fact-Find Survey uses",
        "c": "financial statement is used. But it is important to",
        "d": "Option 1 - Ordinary Payroll - Limited Coverage - 90 or 180 day Option",
        "e": "a promise that certain facts are true and will remain so."
      },
      "answer": "a",
      "answer_text": "Replacement Value - repair, replace or rebuild without deduction for depreciation",
      "explanation": "A: Replacement Value - repair, replace or rebuild without deduction for depreciation"
    },
    {
      "id": 63,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Replacement Value?",
      "options": {
        "a": "expert opinion of licensed real estate appraiser",
        "b": "repair, replace or rebuild without deduction for depreciation",
        "c": "2. Contractor’s Equipment Floater - designed to insured movable equipment owned by",
        "d": "1. Tenant’s Improvements",
        "e": "describes buildings that have met min standards hours"
      },
      "answer": "b",
      "answer_text": "repair, replace or rebuild without deduction for depreciation",
      "explanation": "B: repair, replace or rebuild without deduction for depreciation"
    },
    {
      "id": 64,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Book Value?",
      "options": {
        "a": "p) Bylaws - no coverage for increased cost through enforcement of bylaw",
        "b": "Limit of Insurance Required/Premium Adjustement Provision",
        "c": "No bearing on the amount of payment made by the insurer",
        "d": "original purchase price less depreciation or other write-offs (not including inflation)",
        "e": "estimated annual rental value of unoccupied portions"
      },
      "answer": "d",
      "answer_text": "original purchase price less depreciation or other write-offs (not including inflation)",
      "explanation": "D: original purchase price less depreciation or other write-offs (not including inflation)"
    },
    {
      "id": 65,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Book Value Method?",
      "options": {
        "a": "Pays costs for auditors to certify and prove the loss.",
        "b": "must reflect maximum values",
        "c": "No bearing on the amount of payment made by the insurer",
        "d": "Loss to systems (hardware)",
        "e": "the insured must file a statement of values with the"
      },
      "answer": "c",
      "answer_text": "No bearing on the amount of payment made by the insurer",
      "explanation": "C: No bearing on the amount of payment made by the insurer"
    },
    {
      "id": 66,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Not appropriate for insurance purposes?",
      "options": {
        "a": "Book value can be reduced to zero",
        "b": "something that naturally causes its own demise over time. Like",
        "c": "f) Trade losses",
        "d": "used in low risk commercial operations. The owner",
        "e": "4. Building Damage by Theft - provides coverage for damage to that part of the building"
      },
      "answer": "a",
      "answer_text": "Book value can be reduced to zero",
      "explanation": "A: Book value can be reduced to zero"
    },
    {
      "id": 67,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Book value can be reduced to zero?",
      "options": {
        "a": "Can be combined with Earthquake (“Flake”)",
        "b": "Cost of making goods that are faulty and improper design/workmanship/material",
        "c": "3 approaches for actual cash value",
        "d": "Market Value",
        "e": "Straight line / Plateau accelerated method"
      },
      "answer": "c",
      "answer_text": "3 approaches for actual cash value",
      "explanation": "C: 3 approaches for actual cash value"
    },
    {
      "id": 68,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3 approaches for actual cash value?",
      "options": {
        "a": "Underground, muskeg, blasting, dynamite.",
        "b": "cost of repair, replace or rebuild minus depreciation",
        "c": "Available in limited or broad form. Insures values of materials and cost of labour.",
        "d": "Cost Approach",
        "e": "Insurers will pay a loss even when they cannot tie an employee to a loss."
      },
      "answer": "d",
      "answer_text": "Cost Approach",
      "explanation": "D: Cost Approach"
    },
    {
      "id": 69,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Cost Approach?",
      "options": {
        "a": "ONLY applies to building damage",
        "b": "May not have adequate coverage, may not be broad enough, may be invalid due to",
        "c": "h) Rodents/insects/vermin - unless its directly by a peril",
        "d": "Subtract the rate of depreciation from RC",
        "e": "Ordinary Payroll Expense - has two options."
      },
      "answer": "d",
      "answer_text": "Subtract the rate of depreciation from RC",
      "explanation": "D: Subtract the rate of depreciation from RC"
    },
    {
      "id": 70,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Subtract the rate of depreciation from RC?",
      "options": {
        "a": "Straight line / Plateau accelerated method",
        "b": "step into the shoes of the party compensated and sue",
        "c": "k) Nuclear incident - except for ensuing loss caused by named peril.",
        "d": "determine the R/C of the property, then subtract rate of",
        "e": "1. Physical protection - steel doors, locks, bars"
      },
      "answer": "a",
      "answer_text": "Straight line / Plateau accelerated method",
      "explanation": "A: Straight line / Plateau accelerated method"
    },
    {
      "id": 71,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Straight line / Plateau accelerated method?",
      "options": {
        "a": "amount of loss is influenced by economic conditions and trends.",
        "b": "owner/employees control it, the weakness is they can forget to",
        "c": "owner controls it and do not send to a control center.",
        "d": "when income is produced from down buildings, net annual rent",
        "e": "Market Value"
      },
      "answer": "e",
      "answer_text": "Market Value",
      "explanation": "E: Market Value"
    },
    {
      "id": 72,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Market Value?",
      "options": {
        "a": "Expert opinion",
        "b": "Subtract the rate of depreciation from RC",
        "c": "considered in control of insured and are trade risks. Except if fire",
        "d": "will continue during the interruption such as accounts payables, mortgage,",
        "e": "will not ignite or burn when subjected to fire"
      },
      "answer": "a",
      "answer_text": "Expert opinion",
      "explanation": "A: Expert opinion"
    },
    {
      "id": 73,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Expert opinion?",
      "options": {
        "a": "Primary duty is to select risks most profitable to the company. Improper screening can",
        "b": "Portable wall dividers separating work areas in a sales office",
        "c": "Replacement Value - repair, replace or rebuild without deduction for depreciation",
        "d": "except for sale as stock and except on the premises",
        "e": "Licensed real estate appraiser"
      },
      "answer": "e",
      "answer_text": "Licensed real estate appraiser",
      "explanation": "E: Licensed real estate appraiser"
    },
    {
      "id": 74,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Licensed real estate appraiser?",
      "options": {
        "a": "Market value of before / after the loss",
        "b": "All risks coverage, including damage to letterwork.",
        "c": "a) Wear and tear, rust and corrosion, gradual deterioration",
        "d": "Other Excluded Losses",
        "e": "Subtract the rate of depreciation from RC"
      },
      "answer": "a",
      "answer_text": "Market value of before / after the loss",
      "explanation": "A: Market value of before / after the loss"
    },
    {
      "id": 75,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes The land?",
      "options": {
        "a": "Income approach",
        "b": "Applies while being conveyed to other location",
        "c": "All insurers share in premiums and losses",
        "d": "Primary duty is to select risks most profitable to the company. Improper screening can",
        "e": "if insured had similar policies before,"
      },
      "answer": "a",
      "answer_text": "Income approach",
      "explanation": "A: Income approach"
    },
    {
      "id": 76,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Income approach?",
      "options": {
        "a": "Access was prohibited by civil authority",
        "b": "1. Risk Selection",
        "c": "By-Laws Coverage - when complying to by-laws results in an increase in time to",
        "d": "3. War, Invasion, act of foreign enemy",
        "e": "run -down buildings = net annual rent with a capitalization rate applied to it"
      },
      "answer": "e",
      "answer_text": "run -down buildings = net annual rent with a capitalization rate applied to it",
      "explanation": "E: run -down buildings = net annual rent with a capitalization rate applied to it"
    },
    {
      "id": 77,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes True to the Owner?",
      "options": {
        "a": "1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or",
        "b": "certain hazards or conditions to all buildings that influence their",
        "c": "Clear and present danger",
        "d": "The insureds claim the previous three methods have failed to consider their special circumstances",
        "e": "profits form will be more suitable for subsequent loss of customers"
      },
      "answer": "d",
      "answer_text": "The insureds claim the previous three methods have failed to consider their special circumstances",
      "explanation": "D: The insureds claim the previous three methods have failed to consider their special circumstances"
    },
    {
      "id": 78,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Broad Evidence Rue?",
      "options": {
        "a": "Premium is provisional - adjusted based on reported values at the end of the",
        "b": "Pays costs for auditors to certify and prove the loss.",
        "c": "Ordinary Payroll Expense - has two options.",
        "d": "Ties together all four of the above approaches and considers:",
        "e": "fair and reasonable price property would be on the market minus"
      },
      "answer": "d",
      "answer_text": "Ties together all four of the above approaches and considers:",
      "explanation": "D: Ties together all four of the above approaches and considers:"
    },
    {
      "id": 79,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes RC less depreciation?",
      "options": {
        "a": "Cash price value in a fair market, allow for depreciation",
        "b": "Loss is restricted to sudden backing up of brown water.",
        "c": "can be endorsed.",
        "d": "Market value",
        "e": "enter the insured’s premises at all reasonable times to inspect."
      },
      "answer": "d",
      "answer_text": "Market value",
      "explanation": "D: Market value"
    },
    {
      "id": 80,
      "source": "Notes docx",
      "chapter": "Chapter 7: Business Interruption",
      "type": "mcq",
      "question": "Which of the following best describes Market value?",
      "options": {
        "a": "Rental value",
        "b": "Premium is provisional - adjusted based on reported values at the end of the",
        "c": "k) Nuclear incident - except for ensuing loss caused by named peril.",
        "d": "1. Extra Expense Endorsement Form",
        "e": "can be endorsed, but having to comply with building by-laws is not"
      },
      "answer": "a",
      "answer_text": "Rental value",
      "explanation": "A: Rental value"
    },
    {
      "id": 81,
      "source": "Notes docx",
      "chapter": "Chapter 7: Business Interruption",
      "type": "mcq",
      "question": "Which of the following best describes Rental value?",
      "options": {
        "a": "Rider - document issued by insurer that adds coverages.",
        "b": "Assessed valuation",
        "c": "ONLY applies to building damage",
        "d": "can be endorsed.",
        "e": "Applies while being conveyed to other location"
      },
      "answer": "b",
      "answer_text": "Assessed valuation",
      "explanation": "B: Assessed valuation"
    },
    {
      "id": 82,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Location?",
      "options": {
        "a": "Specialized policy forms have been developed: automobiles, money and securities",
        "b": "Contains 5 Insuring Agreements (insured can select any or all coverages and are continuous",
        "c": "Obsolescence",
        "d": "Both the owner of the property and the bailee has insurable interest",
        "e": "methods used to secure access when business is closed."
      },
      "answer": "c",
      "answer_text": "Obsolescence",
      "explanation": "C: Obsolescence"
    },
    {
      "id": 83,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Obsolescence?",
      "options": {
        "a": "excluded due to high exposure",
        "b": "but has premium adjustments and reporting.",
        "c": "Resale success",
        "d": "Fact-Find Survey uses",
        "e": "if not all met, are on ACV"
      },
      "answer": "c",
      "answer_text": "Resale success",
      "explanation": "C: Resale success"
    },
    {
      "id": 84,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Resale success?",
      "options": {
        "a": "the insurer retains the right to step into the shoes of the insured and sue",
        "b": "a central station ensures it is turned on at arranged times.",
        "c": "Actual cash value",
        "d": "Labour standards/notice of layoff periods",
        "e": "3. Personal Property of Officers and Employees - allows personal property to fit into the"
      },
      "answer": "c",
      "answer_text": "Actual cash value",
      "explanation": "C: Actual cash value"
    },
    {
      "id": 85,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Actual cash value?",
      "options": {
        "a": "1. Tool Floater Rider - extends coverage to off premises use of tools. Has two forms",
        "b": "Cash price value in a fair market, allow for depreciation",
        "c": "Securities is limited to ACV on the business day of the loss. Other",
        "d": "named insured, policy period, identifies nine crime coverage options",
        "e": "actual annual rents"
      },
      "answer": "b",
      "answer_text": "Cash price value in a fair market, allow for depreciation",
      "explanation": "B: Cash price value in a fair market, allow for depreciation"
    },
    {
      "id": 86,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes All property?",
      "options": {
        "a": "safety paper, protect blank cheques, controlled use of fax.",
        "b": "ACV - repair, replace or rebuild less depreciation",
        "c": "but has premium adjustments and reporting.",
        "d": "Insurance covers >two items / locations",
        "e": "Prompt recovery of loss."
      },
      "answer": "d",
      "answer_text": "Insurance covers >two items / locations",
      "explanation": "D: Insurance covers >two items / locations"
    },
    {
      "id": 87,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Insurance covers >two items / locations?",
      "options": {
        "a": "1. Extra Expense Endorsement Form",
        "b": "2 Coverage Limits",
        "c": "Pays all claims",
        "d": "fair rental value of occupied portions of the building.",
        "e": "One aggregate amount"
      },
      "answer": "e",
      "answer_text": "One aggregate amount",
      "explanation": "E: One aggregate amount"
    },
    {
      "id": 88,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes One aggregate amount?",
      "options": {
        "a": "No separate coverage amounts for each item",
        "b": "c) Damage to electrical devices caused by artificially generated electrical currants.",
        "c": "Assessed valuation",
        "d": "Covers actual cost of reproduction",
        "e": "Production Machinery - covers any complete machine with processes forms,"
      },
      "answer": "a",
      "answer_text": "No separate coverage amounts for each item",
      "explanation": "A: No separate coverage amounts for each item"
    },
    {
      "id": 89,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes No separate coverage amounts for each item?",
      "options": {
        "a": "Must make application for refund within 12 months of expiry of policy",
        "b": "actual annual rents",
        "c": "Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are",
        "d": "Replacement value",
        "e": "Perils Excluded"
      },
      "answer": "d",
      "answer_text": "Replacement value",
      "explanation": "D: Replacement value"
    },
    {
      "id": 90,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Replacement value?",
      "options": {
        "a": "wrongful taking by force or fear. Includes unlawful act witnessed by custodian",
        "b": "Specialized policy forms have been developed: automobiles, money and securities",
        "c": "e) Animals/fish/birds - except when due to named peril or theft/attempted theft",
        "d": "This covers for what named perils and broad form do not cover - explosion of boilers",
        "e": "Cash value to replace"
      },
      "answer": "e",
      "answer_text": "Cash value to replace",
      "explanation": "E: Cash value to replace"
    },
    {
      "id": 91,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Cash value to replace?",
      "options": {
        "a": "lacks an essential element to be enforceable by law",
        "b": "Separate payments are provided from all companies to the clamant",
        "c": "Coverage only at premises",
        "d": "Scheduled coverage",
        "e": "portion applies to in transit or within other premises"
      },
      "answer": "d",
      "answer_text": "Scheduled coverage",
      "explanation": "D: Scheduled coverage"
    },
    {
      "id": 92,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Scheduled coverage?",
      "options": {
        "a": "check roof, wiring, breakers, plumbing, heating",
        "b": "Inherent Vice - something that naturally causes its own demise over time. Like",
        "c": "Cash price value in a fair market, allow for depreciation",
        "d": "6. Equipment Breakdown",
        "e": "Property is itemized"
      },
      "answer": "e",
      "answer_text": "Property is itemized",
      "explanation": "E: Property is itemized"
    },
    {
      "id": 93,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Property is itemized?",
      "options": {
        "a": "Coverage limit for each item",
        "b": "ONLY applies to building damage. Does not apply to property",
        "c": "A bailee is someone who has temporary custody of personal property of another for a",
        "d": "c) Damage to electrical devices caused by artificially generated electrical currants.",
        "e": "4. Inflation Protection - increases building insurance during the policy period to reflect"
      },
      "answer": "a",
      "answer_text": "Coverage limit for each item",
      "explanation": "A: Coverage limit for each item"
    },
    {
      "id": 94,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Coverage limit for each item?",
      "options": {
        "a": "1 - Access was prohibited by civil authority",
        "b": "maximum payable for any one accident",
        "c": "Wear/tear/loss due to the designed operation",
        "d": "most extensive form. The policy is defined by exclusions",
        "e": "Property of every description"
      },
      "answer": "e",
      "answer_text": "Property of every description",
      "explanation": "E: Property of every description"
    },
    {
      "id": 95,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Property of every description?",
      "options": {
        "a": "can be endorsed, but having to comply with building by-laws is not",
        "b": "Method used to insure commercial building, equipment and stock under a single limit of insurance",
        "c": "covers loss of income to owners of tenanted",
        "d": "3 ways of valuing property",
        "e": "m) Loss or damage to pressel vessel greater than 15 PSI. Unless its less than 24 inches"
      },
      "answer": "b",
      "answer_text": "Method used to insure commercial building, equipment and stock under a single limit of insurance",
      "explanation": "B: Method used to insure commercial building, equipment and stock under a single limit of insurance"
    },
    {
      "id": 96,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Tenant’s improvements?",
      "options": {
        "a": "not insured.",
        "b": "used to guard interior and restrict entry where valuables are stored.",
        "c": "Additions or changes to rented premises by a tenant at his/her own expense.",
        "d": "Excludes: glass, lettering, ornamentation, tapes/foils to the glass",
        "e": "Must make application for refund within 12 months of expiry of policy"
      },
      "answer": "c",
      "answer_text": "Additions or changes to rented premises by a tenant at his/her own expense.",
      "explanation": "C: Additions or changes to rented premises by a tenant at his/her own expense."
    },
    {
      "id": 97,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Improvements or betterments?",
      "options": {
        "a": "each rider identifies and defines classes of property such as",
        "b": "Common Hazards - certain hazards or conditions to all buildings that influence their",
        "c": "Wear/tear/loss due to the designed operation",
        "d": "indirect and not direct.",
        "e": "Difference between package and manuscript policies"
      },
      "answer": "e",
      "answer_text": "Difference between package and manuscript policies",
      "explanation": "E: Difference between package and manuscript policies"
    },
    {
      "id": 98,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Combine?",
      "options": {
        "a": "Difference between package and manuscript policies",
        "b": "Insured must confirm amount collected is less than outstanding and they are unable to",
        "c": "For tenants who have assumed responsibility for crime at the premises. Also for building",
        "d": "No coverage for loss/damage caused by explosion of boilers.",
        "e": "Under 1 form"
      },
      "answer": "e",
      "answer_text": "Under 1 form",
      "explanation": "E: Under 1 form"
    },
    {
      "id": 99,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Under 1 form?",
      "options": {
        "a": "Variety of coverages needed by offices and small mercantile operations",
        "b": "c. This also includes contents shipped by Parcel Post. The amount of insurance is",
        "c": "One aggregate amount",
        "d": "Characteristics",
        "e": "types of losses expected from everyday operation"
      },
      "answer": "a",
      "answer_text": "Variety of coverages needed by offices and small mercantile operations",
      "explanation": "A: Variety of coverages needed by offices and small mercantile operations"
    },
    {
      "id": 100,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Manuscript?",
      "options": {
        "a": "items specifically identified on policy",
        "b": "Same as commercial building and stock named perils",
        "c": "For risks that have a specialized exposure",
        "d": "May need valid maintenance contract",
        "e": "Inherent vice"
      },
      "answer": "c",
      "answer_text": "For risks that have a specialized exposure",
      "explanation": "C: For risks that have a specialized exposure"
    },
    {
      "id": 101,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes For risks that have a specialized exposure?",
      "options": {
        "a": "Extensions Available",
        "b": "e) Animals/fish/birds - except when due to named peril or theft/attempted theft",
        "c": "period of vacancy specified on form. Duration is on underwriter’s discretion",
        "d": "2. Debris Removal Clause",
        "e": "No standard coverage from exists"
      },
      "answer": "e",
      "answer_text": "No standard coverage from exists",
      "explanation": "E: No standard coverage from exists"
    },
    {
      "id": 102,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes No standard coverage from exists?",
      "options": {
        "a": "Offered on an optional basis",
        "b": "except for ensuing loss caused by named peril.",
        "c": "2 - Peril causing damage to the neighbor was insured under the insured’s own policy.",
        "d": "13. Difference between reinsurance and subscription",
        "e": "there is a need to project lost income for up to two years."
      },
      "answer": "d",
      "answer_text": "13. Difference between reinsurance and subscription",
      "explanation": "D: 13. Difference between reinsurance and subscription"
    },
    {
      "id": 103,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 13. Difference between reinsurance and subscription?",
      "options": {
        "a": "Resale success",
        "b": "describes buildings that have met min standards hours",
        "c": "all insurers share in both premiums collected and losses incurred. The contract",
        "d": "Reinsurance",
        "e": "owner controls system and is not required to inform the"
      },
      "answer": "d",
      "answer_text": "Reinsurance",
      "explanation": "D: Reinsurance"
    },
    {
      "id": 104,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Reinsurance?",
      "options": {
        "a": "steel doors, locks, bars",
        "b": "Loading - rate over and above the fire rate",
        "c": "All insurers share in premiums and losses",
        "d": "excluded due to high exposure",
        "e": "determine the R/C of the property, then subtract rate of"
      },
      "answer": "c",
      "answer_text": "All insurers share in premiums and losses",
      "explanation": "C: All insurers share in premiums and losses"
    },
    {
      "id": 105,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes All insurers share in premiums and losses?",
      "options": {
        "a": "Covers expenses such as renting temporary premises, renovations, moving expenses,",
        "b": "Between the primary insurer and the reinsurer",
        "c": "Cash price value in a fair market, allow for depreciation",
        "d": "Non combustible - will not ignite or burn when subjected to fire",
        "e": "includes unlawful taking from a vault or safe"
      },
      "answer": "b",
      "answer_text": "Between the primary insurer and the reinsurer",
      "explanation": "B: Between the primary insurer and the reinsurer"
    },
    {
      "id": 106,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Between the primary insurer and the reinsurer?",
      "options": {
        "a": "Expert opinion",
        "b": "Resale success",
        "c": "Controlled by the primary insurer",
        "d": "expert opinion of licensed real estate appraiser",
        "e": "Unoccupied - lack of habitual presence. Complete with contents but owner is absent."
      },
      "answer": "c",
      "answer_text": "Controlled by the primary insurer",
      "explanation": "C: Controlled by the primary insurer"
    },
    {
      "id": 107,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Controlled by the primary insurer?",
      "options": {
        "a": "generally organized information for a purpose",
        "b": "Ensures loss of money/securities within premise or any banking premise",
        "c": "Pays all claims",
        "d": "Property is itemized",
        "e": "ACV - repair, replace or rebuild less depreciation"
      },
      "answer": "c",
      "answer_text": "Pays all claims",
      "explanation": "C: Pays all claims"
    },
    {
      "id": 108,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Pays all claims?",
      "options": {
        "a": "Each insurer contracts with the insured for a specific limit of liability",
        "b": "Amount of insurance specified on the declarations page for the lost or damaged property",
        "c": "Subscription",
        "d": "Peril causing damage to the neighbor was insured under the insured’s own policy.",
        "e": "1. Reinstatement Clause - insureds will have as much insurance after a loss as they did"
      },
      "answer": "c",
      "answer_text": "Subscription",
      "explanation": "C: Subscription"
    },
    {
      "id": 109,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Subscription?",
      "options": {
        "a": "p) Bylaws - no coverage for increased cost through enforcement of bylaw",
        "b": "the inertia of a body that tends to move away from center it revolves",
        "c": "Each insurer contracts with the insured for a specific limit of liability",
        "d": "1. Ensures same perils as property policy",
        "e": "lack of habitual presence. Complete with contents but owner is absent."
      },
      "answer": "c",
      "answer_text": "Each insurer contracts with the insured for a specific limit of liability",
      "explanation": "C: Each insurer contracts with the insured for a specific limit of liability"
    },
    {
      "id": 110,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Each insurer has its own policy?",
      "options": {
        "a": "Separate payments are provided from all companies to the clamant",
        "b": "No separate coverage amounts for each item",
        "c": "indirect and not direct.",
        "d": "Increase in cost of construction",
        "e": "Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system"
      },
      "answer": "a",
      "answer_text": "Separate payments are provided from all companies to the clamant",
      "explanation": "A: Separate payments are provided from all companies to the clamant"
    },
    {
      "id": 111,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Pays or denies, others don't have to follow?",
      "options": {
        "a": "3. Rate-Making - factors that influence the premium are application info, internal and",
        "b": "only expenses deemed to be necessary to the resumption of",
        "c": "Replacement shall be on the same or adjacent site",
        "d": "Equipment",
        "e": "14. Reinsurance contracts are preferred by most brokers?"
      },
      "answer": "e",
      "answer_text": "14. Reinsurance contracts are preferred by most brokers?",
      "explanation": "E: 14. Reinsurance contracts are preferred by most brokers?"
    },
    {
      "id": 112,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 14. Reinsurance contracts are preferred by most brokers??",
      "options": {
        "a": "Simpler to deal with an insurer protected by reinsurance",
        "b": "estimated annual rental value of unoccupied portions",
        "c": "1. Removal Clause",
        "d": "insures equipment and stock other than at the specific location.",
        "e": "Ordinary Payroll Exclusion"
      },
      "answer": "a",
      "answer_text": "Simpler to deal with an insurer protected by reinsurance",
      "explanation": "A: Simpler to deal with an insurer protected by reinsurance"
    },
    {
      "id": 113,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Interest of the insured?",
      "options": {
        "a": "expert opinion of licensed real estate appraiser",
        "b": "k) Nuclear incident - except for ensuing loss caused by named peril.",
        "c": "Subrogation - step into the shoes of the party compensated and sue",
        "d": "Amount of insurance specified on the declarations page for the lost or damaged property",
        "e": "A bailee is someone who has temporary custody of personal property of another for a"
      },
      "answer": "d",
      "answer_text": "Amount of insurance specified on the declarations page for the lost or damaged property",
      "explanation": "D: Amount of insurance specified on the declarations page for the lost or damaged property"
    },
    {
      "id": 114,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Losses are smaller than conducting a full inventory?",
      "options": {
        "a": "This covers for what named perils and broad form do not cover - explosion of boilers",
        "b": "not insured.",
        "c": "Not greater than either of 2% of the amount of insurance or $5,000",
        "d": "26. Three obligations placed upon insureds by the Property Protection Systems clause",
        "e": "written application, security checks, investigation of personal finances,"
      },
      "answer": "c",
      "answer_text": "Not greater than either of 2% of the amount of insurance or $5,000",
      "explanation": "C: Not greater than either of 2% of the amount of insurance or $5,000"
    },
    {
      "id": 115,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Replace the standard clause?",
      "options": {
        "a": "On premises only",
        "b": "building material stored at a location away from the project",
        "c": "19. The requirements of the Stated Amount Co-insurance Clause?",
        "d": "Detachment - distance between insured property and other commercially rated",
        "e": "each insurer contracts with the insured for a specific limit of liability. If one"
      },
      "answer": "c",
      "answer_text": "19. The requirements of the Stated Amount Co-insurance Clause?",
      "explanation": "C: 19. The requirements of the Stated Amount Co-insurance Clause?"
    },
    {
      "id": 116,
      "source": "Notes docx",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "type": "mcq",
      "question": "Which of the following best describes Potential to be catastrophic: earthquakes, flood?",
      "options": {
        "a": "the insured has a legal duty to take steps to mitigate",
        "b": "any employee who has special skills not easily replaced is not ordinary",
        "c": "direct security for individual items.",
        "d": "lack of habitual presence. Complete with contents but owner is absent.",
        "e": "Specialized policy forms have been developed: automobiles, money and securities"
      },
      "answer": "e",
      "answer_text": "Specialized policy forms have been developed: automobiles, money and securities",
      "explanation": "E: Specialized policy forms have been developed: automobiles, money and securities"
    },
    {
      "id": 117,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 22. Explain the provisions of the reinstatement clause?",
      "options": {
        "a": "Insured shall have as much insurance after a loss as they did before it",
        "b": "certain hazards or conditions to all buildings that influence their",
        "c": "duplicating sensitive data/storing off premises, requiring two",
        "d": "Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are",
        "e": "Insured is liable only for cost of replacing, repairing, constructing or the property on the"
      },
      "answer": "a",
      "answer_text": "Insured shall have as much insurance after a loss as they did before it",
      "explanation": "A: Insured shall have as much insurance after a loss as they did before it"
    },
    {
      "id": 118,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Sprinkler or other fire extinguishing system?",
      "options": {
        "a": "group of insurers participating in a policy",
        "b": "Excludes jewellery, fur, paintings, livestock, etc",
        "c": "Fire detection system",
        "d": "3 ways to insure commercial property",
        "e": "covers merchandise and goods sold by the insured and"
      },
      "answer": "c",
      "answer_text": "Fire detection system",
      "explanation": "C: Fire detection system"
    },
    {
      "id": 119,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Fire detection system?",
      "options": {
        "a": "1. Temporary Locations - insures equipment and stock other than at the specific location.",
        "b": "Insures goods usual to the business.",
        "c": "Equipment",
        "d": "Insures the records of debts owed to the insured.",
        "e": "Intrusion detection system"
      },
      "answer": "e",
      "answer_text": "Intrusion detection system",
      "explanation": "E: Intrusion detection system"
    },
    {
      "id": 120,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Intrusion detection system?",
      "options": {
        "a": "Cash value to replace",
        "b": "Testing/other construction",
        "c": "loss of profit, gross earnings, rental income.",
        "d": "26. Three obligations placed upon insureds by the Property Protection Systems clause",
        "e": "insures stock and equipment against actual/attempted burglary, robbery"
      },
      "answer": "d",
      "answer_text": "26. Three obligations placed upon insureds by the Property Protection Systems clause",
      "explanation": "D: 26. Three obligations placed upon insureds by the Property Protection Systems clause"
    },
    {
      "id": 121,
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Shall notify the insurer forthwith?",
      "options": {
        "a": "Blank value only if property is not replaced or reproduced",
        "b": "Perils Excluded",
        "c": "Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system",
        "d": "DIRECT DAMAGE FORMS",
        "e": "3 coverages"
      },
      "answer": "c",
      "answer_text": "Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system",
      "explanation": "C: Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system"
    },
    {
      "id": 122,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes CHAPTER 1: INTRODUCTION?",
      "options": {
        "a": "owner controls system and is not required to inform the",
        "b": "insures stock and equipment against actual/attempted burglary, robbery",
        "c": "Straight line / Plateau accelerated method",
        "d": "o) Settling/Expansion/Contraction - ONLY applies to building damage",
        "e": "Three Ways Property Can Be Valued:"
      },
      "answer": "e",
      "answer_text": "Three Ways Property Can Be Valued:",
      "explanation": "E: Three Ways Property Can Be Valued:"
    },
    {
      "id": 123,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Three Ways Property Can Be Valued:?",
      "options": {
        "a": "preparation of original policy, changes requiring endorsements, billing",
        "b": "Endorsements Available for:",
        "c": "any employee who has special skills not easily replaced is not ordinary",
        "d": "duplicating sensitive data/storing off premises, requiring two",
        "e": "1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation"
      },
      "answer": "e",
      "answer_text": "1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation",
      "explanation": "E: 1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": 124,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 1. Actual Cash Value?",
      "options": {
        "a": "1. Consequential Loss Assumption Clause - Cold Storage",
        "b": "cost of repair, replace or rebuild minus depreciation",
        "c": "changes requested effective only when consented to by the insurer.",
        "d": "Misc. Forms",
        "e": "designed to insured movable equipment owned by"
      },
      "answer": "b",
      "answer_text": "cost of repair, replace or rebuild minus depreciation",
      "explanation": "B: cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": 125,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 2. Replacement Value?",
      "options": {
        "a": "direct security for individual items.",
        "b": "Ordinary Payroll Expense - has two options.",
        "c": "same as above, without depreciation deduction.",
        "d": "step into the shoes of the party compensated and sue",
        "e": "Provides means of ensuring predictable increases in stock values in advance."
      },
      "answer": "c",
      "answer_text": "same as above, without depreciation deduction.",
      "explanation": "C: same as above, without depreciation deduction."
    },
    {
      "id": 126,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3. Book Value?",
      "options": {
        "a": "Money in vending machine or coin-operated machines",
        "b": "original purchase price minus depreciation and other write-offs. Not",
        "c": "1 - Access was prohibited by civil authority",
        "d": "allows personal property to fit into the",
        "e": "the insured has a legal duty to take steps to mitigate"
      },
      "answer": "b",
      "answer_text": "original purchase price minus depreciation and other write-offs. Not",
      "explanation": "B: original purchase price minus depreciation and other write-offs. Not"
    },
    {
      "id": 127,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Calculation of ACV?",
      "options": {
        "a": "Sudden, unusual and faulty release of smoke.",
        "b": "each insurer contracts with the insured for a specific limit of liability. If one",
        "c": "b) Flood - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,",
        "d": "1. Formula/Cost Approach - determine the R/C of the property, then subtract rate of",
        "e": "deterioration caused by ordinary and reasonable use of subject matter."
      },
      "answer": "d",
      "answer_text": "1. Formula/Cost Approach - determine the R/C of the property, then subtract rate of",
      "explanation": "D: 1. Formula/Cost Approach - determine the R/C of the property, then subtract rate of"
    },
    {
      "id": 128,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 1. Formula/Cost Approach?",
      "options": {
        "a": "Provides coverage when valuable papers need to be recreated",
        "b": "determine the R/C of the property, then subtract rate of",
        "c": "charged based on annual receipts, and is provisional. Insured required to",
        "d": "repair, replace or rebuild less depreciation",
        "e": "ONLY applies to building damage. Does not apply to property"
      },
      "answer": "b",
      "answer_text": "determine the R/C of the property, then subtract rate of",
      "explanation": "B: determine the R/C of the property, then subtract rate of"
    },
    {
      "id": 129,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 2. Market Value/Direct Sales Approach?",
      "options": {
        "a": "expert opinion of licensed real estate appraiser",
        "b": "No coverage when storing property of others, which can be endorsed through a",
        "c": "All insurers share in premiums and losses",
        "d": "explosion of boilers",
        "e": "Prompt recovery of loss."
      },
      "answer": "a",
      "answer_text": "expert opinion of licensed real estate appraiser",
      "explanation": "A: expert opinion of licensed real estate appraiser"
    },
    {
      "id": 130,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3. Income Approach?",
      "options": {
        "a": "when income is produced from down buildings, net annual rent",
        "b": "1. Reinstatement Clause - insureds will have as much insurance after a loss as they did",
        "c": "EXTENSIONS OF COVERAGE",
        "d": "alerts broker to possible loss exposures, ensures needed coverages are not",
        "e": "Peril causing damage to the neighbor was insured under the insured’s own policy."
      },
      "answer": "a",
      "answer_text": "when income is produced from down buildings, net annual rent",
      "explanation": "A: when income is produced from down buildings, net annual rent"
    },
    {
      "id": 131,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 4. True to Owner?",
      "options": {
        "a": "A bailee is someone who has temporary custody of personal property of another for a",
        "b": "Excludes: glass, lettering, ornamentation, tapes/foils to the glass",
        "c": "repair, replace or rebuild without deduction for depreciation",
        "d": "when insureds claim the previous three methods have failed to",
        "e": "can select individual employees with different limits. Discovery period of 2"
      },
      "answer": "d",
      "answer_text": "when insureds claim the previous three methods have failed to",
      "explanation": "D: when insureds claim the previous three methods have failed to"
    },
    {
      "id": 132,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 5. Broad Evidence Rule?",
      "options": {
        "a": "Equipment",
        "b": "ties together all four of the above.",
        "c": "Ordinary Payroll Exclusion",
        "d": "19. The requirements of the Stated Amount Co-insurance Clause?",
        "e": "magnetic door, window contacts, motion detectors"
      },
      "answer": "b",
      "answer_text": "ties together all four of the above.",
      "explanation": "B: ties together all four of the above."
    },
    {
      "id": 133,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Reinsurance?",
      "options": {
        "a": "excluded due to high exposure",
        "b": "Scheduled - when property is itemized with a limit each",
        "c": "provides coverage for damage to that part of the building",
        "d": "all insurers share in both premiums collected and losses incurred. The contract",
        "e": "3. War, Invasion, act of foreign enemy"
      },
      "answer": "d",
      "answer_text": "all insurers share in both premiums collected and losses incurred. The contract",
      "explanation": "D: all insurers share in both premiums collected and losses incurred. The contract"
    },
    {
      "id": 134,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Subscription?",
      "options": {
        "a": "3 ways to insure commercial property",
        "b": "alerts broker to possible loss exposures, ensures needed coverages are not",
        "c": "Assessed valuation",
        "d": "each insurer contracts with the insured for a specific limit of liability. If one",
        "e": "determine the R/C of the property, then subtract rate of"
      },
      "answer": "d",
      "answer_text": "each insurer contracts with the insured for a specific limit of liability. If one",
      "explanation": "D: each insurer contracts with the insured for a specific limit of liability. If one"
    },
    {
      "id": 135,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Stated Amount of Co-Insurance Clause?",
      "options": {
        "a": "All risks coverage, including damage to letterwork.",
        "b": "Actual or attempted robbery of custodian",
        "c": "For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating",
        "d": "method used to insure commercial building, stock and",
        "e": "the insured must file a statement of values with the"
      },
      "answer": "e",
      "answer_text": "the insured must file a statement of values with the",
      "explanation": "E: the insured must file a statement of values with the"
    },
    {
      "id": 136,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Additional Clauses:?",
      "options": {
        "a": "3 ways to insure commercial property",
        "b": "4. Building Damage by Theft - provides coverage for damage to that part of the building",
        "c": "1. Physical protection - steel doors, locks, bars",
        "d": "Loss to systems (hardware)",
        "e": "1. Reinstatement Clause - insureds will have as much insurance after a loss as they did"
      },
      "answer": "e",
      "answer_text": "1. Reinstatement Clause - insureds will have as much insurance after a loss as they did",
      "explanation": "E: 1. Reinstatement Clause - insureds will have as much insurance after a loss as they did"
    },
    {
      "id": 137,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 1. Reinstatement Clause?",
      "options": {
        "a": "types of losses expected from everyday operation",
        "b": "there is a need to project lost income for up to two years.",
        "c": "insureds will have as much insurance after a loss as they did",
        "d": "Both the owner of the property and the bailee has insurable interest",
        "e": "the inertia of a body that tends to move away from center it revolves"
      },
      "answer": "c",
      "answer_text": "insureds will have as much insurance after a loss as they did",
      "explanation": "C: insureds will have as much insurance after a loss as they did"
    },
    {
      "id": 138,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 2. Subrogation?",
      "options": {
        "a": "Difference between package and manuscript policies",
        "b": "6. Vacancy Permit - on standard policy, vacant/unoccupied is not covered after 30 days.",
        "c": "the insurer retains the right to step into the shoes of the insured and sue",
        "d": "including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,",
        "e": "repair, replace or rebuild without deduction for depreciation"
      },
      "answer": "c",
      "answer_text": "the insurer retains the right to step into the shoes of the insured and sue",
      "explanation": "C: the insurer retains the right to step into the shoes of the insured and sue"
    },
    {
      "id": 139,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3. Property Protection Systems?",
      "options": {
        "a": "Usually covers if its named perils/theft - this extends the definition to other causes of",
        "b": "this extends the definition to other causes of",
        "c": "definition differs from legal, there has to be marks of forcible entry or exit.",
        "d": "insured needs to notify of any interruption to, or flaw or",
        "e": "Caused by faulty workmanship, errors in material and design."
      },
      "answer": "d",
      "answer_text": "insured needs to notify of any interruption to, or flaw or",
      "explanation": "D: insured needs to notify of any interruption to, or flaw or"
    },
    {
      "id": 140,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 4. Premium Adjustment?",
      "options": {
        "a": "must keep records of all insured property for verification.",
        "b": "unless its directly by a peril",
        "c": "owner/employees control it, the weakness is they can forget to",
        "d": "Premium charged is based on the completed value of the project.",
        "e": "Applicable to stock"
      },
      "answer": "e",
      "answer_text": "Applicable to stock",
      "explanation": "E: Applicable to stock"
    },
    {
      "id": 141,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Applicable to stock?",
      "options": {
        "a": "the insured is obligated to restart operations either",
        "b": "Allows over-insured clause for premium refund. Claim must be within 6 months.",
        "c": "except for ensuing loss caused by named peril.",
        "d": "A bailee is someone who has temporary custody of personal property of another for a",
        "e": "p) Bylaws - no coverage for increased cost through enforcement of bylaw"
      },
      "answer": "b",
      "answer_text": "Allows over-insured clause for premium refund. Claim must be within 6 months.",
      "explanation": "B: Allows over-insured clause for premium refund. Claim must be within 6 months."
    },
    {
      "id": 142,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 5. Verification of Values?",
      "options": {
        "a": "2 Coverage Limits",
        "b": "Scheduled - when property is itemized with a limit each",
        "c": "enter the insured’s premises at all reasonable times to inspect.",
        "d": "Covers actual cost of reproduction",
        "e": "the insured is obligated to restart operations either"
      },
      "answer": "c",
      "answer_text": "enter the insured’s premises at all reasonable times to inspect.",
      "explanation": "C: enter the insured’s premises at all reasonable times to inspect."
    },
    {
      "id": 143,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 6. Valuations?",
      "options": {
        "a": "will not ignite or burn when subjected to fire",
        "b": "Under 1 form",
        "c": "used to guard interior and restrict entry where valuables are stored.",
        "d": "insurer retains the right to inspect premises at reasonable times.",
        "e": "Defines basis for valuation of losses for different CLASS of property"
      },
      "answer": "e",
      "answer_text": "Defines basis for valuation of losses for different CLASS of property",
      "explanation": "E: Defines basis for valuation of losses for different CLASS of property"
    },
    {
      "id": 144,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Unsold Stock - ACV?",
      "options": {
        "a": "Sold Stock - selling price less the discounts",
        "b": "1 year after expiry to make a claim.",
        "c": "Property of every description",
        "d": "except when due to named peril or theft/attempted theft",
        "e": "13. Difference between reinsurance and subscription"
      },
      "answer": "a",
      "answer_text": "Sold Stock - selling price less the discounts",
      "explanation": "A: Sold Stock - selling price less the discounts"
    },
    {
      "id": 145,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Sold Stock?",
      "options": {
        "a": "selling price less the discounts",
        "b": "3. Impact by aircraft/land vehicle",
        "c": "Three Ways Property Can Be Valued:",
        "d": "This can also be a Transportation Floater Rider (Limited Form) - provided on named perils.",
        "e": "Tenant’s improvements - additions or charges rented property at the expense of the"
      },
      "answer": "a",
      "answer_text": "selling price less the discounts",
      "explanation": "A: selling price less the discounts"
    },
    {
      "id": 146,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Property of Others Special Basis of Settlement?",
      "options": {
        "a": "Licensed real estate appraiser",
        "b": "Very detailed application form",
        "c": "1. Tenant’s Improvements",
        "d": "convertible, valuable, portable.",
        "e": "A bailee is someone who has temporary custody of personal property of another for a"
      },
      "answer": "c",
      "answer_text": "1. Tenant’s Improvements",
      "explanation": "C: 1. Tenant’s Improvements"
    },
    {
      "id": 147,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 1. Tenant’s Improvements?",
      "options": {
        "a": "Scheduled - items specifically identified on policy",
        "b": "1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation",
        "c": "if repaired with due diligence and dispatch, the insured is entitled to claim all costs",
        "d": "Can be combined with Earthquake (“Flake”)",
        "e": "Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system"
      },
      "answer": "c",
      "answer_text": "if repaired with due diligence and dispatch, the insured is entitled to claim all costs",
      "explanation": "C: if repaired with due diligence and dispatch, the insured is entitled to claim all costs"
    },
    {
      "id": 148,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 2. Records?",
      "options": {
        "a": "period of vacancy specified on form. Duration is on underwriter’s discretion",
        "b": "2. Forcible entry into protected enclosures",
        "c": "Extensions Available",
        "d": "Excludes: glass, lettering, ornamentation, tapes/foils to the glass",
        "e": "Manually maintained records are blank value only + costs to copy from other source"
      },
      "answer": "e",
      "answer_text": "Manually maintained records are blank value only + costs to copy from other source",
      "explanation": "E: Manually maintained records are blank value only + costs to copy from other source"
    },
    {
      "id": 149,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Chapter 1 KEY TERMS?",
      "options": {
        "a": "Actual Cash Value - fair and reasonable price property would be on the market minus",
        "b": "g) Smoke from cumulative agricultural or industrial operations",
        "c": "Insurers will pay a loss even when they cannot tie an employee to a loss.",
        "d": "b) Flood - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,",
        "e": "Insures goods usual to the business."
      },
      "answer": "a",
      "answer_text": "Actual Cash Value - fair and reasonable price property would be on the market minus",
      "explanation": "A: Actual Cash Value - fair and reasonable price property would be on the market minus"
    },
    {
      "id": 150,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Actual Cash Value?",
      "options": {
        "a": "Canadian Currency Clause - all losses are paid in CAD",
        "b": "Expert opinion",
        "c": "each rider identifies and defines classes of property such as",
        "d": "Rider - document issued by insurer that adds coverages.",
        "e": "fair and reasonable price property would be on the market minus"
      },
      "answer": "e",
      "answer_text": "fair and reasonable price property would be on the market minus",
      "explanation": "E: fair and reasonable price property would be on the market minus"
    },
    {
      "id": 151,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes depreciation?",
      "options": {
        "a": "f) Trade losses",
        "b": "Insured needs to keep records in the receptacle described on the form when not in use",
        "c": "Between the primary insurer and the reinsurer",
        "d": "All insurers share in premiums and losses",
        "e": "All property (blanket) - policy of insurance that covers two or more items without listing"
      },
      "answer": "e",
      "answer_text": "All property (blanket) - policy of insurance that covers two or more items without listing",
      "explanation": "E: All property (blanket) - policy of insurance that covers two or more items without listing"
    },
    {
      "id": 152,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes All property (blanket)?",
      "options": {
        "a": "You can endorse temporary storage at insured’s warehouse or loading station",
        "b": "On premises only",
        "c": "policy of insurance that covers two or more items without listing",
        "d": "1. Standard Bill of Lading - reflects amount liable under the tariff",
        "e": "Cash price value in a fair market, allow for depreciation"
      },
      "answer": "c",
      "answer_text": "policy of insurance that covers two or more items without listing",
      "explanation": "C: policy of insurance that covers two or more items without listing"
    },
    {
      "id": 153,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes separate amounts each?",
      "options": {
        "a": "Scheduled - when property is itemized with a limit each",
        "b": "rate over and above the fire rate",
        "c": "No bearing on the amount of payment made by the insurer",
        "d": "there is a need to project lost income for up to two years.",
        "e": "fair and reasonable price property would be on the market minus"
      },
      "answer": "a",
      "answer_text": "Scheduled - when property is itemized with a limit each",
      "explanation": "A: Scheduled - when property is itemized with a limit each"
    },
    {
      "id": 154,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Scheduled?",
      "options": {
        "a": "provides a solution to over-insurance by allowing a refund of the",
        "b": "e) Animals/fish/birds - except when due to named peril or theft/attempted theft",
        "c": "if not, the insurer will reduce the payable amount.",
        "d": "Grouping risks based on categories on their probability for a loss.",
        "e": "when property is itemized with a limit each"
      },
      "answer": "e",
      "answer_text": "when property is itemized with a limit each",
      "explanation": "E: when property is itemized with a limit each"
    },
    {
      "id": 155,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Replacement Value?",
      "options": {
        "a": "failure in working mechanism",
        "b": "3. Released Bill of Lading - releases the carrier from liability of goods. Used when value of",
        "c": "1. Ensures same perils as property policy",
        "d": "the cash value or cost to replace an item",
        "e": "Damage from neglect of shipper, bad packaging, rough handling"
      },
      "answer": "d",
      "answer_text": "the cash value or cost to replace an item",
      "explanation": "D: the cash value or cost to replace an item"
    },
    {
      "id": 156,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Property of every description?",
      "options": {
        "a": "Rider - document issued by insurer that adds coverages.",
        "b": "covers the cost of removing debris of the property after loss. Shall not",
        "c": "methods used to secure access when business is closed.",
        "d": "location specific, restrictions apply.",
        "e": "method used to insure commercial building, stock and"
      },
      "answer": "e",
      "answer_text": "method used to insure commercial building, stock and",
      "explanation": "E: method used to insure commercial building, stock and"
    },
    {
      "id": 157,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes equipment under one limit?",
      "options": {
        "a": "includes following perils",
        "b": "Not greater than either of 2% of the amount of insurance or $5,000",
        "c": "Manually maintained records are blank value only + costs to copy from other source",
        "d": "Tenant’s improvements - additions or charges rented property at the expense of the",
        "e": "includes all means of taking without consent"
      },
      "answer": "d",
      "answer_text": "Tenant’s improvements - additions or charges rented property at the expense of the",
      "explanation": "D: Tenant’s improvements - additions or charges rented property at the expense of the"
    },
    {
      "id": 158,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Tenant’s improvements?",
      "options": {
        "a": "additions or charges rented property at the expense of the",
        "b": "When damage is to media/data ONLY, business interruption is limited to 30 days max",
        "c": "Insurers will pay a loss even when they cannot tie an employee to a loss.",
        "d": "EXCLUDES liability due to cessation of work, theft/attempted theft, flood or",
        "e": "Securities is limited to ACV on the business day of the loss. Other"
      },
      "answer": "a",
      "answer_text": "additions or charges rented property at the expense of the",
      "explanation": "A: additions or charges rented property at the expense of the"
    },
    {
      "id": 159,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Condition?",
      "options": {
        "a": "a condition imposed to do or not do something",
        "b": "c. This also includes contents shipped by Parcel Post. The amount of insurance is",
        "c": "the inertia of a body that tends to move away from center it revolves",
        "d": "lacks an essential element to be enforceable by law",
        "e": "Can be combined with Earthquake (“Flake”)"
      },
      "answer": "a",
      "answer_text": "a condition imposed to do or not do something",
      "explanation": "A: a condition imposed to do or not do something"
    },
    {
      "id": 160,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Warranty?",
      "options": {
        "a": "Theft from window display area inside the premises while premises are open",
        "b": "indirect and not direct.",
        "c": "a promise that certain facts are true and will remain so.",
        "d": "Rider - document issued by insurer that adds coverages.",
        "e": "Applies off premises but only the lesser of 10% or $5000"
      },
      "answer": "c",
      "answer_text": "a promise that certain facts are true and will remain so.",
      "explanation": "C: a promise that certain facts are true and will remain so."
    },
    {
      "id": 161,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Fraudulent Misrepresentation?",
      "options": {
        "a": "1. Consequential Loss Assumption Clause - Cold Storage",
        "b": "Pays all claims",
        "c": "a false statement made knowing to be false",
        "d": "loss does not apply to first $1000 of any loss and does not",
        "e": "adjusted based on reported values at the end of the"
      },
      "answer": "c",
      "answer_text": "a false statement made knowing to be false",
      "explanation": "C: a false statement made knowing to be false"
    },
    {
      "id": 162,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Material Fact?",
      "options": {
        "a": "4. Continues beyond expiry.",
        "b": "Defines basis for valuation of losses for different CLASS of property",
        "c": "selling price less the discounts",
        "d": "Ties together all four of the above approaches and considers:",
        "e": "a fact which if the insurer knew about, would affect the decision to insure"
      },
      "answer": "e",
      "answer_text": "a fact which if the insurer knew about, would affect the decision to insure",
      "explanation": "E: a fact which if the insurer knew about, would affect the decision to insure"
    },
    {
      "id": 163,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes it or not?",
      "options": {
        "a": "Very detailed application form",
        "b": "Obsolescence",
        "c": "c. This also includes contents shipped by Parcel Post. The amount of insurance is",
        "d": "Loading - rate over and above the fire rate",
        "e": "Subrogation - step into the shoes of the party compensated and sue"
      },
      "answer": "e",
      "answer_text": "Subrogation - step into the shoes of the party compensated and sue",
      "explanation": "E: Subrogation - step into the shoes of the party compensated and sue"
    },
    {
      "id": 164,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Subrogation?",
      "options": {
        "a": "Insured shall have as much insurance after a loss as they did before it",
        "b": "step into the shoes of the party compensated and sue",
        "c": "most extensive form. The policy is defined by exclusions",
        "d": "Insures goods usual to the business.",
        "e": "1. Extra Expense Endorsement Form"
      },
      "answer": "b",
      "answer_text": "step into the shoes of the party compensated and sue",
      "explanation": "B: step into the shoes of the party compensated and sue"
    },
    {
      "id": 165,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Subscription Policy?",
      "options": {
        "a": "Actual Cash Value - fair and reasonable price property would be on the market minus",
        "b": "1. Removal Clause",
        "c": "group of insurers participating in a policy",
        "d": "Market value",
        "e": "Rust/corrosion"
      },
      "answer": "c",
      "answer_text": "group of insurers participating in a policy",
      "explanation": "C: group of insurers participating in a policy"
    },
    {
      "id": 166,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Void contract?",
      "options": {
        "a": "lacks an essential element to be enforceable by law",
        "b": "o) Settling/Expansion/Contraction - ONLY applies to building damage",
        "c": "Items that are covered",
        "d": "Rental value",
        "e": "Insured must confirm amount collected is less than outstanding and they are unable to"
      },
      "answer": "a",
      "answer_text": "lacks an essential element to be enforceable by law",
      "explanation": "A: lacks an essential element to be enforceable by law"
    },
    {
      "id": 167,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes CHAPTER 2: UNDERWRITING?",
      "options": {
        "a": "o) Settling/Expansion/Contraction - ONLY applies to building damage",
        "b": "must be insured separately",
        "c": "A bailee is someone who has temporary custody of personal property of another for a",
        "d": "26. Three obligations placed upon insureds by the Property Protection Systems clause",
        "e": "Fact-Find Survey uses"
      },
      "answer": "e",
      "answer_text": "Fact-Find Survey uses",
      "explanation": "E: Fact-Find Survey uses"
    },
    {
      "id": 168,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Fact-Find Survey uses?",
      "options": {
        "a": "Sold Stock - selling price less the discounts",
        "b": "Identify coverages needed, help determine cvgs needed",
        "c": "location specific, restrictions apply.",
        "d": "Between the primary insurer and the reinsurer",
        "e": "Locally Supervised - owner/employees control it, the weakness is they can forget to"
      },
      "answer": "b",
      "answer_text": "Identify coverages needed, help determine cvgs needed",
      "explanation": "B: Identify coverages needed, help determine cvgs needed"
    },
    {
      "id": 169,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Identify coverages needed, help determine cvgs needed?",
      "options": {
        "a": "maximum payable for any one accident",
        "b": "Checklist - alerts broker to possible loss exposures, ensures needed coverages are not",
        "c": "No coverage for loss/damage caused by explosion of boilers.",
        "d": "outlines the basic rules",
        "e": "a central station ensures it is turned on at arranged times."
      },
      "answer": "b",
      "answer_text": "Checklist - alerts broker to possible loss exposures, ensures needed coverages are not",
      "explanation": "B: Checklist - alerts broker to possible loss exposures, ensures needed coverages are not"
    },
    {
      "id": 170,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Checklist?",
      "options": {
        "a": "A bailee is someone who has temporary custody of personal property of another for a",
        "b": "notify insurer ASAP, provide sworn proof of loss",
        "c": "changes requested effective only when consented to by the insurer.",
        "d": "Extensions Available",
        "e": "alerts broker to possible loss exposures, ensures needed coverages are not"
      },
      "answer": "e",
      "answer_text": "alerts broker to possible loss exposures, ensures needed coverages are not",
      "explanation": "E: alerts broker to possible loss exposures, ensures needed coverages are not"
    },
    {
      "id": 171,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Physical and Other Qualities of Commercial Risks?",
      "options": {
        "a": "each rider identifies and defines classes of property such as",
        "b": "Building materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,",
        "c": "all property owned by the insured is covered by a single limit of insurance",
        "d": "magnetic door, window contacts, motion detectors",
        "e": "o) Settling/Expansion/Contraction - ONLY applies to building damage"
      },
      "answer": "b",
      "answer_text": "Building materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,",
      "explanation": "B: Building materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,"
    },
    {
      "id": 172,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Building materials best to worst?",
      "options": {
        "a": "Available in limited or broad form. Insures values of materials and cost of labour.",
        "b": "Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are",
        "c": "fire-resistive, non combustible, heavy timber, ordinary,",
        "d": "1. Ensures same perils as property policy",
        "e": "all insurers share in both premiums collected and losses incurred. The contract"
      },
      "answer": "c",
      "answer_text": "fire-resistive, non combustible, heavy timber, ordinary,",
      "explanation": "C: fire-resistive, non combustible, heavy timber, ordinary,"
    },
    {
      "id": 173,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes frame?",
      "options": {
        "a": "Central Station Supervised - a central station ensures it is turned on at arranged times.",
        "b": "ties together all four of the above.",
        "c": "For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating",
        "d": "Detachment - distance between insured property and other commercially rated",
        "e": "Caused by faulty workmanship, errors in material and design."
      },
      "answer": "c",
      "answer_text": "For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating",
      "explanation": "C: For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating"
    },
    {
      "id": 174,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes For buildings over 25+ years?",
      "options": {
        "a": "covers restaurant loss of income if a major customer is lost",
        "b": "1. Fire/Lightning",
        "c": "This clause extends coverage under the commercial property to include",
        "d": "Acts of violence or threatened violence must be present",
        "e": "check roof, wiring, breakers, plumbing, heating"
      },
      "answer": "e",
      "answer_text": "check roof, wiring, breakers, plumbing, heating",
      "explanation": "E: check roof, wiring, breakers, plumbing, heating"
    },
    {
      "id": 175,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Underwriting Activities?",
      "options": {
        "a": "Cash price value in a fair market, allow for depreciation",
        "b": "unless its directly by a peril",
        "c": "1. Risk Selection",
        "d": "Provides means of ensuring predictable increases in stock values in advance.",
        "e": "alerts broker to possible loss exposures, ensures needed coverages are not"
      },
      "answer": "c",
      "answer_text": "1. Risk Selection",
      "explanation": "C: 1. Risk Selection"
    },
    {
      "id": 176,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes 1. Risk Selection?",
      "options": {
        "a": "includes following perils",
        "b": "Primary duty is to select risks most profitable to the company. Improper screening can",
        "c": "Coverage only at premises",
        "d": "expert opinion of licensed real estate appraiser",
        "e": "each rider identifies and defines classes of property such as"
      },
      "answer": "b",
      "answer_text": "Primary duty is to select risks most profitable to the company. Improper screening can",
      "explanation": "B: Primary duty is to select risks most profitable to the company. Improper screening can"
    },
    {
      "id": 177,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes 2. Risk Classification?",
      "options": {
        "a": "Resale success",
        "b": "Grouping risks based on categories on their probability for a loss.",
        "c": "Pays costs for auditors to certify and prove the loss.",
        "d": "owner controls system and is not required to inform the",
        "e": "2. Debris Removal Clause"
      },
      "answer": "b",
      "answer_text": "Grouping risks based on categories on their probability for a loss.",
      "explanation": "B: Grouping risks based on categories on their probability for a loss."
    },
    {
      "id": 178,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Helps determine proper premium?",
      "options": {
        "a": "b) Flood - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,",
        "b": "1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or",
        "c": "materials to store data",
        "d": "3. Rate-Making - factors that influence the premium are application info, internal and",
        "e": "Resale success"
      },
      "answer": "d",
      "answer_text": "3. Rate-Making - factors that influence the premium are application info, internal and",
      "explanation": "D: 3. Rate-Making - factors that influence the premium are application info, internal and"
    },
    {
      "id": 179,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes 3. Rate-Making?",
      "options": {
        "a": "a false statement made knowing to be false",
        "b": "factors that influence the premium are application info, internal and",
        "c": "increases building insurance during the policy period to reflect",
        "d": "2. Electronic protection - magnetic door, window contacts, motion detectors",
        "e": "is the insured or a partner of the insured or any employee with care outside"
      },
      "answer": "b",
      "answer_text": "factors that influence the premium are application info, internal and",
      "explanation": "B: factors that influence the premium are application info, internal and"
    },
    {
      "id": 180,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Organization?",
      "options": {
        "a": "wrongful taking by force or fear. Includes unlawful act witnessed by custodian",
        "b": "steel doors, locks, bars",
        "c": "Hard Market - characterized by an increase in the loss ratio bought on by low rates in a",
        "d": "can be for single projects or installation. But will be mostly issued on an",
        "e": "Insurers will pay a loss even when they cannot tie an employee to a loss."
      },
      "answer": "c",
      "answer_text": "Hard Market - characterized by an increase in the loss ratio bought on by low rates in a",
      "explanation": "C: Hard Market - characterized by an increase in the loss ratio bought on by low rates in a"
    },
    {
      "id": 181,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Hard Market?",
      "options": {
        "a": "Ordinary Payroll Exclusion",
        "b": "items specifically identified on policy",
        "c": "characterized by an increase in the loss ratio bought on by low rates in a",
        "d": "the inertia of a body that tends to move away from center it revolves",
        "e": "will continue during the interruption such as accounts payables, mortgage,"
      },
      "answer": "c",
      "answer_text": "characterized by an increase in the loss ratio bought on by low rates in a",
      "explanation": "C: characterized by an increase in the loss ratio bought on by low rates in a"
    },
    {
      "id": 182,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Soft Market?",
      "options": {
        "a": "fire-resistive, non combustible, heavy timber, ordinary,",
        "b": "intense competition between insurers resulting in unusually low rates.",
        "c": "owner controls system and is not required to inform the",
        "d": "Each insurer contracts with the insured for a specific limit of liability",
        "e": "fair and reasonable price property would be on the market minus"
      },
      "answer": "b",
      "answer_text": "intense competition between insurers resulting in unusually low rates.",
      "explanation": "B: intense competition between insurers resulting in unusually low rates."
    },
    {
      "id": 183,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 4. Policy Service?",
      "options": {
        "a": "By-Laws Exclusion - can be endorsed, but having to comply with building by-laws is not",
        "b": "By-Laws Coverage - when complying to by-laws results in an increase in time to",
        "c": "Obsolescence",
        "d": "Contains 5 Insuring Agreements (insured can select any or all coverages and are continuous",
        "e": "preparation of original policy, changes requiring endorsements, billing"
      },
      "answer": "e",
      "answer_text": "preparation of original policy, changes requiring endorsements, billing",
      "explanation": "E: preparation of original policy, changes requiring endorsements, billing"
    },
    {
      "id": 184,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes of premiums?",
      "options": {
        "a": "By-Laws Exclusion - can be endorsed, but having to comply with building by-laws is not",
        "b": "Three Ways Property Can Be Valued:",
        "c": "Chapter 2 KEY TERMS",
        "d": "when complying to by-laws results in an increase in time to",
        "e": "Additions or changes to rented premises by a tenant at his/her own expense."
      },
      "answer": "c",
      "answer_text": "Chapter 2 KEY TERMS",
      "explanation": "C: Chapter 2 KEY TERMS"
    },
    {
      "id": 185,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Chapter 2 KEY TERMS?",
      "options": {
        "a": "1. Risk Selection",
        "b": "Common Hazards - certain hazards or conditions to all buildings that influence their",
        "c": "Wages In Lieu of Notice Endorsement - coverage can be provided for the wages of",
        "d": "Scheduled - when property is itemized with a limit each",
        "e": "including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,"
      },
      "answer": "b",
      "answer_text": "Common Hazards - certain hazards or conditions to all buildings that influence their",
      "explanation": "B: Common Hazards - certain hazards or conditions to all buildings that influence their"
    },
    {
      "id": 186,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Common Hazards?",
      "options": {
        "a": "Adds coverage for other perils and is available on blanket or scheduled basis.",
        "b": "certain hazards or conditions to all buildings that influence their",
        "c": "Subscription",
        "d": "Covers property at location not indicated only when it is necessary to",
        "e": "3. Builder’s Risk - available in broad form or named perils"
      },
      "answer": "b",
      "answer_text": "certain hazards or conditions to all buildings that influence their",
      "explanation": "B: certain hazards or conditions to all buildings that influence their"
    },
    {
      "id": 187,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes potential for loss?",
      "options": {
        "a": "All risks basis",
        "b": "Detachment - distance between insured property and other commercially rated",
        "c": "the amount of insurance is only an estimate, the amount of payment",
        "d": "2 - Peril causing damage to the neighbor was insured under the insured’s own policy.",
        "e": "Data Exclusion"
      },
      "answer": "b",
      "answer_text": "Detachment - distance between insured property and other commercially rated",
      "explanation": "B: Detachment - distance between insured property and other commercially rated"
    },
    {
      "id": 188,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Detachment?",
      "options": {
        "a": "Insures goods usual to the business.",
        "b": "indirect and not direct.",
        "c": "distance between insured property and other commercially rated",
        "d": "Ties together all four of the above approaches and considers:",
        "e": "negotiated when standard bill does not accurately reflect value of"
      },
      "answer": "c",
      "answer_text": "distance between insured property and other commercially rated",
      "explanation": "C: distance between insured property and other commercially rated"
    },
    {
      "id": 189,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Fire resistive/resistant?",
      "options": {
        "a": "No coverage for vehicles belonging to operating under insured or their",
        "b": "Damage from neglect of shipper, bad packaging, rough handling",
        "c": "No coverage when storing property of others, which can be endorsed through a",
        "d": "portion applies to in transit or within other premises",
        "e": "describes buildings that have met min standards hours"
      },
      "answer": "e",
      "answer_text": "describes buildings that have met min standards hours",
      "explanation": "E: describes buildings that have met min standards hours"
    },
    {
      "id": 190,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes withstanding controlled fire?",
      "options": {
        "a": "Non combustible - will not ignite or burn when subjected to fire",
        "b": "Money in vending machine or coin-operated machines",
        "c": "covers restaurant loss of income if a major customer is lost",
        "d": "Manually maintained records are blank value only + costs to copy from other source",
        "e": "Adds coverage for other perils and is available on blanket or scheduled basis."
      },
      "answer": "a",
      "answer_text": "Non combustible - will not ignite or burn when subjected to fire",
      "explanation": "A: Non combustible - will not ignite or burn when subjected to fire"
    },
    {
      "id": 191,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "type": "mcq",
      "question": "Which of the following best describes Non combustible?",
      "options": {
        "a": "charged based on annual receipts, and is provisional. Insured required to",
        "b": "Covers actual cost of reproduction",
        "c": "will not ignite or burn when subjected to fire",
        "d": "Non combustible - will not ignite or burn when subjected to fire",
        "e": "All risks basis"
      },
      "answer": "c",
      "answer_text": "will not ignite or burn when subjected to fire",
      "explanation": "C: will not ignite or burn when subjected to fire"
    },
    {
      "id": 192,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes CHAPTER 3: COMMERCIAL PROPERTY POLICY?",
      "options": {
        "a": "FIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model",
        "b": "Cash value to replace",
        "c": "Unoccupied - lack of habitual presence. Complete with contents but owner is absent.",
        "d": "Includes expenses for removing debris of insured property or property blown into",
        "e": "Total Limits of property in the custody of all sales"
      },
      "answer": "a",
      "answer_text": "FIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model",
      "explanation": "A: FIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model"
    },
    {
      "id": 193,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes FIRE POLICY?",
      "options": {
        "a": "narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model",
        "b": "Perils Excluded",
        "c": "3 ways to insure commercial property",
        "d": "Does not apply if property is insured by the owner unless he is obligated to insure it",
        "e": "Income approach"
      },
      "answer": "a",
      "answer_text": "narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model",
      "explanation": "A: narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model"
    },
    {
      "id": 194,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes manufactured gas?",
      "options": {
        "a": "Replacement value",
        "b": "Primary duty is to select risks most profitable to the company. Improper screening can",
        "c": "Ordinary Payroll - Limited Coverage - 90 or 180 day Option",
        "d": "Perils Excluded",
        "e": "Usually covers if its named perils/theft - this extends the definition to other causes of"
      },
      "answer": "d",
      "answer_text": "Perils Excluded",
      "explanation": "D: Perils Excluded"
    },
    {
      "id": 195,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Perils Excluded?",
      "options": {
        "a": "Scheduled - items specifically identified on policy",
        "b": "1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or",
        "c": "Replacement shall be on the same or adjacent site",
        "d": "Contractor’s tools and equipment",
        "e": "Actual Cash Value - fair and reasonable price property would be on the market minus"
      },
      "answer": "b",
      "answer_text": "1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or",
      "explanation": "B: 1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or"
    },
    {
      "id": 196,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 2. Application of heat?",
      "options": {
        "a": "if business is sold, coverage does not extend to the new",
        "b": "ONLY applies to building damage",
        "c": "considered in control of insured and are trade risks. Except if fire",
        "d": "Grouping risks based on categories on their probability for a loss.",
        "e": "Provides means of ensuring predictable increases in stock values in advance."
      },
      "answer": "c",
      "answer_text": "considered in control of insured and are trade risks. Except if fire",
      "explanation": "C: considered in control of insured and are trade risks. Except if fire"
    },
    {
      "id": 197,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes spreads beyond excluded property to other property insured?",
      "options": {
        "a": "Portable wall dividers separating work areas in a sales office",
        "b": "narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model",
        "c": "deterioration caused by ordinary and reasonable use of subject matter.",
        "d": "duplicating sensitive data/storing off premises, requiring two",
        "e": "3. War, Invasion, act of foreign enemy"
      },
      "answer": "e",
      "answer_text": "3. War, Invasion, act of foreign enemy",
      "explanation": "E: 3. War, Invasion, act of foreign enemy"
    },
    {
      "id": 198,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3. War, Invasion, act of foreign enemy?",
      "options": {
        "a": "Items that are covered",
        "b": "explosion of boilers",
        "c": "portion applies to in transit or within other premises",
        "d": "owner controls it and do not send to a control center.",
        "e": "4. Nuclear Incident. Except for loss or damage directly results from named peril"
      },
      "answer": "e",
      "answer_text": "4. Nuclear Incident. Except for loss or damage directly results from named peril",
      "explanation": "E: 4. Nuclear Incident. Except for loss or damage directly results from named peril"
    },
    {
      "id": 199,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Property Excluded?",
      "options": {
        "a": "Pays costs for auditors to certify and prove the loss.",
        "b": "coverage can be provided for the wages of",
        "c": "document issued by insurer that adds coverages.",
        "d": "3. Impact by aircraft/land vehicle",
        "e": "1. Money, Bullion, Precious Metals, Securities, Stamps - excluded due to high exposure"
      },
      "answer": "e",
      "answer_text": "1. Money, Bullion, Precious Metals, Securities, Stamps - excluded due to high exposure",
      "explanation": "E: 1. Money, Bullion, Precious Metals, Securities, Stamps - excluded due to high exposure"
    },
    {
      "id": 200,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 1. Money, Bullion, Precious Metals, Securities, Stamps?",
      "options": {
        "a": "Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are",
        "b": "g) Automobiles/watercraft - only insured if held on sale as stock or unlicensed for",
        "c": "failure in electrical mechanism",
        "d": "covers the cost of removing debris of the property after loss. Shall not",
        "e": "excluded due to high exposure"
      },
      "answer": "e",
      "answer_text": "excluded due to high exposure",
      "explanation": "E: excluded due to high exposure"
    },
    {
      "id": 201,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 2. Automobiles/Watercraft?",
      "options": {
        "a": "certain hazards or conditions to all buildings that influence their",
        "b": "except for sale as stock and except on the premises",
        "c": "if business is sold, coverage does not extend to the new",
        "d": "k) Nuclear incident - except for ensuing loss caused by named peril.",
        "e": "Pays costs for auditors to certify and prove the loss."
      },
      "answer": "b",
      "answer_text": "except for sale as stock and except on the premises",
      "explanation": "B: except for sale as stock and except on the premises"
    },
    {
      "id": 202,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes unlicensed used as in the business?",
      "options": {
        "a": "can be endorsed.",
        "b": "Property sold under written deferred payment plan agreement",
        "c": "period of vacancy specified on form. Duration is on underwriter’s discretion",
        "d": "Controlled by the primary insurer",
        "e": "3. Property at locations with the knowledge is vacant or unoccupied for more than 30"
      },
      "answer": "e",
      "answer_text": "3. Property at locations with the knowledge is vacant or unoccupied for more than 30",
      "explanation": "E: 3. Property at locations with the knowledge is vacant or unoccupied for more than 30"
    },
    {
      "id": 203,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes Extensions of Coverage?",
      "options": {
        "a": "1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation",
        "b": "Actual or attempted robbery of custodian",
        "c": "1. Removal Clause - Covers property at location not indicated only when it is necessary to",
        "d": "All risks basis",
        "e": "will continue during the interruption such as accounts payables, mortgage,"
      },
      "answer": "c",
      "answer_text": "1. Removal Clause - Covers property at location not indicated only when it is necessary to",
      "explanation": "C: 1. Removal Clause - Covers property at location not indicated only when it is necessary to"
    },
    {
      "id": 204,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes 1. Removal Clause?",
      "options": {
        "a": "Loss to systems (hardware)",
        "b": "Covers property at location not indicated only when it is necessary to",
        "c": "Rental value",
        "d": "Fact-Find Survey uses",
        "e": "contents removed also"
      },
      "answer": "b",
      "answer_text": "Covers property at location not indicated only when it is necessary to",
      "explanation": "B: Covers property at location not indicated only when it is necessary to"
    },
    {
      "id": 205,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes 2. Debris Removal?",
      "options": {
        "a": "2 Coverage Limits",
        "b": "Covers actual cost of reproduction",
        "c": "3 coverages",
        "d": "covers the cost of removing debris of the property after loss. Shall not",
        "e": "Blank value only if property is not replaced or reproduced"
      },
      "answer": "d",
      "answer_text": "covers the cost of removing debris of the property after loss. Shall not",
      "explanation": "D: covers the cost of removing debris of the property after loss. Shall not"
    },
    {
      "id": 206,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes NAMED PERILS?",
      "options": {
        "a": "failure in working mechanism",
        "b": "ONLY applies to building damage",
        "c": "includes following perils",
        "d": "Applies off premises but only the lesser of 10% or $5000",
        "e": "No coverage through aircraft taxied or moved"
      },
      "answer": "c",
      "answer_text": "includes following perils",
      "explanation": "C: includes following perils"
    },
    {
      "id": 207,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes NAMED PERILS - includes following perils?",
      "options": {
        "a": "Inherent Vice - something that naturally causes its own demise over time. Like",
        "b": "Inherent vice",
        "c": "Determining the need - assess potential for interruption due to loss.",
        "d": "1. Fire/Lightning",
        "e": "1. Forcible entry into building"
      },
      "answer": "d",
      "answer_text": "1. Fire/Lightning",
      "explanation": "D: 1. Fire/Lightning"
    },
    {
      "id": 208,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes 1. Fire/Lightning?",
      "options": {
        "a": "rate over and above the fire rate",
        "b": "a) Wear and tear, rust and corrosion, gradual deterioration",
        "c": "on standard policy, vacant/unoccupied is not covered after 30 days.",
        "d": "2. Explosion",
        "e": "magnetic door, window contacts, motion detectors"
      },
      "answer": "d",
      "answer_text": "2. Explosion",
      "explanation": "D: 2. Explosion"
    },
    {
      "id": 209,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes 2. Explosion?",
      "options": {
        "a": "Market value of before / after the loss",
        "b": "the cash value or cost to replace an item",
        "c": "Cost Approach",
        "d": "describes buildings that have met min standards hours",
        "e": "No coverage for loss/damage caused by explosion of boilers."
      },
      "answer": "e",
      "answer_text": "No coverage for loss/damage caused by explosion of boilers.",
      "explanation": "E: No coverage for loss/damage caused by explosion of boilers."
    },
    {
      "id": 210,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes manually portable gas cylinders?",
      "options": {
        "a": "Straight line / Plateau accelerated method",
        "b": "Resale success",
        "c": "Expert opinion",
        "d": "intense competition between insurers resulting in unusually low rates.",
        "e": "Excludes mechanical breakdown and centrifugal force"
      },
      "answer": "e",
      "answer_text": "Excludes mechanical breakdown and centrifugal force",
      "explanation": "E: Excludes mechanical breakdown and centrifugal force"
    },
    {
      "id": 211,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Excludes mechanical breakdown and centrifugal force?",
      "options": {
        "a": "k) Nuclear incident - except for ensuing loss caused by named peril.",
        "b": "Same as commercial building and stock named perils",
        "c": "6. Espionage",
        "d": "Subscription",
        "e": "3. Impact by aircraft/land vehicle"
      },
      "answer": "e",
      "answer_text": "3. Impact by aircraft/land vehicle",
      "explanation": "E: 3. Impact by aircraft/land vehicle"
    },
    {
      "id": 212,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes 3. Impact by aircraft/land vehicle?",
      "options": {
        "a": "the cash value or cost to replace an item",
        "b": "when income is produced from down buildings, net annual rent",
        "c": "Impact losses only",
        "d": "run -down buildings = net annual rent with a capitalization rate applied to it",
        "e": "Income approach"
      },
      "answer": "c",
      "answer_text": "Impact losses only",
      "explanation": "C: Impact losses only"
    },
    {
      "id": 213,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes Impact losses only?",
      "options": {
        "a": "negotiated when standard bill does not accurately reflect value of",
        "b": "No coverage for cumulative damage",
        "c": "Allows over-insured clause for premium refund. Claim must be within 6 months.",
        "d": "Insures while in custody of sales rep",
        "e": "ONLY applies to building damage"
      },
      "answer": "b",
      "answer_text": "No coverage for cumulative damage",
      "explanation": "B: No coverage for cumulative damage"
    },
    {
      "id": 214,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes No coverage for cumulative damage?",
      "options": {
        "a": "No coverage for vehicles belonging to operating under insured or their",
        "b": "3. Builder’s Risk - available in broad form or named perils",
        "c": "Cold Storage",
        "d": "Cash value to replace",
        "e": "This Covers: Amounts which cannot be collected AND Interest changes on any loan"
      },
      "answer": "a",
      "answer_text": "No coverage for vehicles belonging to operating under insured or their",
      "explanation": "A: No coverage for vehicles belonging to operating under insured or their"
    },
    {
      "id": 215,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 6: Crime Insurance",
      "type": "mcq",
      "question": "Which of the following best describes employees?",
      "options": {
        "a": "insured is entitled to 30 days notice of cancellation, 15 days if it is",
        "b": "Expert opinion",
        "c": "Increase in cost of construction",
        "d": "No coverage through aircraft taxied or moved",
        "e": "3 coverages"
      },
      "answer": "d",
      "answer_text": "No coverage through aircraft taxied or moved",
      "explanation": "D: No coverage through aircraft taxied or moved"
    },
    {
      "id": 216,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes No coverage through aircraft taxied or moved?",
      "options": {
        "a": "Increase in cost of construction",
        "b": "EXTENSIONS OF COVERAGE",
        "c": "Policy deductible is applied to each and every loss",
        "d": "each insurer contracts with the insured for a specific limit of liability. If one",
        "e": "Cash value to replace"
      },
      "answer": "c",
      "answer_text": "Policy deductible is applied to each and every loss",
      "explanation": "C: Policy deductible is applied to each and every loss"
    },
    {
      "id": 217,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes 4. Riot/Vandalism/Malicious Acts?",
      "options": {
        "a": "Additions or changes to rented premises by a tenant at his/her own expense.",
        "b": "Mechanical/electrical breakdown",
        "c": "Loss of value of the undamaged portion of the building",
        "d": "Acts of violence or threatened violence must be present",
        "e": "POED - A single limit of insurance is stated on the policy"
      },
      "answer": "d",
      "answer_text": "Acts of violence or threatened violence must be present",
      "explanation": "D: Acts of violence or threatened violence must be present"
    },
    {
      "id": 218,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following best describes No less than 3 people involved?",
      "options": {
        "a": "Wear/tear/loss due to the designed operation",
        "b": "Clear and present danger",
        "c": "actual annual rents",
        "d": "Must make application for refund within 12 months of expiry of policy",
        "e": "Applies off premises but only the lesser of 10% or $5000"
      },
      "answer": "b",
      "answer_text": "Clear and present danger",
      "explanation": "B: Clear and present danger"
    },
    {
      "id": 219,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "type": "mcq",
      "question": "Which of the following best describes Clear and present danger?",
      "options": {
        "a": "contents removed also",
        "b": "Scheduled - when property is itemized with a limit each",
        "c": "When damage is to media/data ONLY, business interruption is limited to 30 days max",
        "d": "Excludes mechanical breakdown and centrifugal force",
        "e": "EXCLUDES liability due to cessation of work, theft/attempted theft, flood or"
      },
      "answer": "e",
      "answer_text": "EXCLUDES liability due to cessation of work, theft/attempted theft, flood or",
      "explanation": "E: EXCLUDES liability due to cessation of work, theft/attempted theft, flood or"
    },
    {
      "id": 220,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "type": "mcq",
      "question": "Which of the following best describes 5. Smoke?",
      "options": {
        "a": "Cost of making goods that are faulty and improper design/workmanship/material",
        "b": "used in low risk commercial operations. The owner",
        "c": "adjusted based on reported values at the end of the",
        "d": "Sudden, unusual and faulty release of smoke.",
        "e": "the insurer retains the right to step into the shoes of the insured and sue"
      },
      "answer": "d",
      "answer_text": "Sudden, unusual and faulty release of smoke.",
      "explanation": "D: Sudden, unusual and faulty release of smoke."
    },
    {
      "id": 221,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to Three Ways Property Can Be Valued:?",
      "options": {
        "a": "Electronic Data Processing",
        "b": "Actual Cash Value - cost of repair, replace or rebuild minus depreciation",
        "c": "Must identify peak seasons ahead of time.",
        "d": "All risks basis",
        "e": "Perils broader."
      },
      "answer": "b",
      "answer_text": "Actual Cash Value - cost of repair, replace or rebuild minus depreciation",
      "explanation": "B: Actual Cash Value - cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": 222,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to Three Ways Property Can Be Valued:?",
      "options": {
        "a": "Ensures same perils as property policy",
        "b": "Replacement Value - same as above, without depreciation deduction.",
        "c": "Fire/Lightning",
        "d": "Does not apply if property is insured by the owner unless he is obligated to insure it",
        "e": "Installation Floater Rider"
      },
      "answer": "b",
      "answer_text": "Replacement Value - same as above, without depreciation deduction.",
      "explanation": "B: Replacement Value - same as above, without depreciation deduction."
    },
    {
      "id": 223,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to Defines basis for valuation of losses for different CLASS of property?",
      "options": {
        "a": "Insures loss due to forgery of cheque, draft, or any written promise.",
        "b": "Unsold Stock - ACV",
        "c": "Determining the type - 2 key factors",
        "d": "Either owner or contractor can purchase this.",
        "e": "Adds coverage for other perils and is available on blanket or scheduled basis."
      },
      "answer": "b",
      "answer_text": "Unsold Stock - ACV",
      "explanation": "B: Unsold Stock - ACV"
    },
    {
      "id": 224,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to Defines basis for valuation of losses for different CLASS of property?",
      "options": {
        "a": "Sold Stock - selling price less the discounts",
        "b": "Premium charged is based on the completed value of the project.",
        "c": "Determining the need - assess potential for interruption due to loss.",
        "d": "Coverage only at premises",
        "e": "No coverage for breakdown of refrigeration."
      },
      "answer": "a",
      "answer_text": "Sold Stock - selling price less the discounts",
      "explanation": "A: Sold Stock - selling price less the discounts"
    },
    {
      "id": 225,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to separate amounts each?",
      "options": {
        "a": "Pays costs for auditors to certify and prove the loss.",
        "b": "Either owner or contractor can purchase this.",
        "c": "Scheduled - when property is itemized with a limit each",
        "d": "Wear and tear - deterioration caused by ordinary and reasonable use of subject matter.",
        "e": "Increase in cost of construction"
      },
      "answer": "c",
      "answer_text": "Scheduled - when property is itemized with a limit each",
      "explanation": "C: Scheduled - when property is itemized with a limit each"
    },
    {
      "id": 226,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to separate amounts each?",
      "options": {
        "a": "Peak Season Endorsement",
        "b": "Sign Form",
        "c": "Dishonest/criminal act for insured or its employees. Except for bailees",
        "d": "This Covers: Amounts which cannot be collected AND Interest changes on any loan",
        "e": "Replacement Value - the cash value or cost to replace an item"
      },
      "answer": "e",
      "answer_text": "Replacement Value - the cash value or cost to replace an item",
      "explanation": "E: Replacement Value - the cash value or cost to replace an item"
    },
    {
      "id": 227,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to - Condition - a condition imposed to do or not do something?",
      "options": {
        "a": "Must select the amount of insurance for EACH vehicle. Coverage in VEHICLE",
        "b": "Form A - has one limit for all employees. Discovery period of 1 year.",
        "c": "Warranty - a promise that certain facts are true and will remain so.",
        "d": "Mechanical Breakdown - failure in working mechanism",
        "e": "Coverage is less expensive."
      },
      "answer": "c",
      "answer_text": "Warranty - a promise that certain facts are true and will remain so.",
      "explanation": "C: Warranty - a promise that certain facts are true and will remain so."
    },
    {
      "id": 228,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to - Condition - a condition imposed to do or not do something?",
      "options": {
        "a": "Shoplifting",
        "b": "Electronic Data Processing",
        "c": "Both the owner of the property and the bailee has insurable interest",
        "d": "Contract of indemnity - amount of loss is influenced by economic conditions and trends.",
        "e": "Fraudulent Misrepresentation - a false statement made knowing to be false"
      },
      "answer": "e",
      "answer_text": "Fraudulent Misrepresentation - a false statement made knowing to be false",
      "explanation": "E: Fraudulent Misrepresentation - a false statement made knowing to be false"
    },
    {
      "id": 229,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to it or not?",
      "options": {
        "a": "Contract of indemnity - amount of loss is influenced by economic conditions and trends.",
        "b": "When damage is to media/data ONLY, business interruption is limited to 30 days max",
        "c": "Types of good must be stated on the form.",
        "d": "Repair or replace with property of like kind and quality",
        "e": "Subrogation - step into the shoes of the party compensated and sue"
      },
      "answer": "e",
      "answer_text": "Subrogation - step into the shoes of the party compensated and sue",
      "explanation": "E: Subrogation - step into the shoes of the party compensated and sue"
    },
    {
      "id": 230,
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "type": "mcq",
      "question": "Which of the following applies to it or not?",
      "options": {
        "a": "Employee Dishonesty",
        "b": "Subscription Policy - group of insurers participating in a policy",
        "c": "By-Laws",
        "d": "Kidnapping",
        "e": "Book Value - original purchase price minus depreciation and other write-offs. Not"
      },
      "answer": "b",
      "answer_text": "Subscription Policy - group of insurers participating in a policy",
      "explanation": "B: Subscription Policy - group of insurers participating in a policy"
    }
  ],
  "fill": [
    {
      "id": "F1",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - cost of repair, replace or rebuild minus depreciation",
      "answer": "Actual Cash Value",
      "explanation": "Actual Cash Value - cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": "F2",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - same as above, without depreciation deduction.",
      "answer": "Replacement Value",
      "explanation": "Replacement Value - same as above, without depreciation deduction."
    },
    {
      "id": "F3",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - original purchase price minus depreciation and other write-offs. Not appropriate for insurance values.",
      "answer": "Book Value",
      "explanation": "Book Value - original purchase price minus depreciation and other write-offs. Not appropriate for insurance values."
    },
    {
      "id": "F4",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - determine the R/C of the property, then subtract rate of depreciation determined by either the straight line or plateau method.",
      "answer": "Formula/Cost Approach",
      "explanation": "Formula/Cost Approach - determine the R/C of the property, then subtract rate of depreciation determined by either the straight line or plateau method."
    },
    {
      "id": "F5",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - expert opinion of licensed real estate appraiser as to the fair market value of property before and after loss and the value of the land",
      "answer": "Market Value/Direct Sales Approach",
      "explanation": "Market Value/Direct Sales Approach - expert opinion of licensed real estate appraiser as to the fair market value of property before and after loss and the value of the land"
    },
    {
      "id": "F6",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - when income is produced from down buildings, net annual rent income is determined and capitalization rate is applied to it.",
      "answer": "Income Approach",
      "explanation": "Income Approach - when income is produced from down buildings, net annual rent income is determined and capitalization rate is applied to it."
    },
    {
      "id": "F7",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - when insureds claim the previous three methods have failed to consider special circumstances.",
      "answer": "True to Owner",
      "explanation": "True to Owner - when insureds claim the previous three methods have failed to consider special circumstances."
    },
    {
      "id": "F8",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - ties together all four of the above.",
      "answer": "Broad Evidence Rule",
      "explanation": "Broad Evidence Rule - ties together all four of the above."
    },
    {
      "id": "F9",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - all insurers share in both premiums collected and losses incurred. The contract is between the primary insurer and reinsurerer.",
      "answer": "Reinsurance",
      "explanation": "Reinsurance - all insurers share in both premiums collected and losses incurred. The contract is between the primary insurer and reinsurerer."
    },
    {
      "id": "F10",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - each insurer contracts with the insured for a specific limit of liability. If one denies the claim, others don't need to follow along.",
      "answer": "Subscription",
      "explanation": "Subscription - each insurer contracts with the insured for a specific limit of liability. If one denies the claim, others don't need to follow along."
    },
    {
      "id": "F11",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - the insured must file a statement of values with the insurer representing 100% of the value of all property as insured as verified by appraisal and maintain those values throughout the term.",
      "answer": "Stated Amount of Co-Insurance Clause",
      "explanation": "Stated Amount of Co-Insurance Clause - the insured must file a statement of values with the insurer representing 100% of the value of all property as insured as verified by appraisal and maintain those values throughout the term."
    },
    {
      "id": "F12",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - insureds will have as much insurance after a loss as they did before it.",
      "answer": "Reinstatement Clause",
      "explanation": "Reinstatement Clause - insureds will have as much insurance after a loss as they did before it."
    },
    {
      "id": "F13",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - the insurer retains the right to step into the shoes of the insured and sue the responsible party.",
      "answer": "Subrogation",
      "explanation": "Subrogation - the insurer retains the right to step into the shoes of the insured and sue the responsible party."
    },
    {
      "id": "F14",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - insured needs to notify of any interruption to, or flaw or defect. When the contract isn’t renewed or is cancelled and when police notify suspension of the protection system.",
      "answer": "Property Protection Systems",
      "explanation": "Property Protection Systems - insured needs to notify of any interruption to, or flaw or defect. When the contract isn’t renewed or is cancelled and when police notify suspension of the protection system."
    },
    {
      "id": "F15",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - enter the insured’s premises at all reasonable times to inspect. Insurers can determine values are reasonable and actually exist.",
      "answer": "Verification of Values",
      "explanation": "Verification of Values - enter the insured’s premises at all reasonable times to inspect. Insurers can determine values are reasonable and actually exist."
    },
    {
      "id": "F16",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - selling price less the discounts",
      "answer": "Sold Stock",
      "explanation": "Sold Stock - selling price less the discounts"
    },
    {
      "id": "F17",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - fair and reasonable price property would be on the market minus",
      "answer": "Actual Cash Value",
      "explanation": "Actual Cash Value - fair and reasonable price property would be on the market minus"
    },
    {
      "id": "F18",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - policy of insurance that covers two or more items without listing",
      "answer": "All property (blanket)",
      "explanation": "All property (blanket) - policy of insurance that covers two or more items without listing"
    },
    {
      "id": "F19",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - when property is itemized with a limit each",
      "answer": "Scheduled",
      "explanation": "Scheduled - when property is itemized with a limit each"
    },
    {
      "id": "F20",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - the cash value or cost to replace an item",
      "answer": "Replacement Value",
      "explanation": "Replacement Value - the cash value or cost to replace an item"
    },
    {
      "id": "F21",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - method used to insure commercial building, stock and",
      "answer": "Property of every description",
      "explanation": "Property of every description - method used to insure commercial building, stock and"
    },
    {
      "id": "F22",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - additions or charges rented property at the expense of the tenant.",
      "answer": "Tenant’s improvements",
      "explanation": "Tenant’s improvements - additions or charges rented property at the expense of the tenant."
    },
    {
      "id": "F23",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - a condition imposed to do or not do something",
      "answer": "Condition",
      "explanation": "Condition - a condition imposed to do or not do something"
    },
    {
      "id": "F24",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - a promise that certain facts are true and will remain so.",
      "answer": "Warranty",
      "explanation": "Warranty - a promise that certain facts are true and will remain so."
    },
    {
      "id": "F25",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - a false statement made knowing to be false",
      "answer": "Fraudulent Misrepresentation",
      "explanation": "Fraudulent Misrepresentation - a false statement made knowing to be false"
    },
    {
      "id": "F26",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - a fact which if the insurer knew about, would affect the decision to insure",
      "answer": "Material Fact",
      "explanation": "Material Fact - a fact which if the insurer knew about, would affect the decision to insure"
    },
    {
      "id": "F27",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - step into the shoes of the party compensated and sue",
      "answer": "Subrogation",
      "explanation": "Subrogation - step into the shoes of the party compensated and sue"
    },
    {
      "id": "F28",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - group of insurers participating in a policy",
      "answer": "Subscription Policy",
      "explanation": "Subscription Policy - group of insurers participating in a policy"
    },
    {
      "id": "F29",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 1: Introduction",
      "question": "_____ - lacks an essential element to be enforceable by law",
      "answer": "Void contract",
      "explanation": "Void contract - lacks an essential element to be enforceable by law"
    },
    {
      "id": "F30",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - alerts broker to possible loss exposures, ensures needed coverages are not forgotten or ignored. Helps reduce potential E&O. Physical and Other Qualities of Commercial Risks",
      "answer": "Checklist",
      "explanation": "Checklist - alerts broker to possible loss exposures, ensures needed coverages are not forgotten or ignored. Helps reduce potential E&O. Physical and Other Qualities of Commercial Risks"
    },
    {
      "id": "F31",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - fire-resistive, non combustible, heavy timber, ordinary,",
      "answer": "Building materials best to worst",
      "explanation": "Building materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,"
    },
    {
      "id": "F32",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - check roof, wiring, breakers, plumbing, heating",
      "answer": "For buildings over 25+ years",
      "explanation": "For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating"
    },
    {
      "id": "F33",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - factors that influence the premium are application info, internal and external sources of info, field investigations, rates suggested by Insurer’s Advisory",
      "answer": "Rate-Making",
      "explanation": "Rate-Making - factors that influence the premium are application info, internal and external sources of info, field investigations, rates suggested by Insurer’s Advisory"
    },
    {
      "id": "F34",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - characterized by an increase in the loss ratio bought on by low rates in a soft market, forcing out some of the competition. Insurers are selective about risks, rates are higher, underwriting is disciplined.",
      "answer": "Hard Market",
      "explanation": "Hard Market - characterized by an increase in the loss ratio bought on by low rates in a soft market, forcing out some of the competition. Insurers are selective about risks, rates are higher, underwriting is disciplined."
    },
    {
      "id": "F35",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - intense competition between insurers resulting in unusually low rates.",
      "answer": "Soft Market",
      "explanation": "Soft Market - intense competition between insurers resulting in unusually low rates."
    },
    {
      "id": "F36",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - preparation of original policy, changes requiring endorsements, billing",
      "answer": "Policy Service",
      "explanation": "Policy Service - preparation of original policy, changes requiring endorsements, billing"
    },
    {
      "id": "F37",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - certain hazards or conditions to all buildings that influence their",
      "answer": "Common Hazards",
      "explanation": "Common Hazards - certain hazards or conditions to all buildings that influence their"
    },
    {
      "id": "F38",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - distance between insured property and other commercially rated exposures.",
      "answer": "Detachment",
      "explanation": "Detachment - distance between insured property and other commercially rated exposures."
    },
    {
      "id": "F39",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - describes buildings that have met min standards hours",
      "answer": "Fire resistive/resistant",
      "explanation": "Fire resistive/resistant - describes buildings that have met min standards hours"
    },
    {
      "id": "F40",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 2: Underwriting",
      "question": "_____ - will not ignite or burn when subjected to fire",
      "answer": "Non combustible",
      "explanation": "Non combustible - will not ignite or burn when subjected to fire"
    },
    {
      "id": "F41",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model for broader coverage forms.",
      "answer": "FIRE POLICY",
      "explanation": "FIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model for broader coverage forms."
    },
    {
      "id": "F42",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - considered in control of insured and are trade risks. Except if fire spreads beyond excluded property to other property insured",
      "answer": "Application of heat",
      "explanation": "Application of heat - considered in control of insured and are trade risks. Except if fire spreads beyond excluded property to other property insured"
    },
    {
      "id": "F43",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - excluded due to high exposure and difficult to verify amounts claimed.",
      "answer": "Money, Bullion, Precious Metals, Securities, Stamps",
      "explanation": "Money, Bullion, Precious Metals, Securities, Stamps - excluded due to high exposure and difficult to verify amounts claimed."
    },
    {
      "id": "F44",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - except for sale as stock and except on the premises",
      "answer": "Automobiles/Watercraft",
      "explanation": "Automobiles/Watercraft - except for sale as stock and except on the premises"
    },
    {
      "id": "F45",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - Covers property at location not indicated only when it is necessary to prevent loss. Amount of coverage at the unnamed location is limited to insurance remaining after payment after the insured original location. Least of 7 days or unexpired term.",
      "answer": "Removal Clause",
      "explanation": "Removal Clause - Covers property at location not indicated only when it is necessary to prevent loss. Amount of coverage at the unnamed location is limited to insurance remaining after payment after the insured original location. Least of 7 days or unexpired term."
    },
    {
      "id": "F46",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - covers the cost of removing debris of the property after loss. Shall not exceed 25% of the total amount payable.",
      "answer": "Debris Removal",
      "explanation": "Debris Removal - covers the cost of removing debris of the property after loss. Shall not exceed 25% of the total amount payable."
    },
    {
      "id": "F47",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - includes following perils",
      "answer": "NAMED PERILS",
      "explanation": "NAMED PERILS - includes following perils"
    },
    {
      "id": "F48",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - most extensive form. The policy is defined by exclusions",
      "answer": "BROAD FORM",
      "explanation": "BROAD FORM - most extensive form. The policy is defined by exclusions"
    },
    {
      "id": "F49",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - except when due to named peril or theft/attempted theft",
      "answer": "e) Animals/fish/birds",
      "explanation": "e) Animals/fish/birds - except when due to named peril or theft/attempted theft"
    },
    {
      "id": "F50",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - must be insured separately",
      "answer": "f) Money/bullion/precious metals",
      "explanation": "f) Money/bullion/precious metals - must be insured separately"
    },
    {
      "id": "F51",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - only insured if held on sale as stock or unlicensed for business purposes on the premises.",
      "answer": "g) Automobiles/watercraft",
      "explanation": "g) Automobiles/watercraft - only insured if held on sale as stock or unlicensed for business purposes on the premises."
    },
    {
      "id": "F52",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - loss does not apply to first $1000 of any loss and does not",
      "answer": "h) Fur/garments/jewellery",
      "explanation": "h) Fur/garments/jewellery - loss does not apply to first $1000 of any loss and does not"
    },
    {
      "id": "F53",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - loss caused by earthquake. Except for ensuing loss or damage which results directly from fire, explosion, smoke or leakage",
      "answer": "a) Earthquake",
      "explanation": "a) Earthquake - loss caused by earthquake. Except for ensuing loss or damage which results directly from fire, explosion, smoke or leakage"
    },
    {
      "id": "F54",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire, explosion, smoke or leakage. c) Seepage, leakage or influx of water from natural sources. d) Centrifugal force, mechanical, electrical breakdown. Unless fire ensues, which then",
      "answer": "b) Flood",
      "explanation": "b) Flood - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire, explosion, smoke or leakage. c) Seepage, leakage or influx of water from natural sources. d) Centrifugal force, mechanical, electrical breakdown. Unless fire ensues, which then"
    },
    {
      "id": "F55",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - unless its directly by a peril",
      "answer": "h) Rodents/insects/vermin",
      "explanation": "h) Rodents/insects/vermin - unless its directly by a peril"
    },
    {
      "id": "F56",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - indirect and not direct.",
      "answer": "i) Loss of market/delay",
      "explanation": "i) Loss of market/delay - indirect and not direct."
    },
    {
      "id": "F57",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - except for ensuing loss caused by named peril. l) Dishonest/criminal act for insured or its employees. Except for bailees",
      "answer": "k) Nuclear incident",
      "explanation": "k) Nuclear incident - except for ensuing loss caused by named peril. l) Dishonest/criminal act for insured or its employees. Except for bailees"
    },
    {
      "id": "F58",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - ONLY applies to building damage. Does not apply to property in transit.",
      "answer": "m) Snowslide, landslide",
      "explanation": "m) Snowslide, landslide - ONLY applies to building damage. Does not apply to property in transit."
    },
    {
      "id": "F59",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - ONLY applies to building damage",
      "answer": "n) Explosion/collapse/rupture",
      "explanation": "n) Explosion/collapse/rupture - ONLY applies to building damage"
    },
    {
      "id": "F60",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - ONLY applies to building damage",
      "answer": "o) Settling/Expansion/Contraction",
      "explanation": "o) Settling/Expansion/Contraction - ONLY applies to building damage"
    },
    {
      "id": "F61",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - no coverage for increased cost through enforcement of bylaw",
      "answer": "p) Bylaws",
      "explanation": "p) Bylaws - no coverage for increased cost through enforcement of bylaw"
    },
    {
      "id": "F62",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - hidden and concealed defect",
      "answer": "b) Latent defect",
      "explanation": "b) Latent defect - hidden and concealed defect"
    },
    {
      "id": "F63",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - something within a commodity that causes demise over time",
      "answer": "Inherent Vice",
      "explanation": "Inherent Vice - something within a commodity that causes demise over time"
    },
    {
      "id": "F64",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - allows personal property to fit into the",
      "answer": "Personal Property of Officers and Employees",
      "explanation": "Personal Property of Officers and Employees - allows personal property to fit into the"
    },
    {
      "id": "F65",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - provides coverage for damage to that part of the building occupied by the insured directly resulting from theft/attempted theft and vandalism.",
      "answer": "Building Damage by Theft",
      "explanation": "Building Damage by Theft - provides coverage for damage to that part of the building occupied by the insured directly resulting from theft/attempted theft and vandalism."
    },
    {
      "id": "F66",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - this extends the definition to other causes of loss.",
      "answer": "Usually covers if its named perils/theft",
      "explanation": "Usually covers if its named perils/theft - this extends the definition to other causes of loss."
    },
    {
      "id": "F67",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - lack of habitual presence. Complete with contents but owner is absent.",
      "answer": "Unoccupied",
      "explanation": "Unoccupied - lack of habitual presence. Complete with contents but owner is absent."
    },
    {
      "id": "F68",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - contents removed also",
      "answer": "Vacant",
      "explanation": "Vacant - contents removed also"
    },
    {
      "id": "F69",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - rate over and above the fire rate",
      "answer": "Loading",
      "explanation": "Loading - rate over and above the fire rate"
    },
    {
      "id": "F70",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - the inertia of a body that tends to move away from center it revolves",
      "answer": "Centrifugal Force",
      "explanation": "Centrifugal Force - the inertia of a body that tends to move away from center it revolves"
    },
    {
      "id": "F71",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - failure in working mechanism",
      "answer": "Mechanical Breakdown",
      "explanation": "Mechanical Breakdown - failure in working mechanism"
    },
    {
      "id": "F72",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - failure in electrical mechanism",
      "answer": "Electrical Breakdown",
      "explanation": "Electrical Breakdown - failure in electrical mechanism"
    },
    {
      "id": "F73",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - something that naturally causes its own demise over time. Like fruits/veggies.",
      "answer": "Inherent Vice",
      "explanation": "Inherent Vice - something that naturally causes its own demise over time. Like fruits/veggies."
    },
    {
      "id": "F74",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - a hidden or concealed defect which could not be discovered by",
      "answer": "Latent Defect",
      "explanation": "Latent Defect - a hidden or concealed defect which could not be discovered by"
    },
    {
      "id": "F75",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - types of losses expected from everyday operation",
      "answer": "Trade Losses",
      "explanation": "Trade Losses - types of losses expected from everyday operation"
    },
    {
      "id": "F76",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - deterioration caused by ordinary and reasonable use of subject matter.",
      "answer": "Wear and tear",
      "explanation": "Wear and tear - deterioration caused by ordinary and reasonable use of subject matter."
    },
    {
      "id": "F77",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - generally organized information for a purpose",
      "answer": "Data",
      "explanation": "Data - generally organized information for a purpose"
    },
    {
      "id": "F78",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - a piece of paper issued for a change in terms on the policy",
      "answer": "Endorsement",
      "explanation": "Endorsement - a piece of paper issued for a change in terms on the policy"
    },
    {
      "id": "F79",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - materials to store data",
      "answer": "Media",
      "explanation": "Media - materials to store data"
    },
    {
      "id": "F80",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 3: Commercial Property Policy",
      "question": "_____ - document issued by insurer that adds coverages.",
      "answer": "Rider",
      "explanation": "Rider - document issued by insurer that adds coverages."
    },
    {
      "id": "F81",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - maximum payable for any one accident",
      "answer": "Limit Per Liability",
      "explanation": "Limit Per Liability - maximum payable for any one accident"
    },
    {
      "id": "F82",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - covers any complete machine with processes forms,",
      "answer": "Production Machinery",
      "explanation": "Production Machinery - covers any complete machine with processes forms,"
    },
    {
      "id": "F83",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - loss of profit, gross earnings, rental income.",
      "answer": "Indirect Coverage",
      "explanation": "Indirect Coverage - loss of profit, gross earnings, rental income."
    },
    {
      "id": "F84",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - Cold Storage",
      "answer": "Consequential Loss Assumption Clause",
      "explanation": "Consequential Loss Assumption Clause - Cold Storage"
    },
    {
      "id": "F85",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - insures equipment and stock other than at the specific location.",
      "answer": "Temporary Locations",
      "explanation": "Temporary Locations - insures equipment and stock other than at the specific location."
    },
    {
      "id": "F86",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - While examined or used at customer for pre-sale trial, repairs at business of others or held for pickup at warehouse or depot",
      "answer": "ii.",
      "explanation": "ii. - While examined or used at customer for pre-sale trial, repairs at business of others or held for pickup at warehouse or depot"
    },
    {
      "id": "F87",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - protects the interests of business that sells goods on payment plans.",
      "answer": "Instalment Sales Contract Floater",
      "explanation": "Instalment Sales Contract Floater - protects the interests of business that sells goods on payment plans."
    },
    {
      "id": "F88",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - increases building insurance during the policy period to reflect increase in building costs.",
      "answer": "Inflation Protection",
      "explanation": "Inflation Protection - increases building insurance during the policy period to reflect increase in building costs."
    },
    {
      "id": "F89",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - on standard policy, vacant/unoccupied is not covered after 30 days. Two Types.",
      "answer": "Vacancy Permit",
      "explanation": "Vacancy Permit - on standard policy, vacant/unoccupied is not covered after 30 days. Two Types."
    },
    {
      "id": "F90",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - period of vacancy specified on form. Duration is on underwriter’s discretion",
      "answer": "Permit 1",
      "explanation": "Permit 1 - period of vacancy specified on form. Duration is on underwriter’s discretion"
    },
    {
      "id": "F91",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "question": "_____ - makes the insured co-insurer in all fire and lightning loss",
      "answer": "Permit 2",
      "explanation": "Permit 2 - makes the insured co-insurer in all fire and lightning loss"
    },
    {
      "id": "F92",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - when purchased, the bailee accepts all responsibility for customer’s goods and legal liability is not a concern.",
      "answer": "Specialized Bailee’s Customers Policy",
      "explanation": "Specialized Bailee’s Customers Policy - when purchased, the bailee accepts all responsibility for customer’s goods and legal liability is not a concern."
    },
    {
      "id": "F93",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - reflects amount liable under the tariff",
      "answer": "Standard Bill of Lading",
      "explanation": "Standard Bill of Lading - reflects amount liable under the tariff"
    },
    {
      "id": "F94",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - negotiated when standard bill does not accurately reflect value of",
      "answer": "Valued Bill of Lading",
      "explanation": "Valued Bill of Lading - negotiated when standard bill does not accurately reflect value of"
    },
    {
      "id": "F95",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - releases the carrier from liability of goods. Used when value of goods is less than standard bill of lading or value of goods exceeds the standard tariff.",
      "answer": "Released Bill of Lading",
      "explanation": "Released Bill of Lading - releases the carrier from liability of goods. Used when value of goods is less than standard bill of lading or value of goods exceeds the standard tariff."
    },
    {
      "id": "F96",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - all risks coverage. Designed to insure property owned by the insured, property which insured is responsible, property sold but not yet",
      "answer": "Transportation Floater (Broad Form)",
      "explanation": "Transportation Floater (Broad Form) - all risks coverage. Designed to insure property owned by the insured, property which insured is responsible, property sold but not yet"
    },
    {
      "id": "F97",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - adjusted based on reported values at the end of the policy term.",
      "answer": "Premium is provisional",
      "explanation": "Premium is provisional - adjusted based on reported values at the end of the policy term."
    },
    {
      "id": "F98",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - covers merchandise and goods sold by the insured and transported exclusively in the insured’s own vehicles.",
      "answer": "Motor Cargo Rider",
      "explanation": "Motor Cargo Rider - covers merchandise and goods sold by the insured and transported exclusively in the insured’s own vehicles."
    },
    {
      "id": "F99",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - used to insure transit of a single shipment. Amount of premium based on nature of property, distance, method of transport.",
      "answer": "Trip Transit Policy",
      "explanation": "Trip Transit Policy - used to insure transit of a single shipment. Amount of premium based on nature of property, distance, method of transport."
    },
    {
      "id": "F100",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - insures the insured’s liability as a carrier.",
      "answer": "Truckman’s Liability Cargo Rider",
      "explanation": "Truckman’s Liability Cargo Rider - insures the insured’s liability as a carrier."
    },
    {
      "id": "F101",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - the max. Amount insurer will pay for any one occurrence.",
      "answer": "There is a Catastrophe limit",
      "explanation": "There is a Catastrophe limit - the max. Amount insurer will pay for any one occurrence."
    },
    {
      "id": "F102",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - extends coverage to off premises use of tools. Has two forms",
      "answer": "Tool Floater Rider",
      "explanation": "Tool Floater Rider - extends coverage to off premises use of tools. Has two forms"
    },
    {
      "id": "F103",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - designed to insured movable equipment owned by contractors.",
      "answer": "Contractor’s Equipment Floater",
      "explanation": "Contractor’s Equipment Floater - designed to insured movable equipment owned by contractors."
    },
    {
      "id": "F104",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - coverage is provided for newly acquired equipment similar to the covered ones scheduled. Coverage ceases after 30 days and the amount of insurance is limited.",
      "answer": "Newly Acquired Equipment",
      "explanation": "Newly Acquired Equipment - coverage is provided for newly acquired equipment similar to the covered ones scheduled. Coverage ceases after 30 days and the amount of insurance is limited."
    },
    {
      "id": "F105",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - available in broad form or named perils",
      "answer": "Builder’s Risk",
      "explanation": "Builder’s Risk - available in broad form or named perils"
    },
    {
      "id": "F106",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - for contractors with more than one building at a time. Must provide an estimate of total and max of any particular project. A provisional premium will be charged and insured must abide by reporting requirements",
      "answer": "Blanket Policy",
      "explanation": "Blanket Policy - for contractors with more than one building at a time. Must provide an estimate of total and max of any particular project. A provisional premium will be charged and insured must abide by reporting requirements"
    },
    {
      "id": "F107",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - all risks, broadest available. This insured: a) Property in the course of construction/installation/reconstruction or repair. b) Landscaping, growing trees, plants to be entered into the building. c) Temporary buildings, scaffolding, falsework, forms.",
      "answer": "Broad Form",
      "explanation": "Broad Form - all risks, broadest available. This insured: a) Property in the course of construction/installation/reconstruction or repair. b) Landscaping, growing trees, plants to be entered into the building. c) Temporary buildings, scaffolding, falsework, forms."
    },
    {
      "id": "F108",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - limited to Canada and continental US",
      "answer": "In Transit",
      "explanation": "In Transit - limited to Canada and continental US"
    },
    {
      "id": "F109",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - building material stored at a location away from the project site.",
      "answer": "Any Other Location",
      "explanation": "Any Other Location - building material stored at a location away from the project site."
    },
    {
      "id": "F110",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - but has premium adjustments and reporting.",
      "answer": "Does not have co-insurance",
      "explanation": "Does not have co-insurance - but has premium adjustments and reporting."
    },
    {
      "id": "F111",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - can be for single projects or installation. But will be mostly issued on an annual basis.",
      "answer": "Basis of Coverage",
      "explanation": "Basis of Coverage - can be for single projects or installation. But will be mostly issued on an annual basis."
    },
    {
      "id": "F112",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 5: Misc. Property Forms",
      "question": "_____ - charged based on annual receipts, and is provisional. Insured required to report within 30 days of policy expiry.",
      "answer": "Premium basis",
      "explanation": "Premium basis - charged based on annual receipts, and is provisional. Insured required to report within 30 days of policy expiry."
    },
    {
      "id": "F113",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - steel doors, locks, bars",
      "answer": "Physical protection",
      "explanation": "Physical protection - steel doors, locks, bars"
    },
    {
      "id": "F114",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - magnetic door, window contacts, motion detectors",
      "answer": "Electronic protection",
      "explanation": "Electronic protection - magnetic door, window contacts, motion detectors"
    },
    {
      "id": "F115",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - methods used to secure access when business is closed. Range from none, partial and complete.",
      "answer": "Perimeter Protection",
      "explanation": "Perimeter Protection - methods used to secure access when business is closed. Range from none, partial and complete."
    },
    {
      "id": "F116",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - used to guard interior and restrict entry where valuables are stored. Physical can be bars and locks and electronic can be interior trapping devices, motion/heat detectors and CCTV.",
      "answer": "Area Protection",
      "explanation": "Area Protection - used to guard interior and restrict entry where valuables are stored. Physical can be bars and locks and electronic can be interior trapping devices, motion/heat detectors and CCTV."
    },
    {
      "id": "F117",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - direct security for individual items.",
      "answer": "Point Protection",
      "explanation": "Point Protection - direct security for individual items."
    },
    {
      "id": "F118",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - owner/employees control it, the weakness is they can forget to",
      "answer": "Locally Supervised",
      "explanation": "Locally Supervised - owner/employees control it, the weakness is they can forget to"
    },
    {
      "id": "F119",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - a central station ensures it is turned on at arranged times. Provides immediate notice to police.",
      "answer": "Central Station Supervised",
      "explanation": "Central Station Supervised - a central station ensures it is turned on at arranged times. Provides immediate notice to police."
    },
    {
      "id": "F120",
      "type": "fill",
      "source": "Study Sheet exact definition",
      "chapter": "Chapter 6: Crime Insurance",
      "question": "_____ - same as above, but no guard is dispatched.",
      "answer": "Monitoring Station Service",
      "explanation": "Monitoring Station Service - same as above, but no guard is dispatched."
    }
  ],
  "flashcards": [
    {
      "id": "C1",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "When insuring building, building, stock and equipment on an “all property-blanket” basis\na. All property owned by the insured is covered by a single limit of insurance\nb. Coverage is usually subject to a minimum 90% Co-insurance requirement\nc. Coverage limits can be extended to include property at more than one location\nd. All of the above\ne. None of the above",
      "back": "Ans: A\nAll property owned by the insured is covered by a single limit of insurance\nExplanation: A: All property owned by the insured is covered by a single limit of insurance"
    },
    {
      "id": "C2",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Your client, who operates the business out of leased premises, is undertaking major renovations which include new flooring, wall panelling and light fixtures. The total cost of the renovations which include new flooring, wall panelling and light fixtures. The total cost of the renovations is $25,000. You advise her that these values\na. Are insured under the landlord’s building insurance\nb. Must be added to her own policy as building coverage\nc. Must be added to equipment insured under her own policy\nd. Cannot be insured because she does not own the building\ne. None of the above",
      "back": "Ans: C\nMust be added to equipment insured under her own policy\nExplanation: C: Must be added to equipment insured under her own policy"
    },
    {
      "id": "C3",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following is not used in determining an amount of insurance for property?\na. Book Value\nb. True Value to the Owner\nc. Income Approach\nd. Market Value / Direct Sales Approach\ne. Broad Evidence Rule",
      "back": "Ans: A\nBook Value\nExplanation: A: Book Value"
    },
    {
      "id": "C4",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Insurers can use both Reinsurance and Subscription policies to limit their exposure on risks. Select the answer which best describes Reinsurance.\na. The insurer cedes part of the risk it has assumed to one or more insurers\nb. Each agreement is negotiated separately with the participating insurers\nc. The policy is controlled by the primary insurer and all claims are paid by it\nd. A and b\ne. A and c",
      "back": "Ans: E\nA and c\nExplanation: E: A and c"
    },
    {
      "id": "C5",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The amount of a claim payment made to the insured is\na. The least of the actual cash value, the interest of the insured, and the replacement cost\nb. Not limited to the amount of insurance specified\nc. The actual cash value, the interest of the insured, and the amount of insurance specified, whichever is the least\nd. Limited to the actual cash value only\ne. Always based on the replacement value",
      "back": "Ans: C\nThe actual cash value, the interest of the insured, and the amount of insurance specified, whichever is the least\nExplanation: C: The actual cash value, the interest of the insured, and the amount of insurance specified, whichever is the least"
    },
    {
      "id": "C6",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The co-insurance requirement is waived when\na. The loss is less than $5000\nb. The loss is more than $5000 but less than 2% of the amount of insurance\nc. The loss is less than the Actual Cash Value\nd. The loss is less than 2% of the amount of insurance and less than $5000\ne. None of the above",
      "back": "Ans: D\nThe loss is less than 2% of the amount of insurance and less than $5000\nExplanation: D: The loss is less than 2% of the amount of insurance and less than $5000"
    },
    {
      "id": "C7",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following does not apply to the stated amount co-insurance clause?\na. The stated amount co-insurance clause replaces the standard co-insurance clause normally contained in the policy\nb. The stated amount co-insurance clause does not require the insured to insure values to 100%\nc. The insured files a statement of values representing 100% of the value of the property insured\nd. Values are verified by appraisal or other means acceptable to the insurer\ne. The insured must maintain those values throughout the policy term",
      "back": "Ans: B\nThe stated amount co-insurance clause does not require the insured to insure values to 100%\nExplanation: B, only the standard co-insurance clause permits the amount of insurance to be less than 100% of the value of the property insured"
    },
    {
      "id": "C8",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The “property protection systems” clause requires the insured to:\na. Notify the insurer immediately when becoming aware of any interruption, flaw or defect in property protection systems\nb. Notify the insurer as soon as possible when becoming aware of any interruption, flaw or defect in property protection systems\nc. Notify the insurer within 30 days when becoming aware of any interruption, flaw or defect in property protection systems\nd. Notify the insurer within 15 days when becoming aware of any interruption, flaw or defect in property protection systems\ne. Notify the insurer immediately after repairs have been made",
      "back": "Ans: A\nNotify the insurer immediately when becoming aware of any interruption, flaw or defect in property protection systems\nExplanation: A: Notify the insurer immediately when becoming aware of any interruption, flaw or defect in property protection systems"
    },
    {
      "id": "C9",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The locked vehicle warranty:\na. Requires that the vehicle containing the property insured by equipped with a fully enclosed metal body or compartment of the vehicle\nb. Requires that the doors and windows of the vehicle must be securely locked when the vehicle is unattended, only when away from the insured’s premises\nc. Requires that the doors and windows of the vehicle must be securely locked when be securely locked when the vehicle is unattended\nd. There must be visible signs of force used to gain entry into the body or compartment of the vehicle\ne. A, c and d",
      "back": "Ans: E\nA, c and d\nExplanation: E: A, c and d"
    },
    {
      "id": "C10",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The Statutory Condition One, Misrepresentation identifies breaches of good faith. A breach of good faith is deemed to have occurred when:\na. The quality of the risk is superior to what has been described on the application\nb. The insured fails to disclose previous claims\nc. The insured does not disclose facts which the insurer has waived the requirement for information\nd. The insured does not disclose facts which are known to the insurer\ne. The insured does disclose facts which need not be disclosed by reason of a policy condition",
      "back": "Ans: B\nThe insured fails to disclose previous claims\nExplanation: B: The insured fails to disclose previous claims"
    },
    {
      "id": "C11",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes why brokers are referred to as the insurer’s first line underwriter?\na. They have binding authority on all commercial risks\nb. They have the first opportunity to qualify a prospect for insurance\nc. They select risks that are most profitable to the insurer\nd. They carry out the inspections of risks\ne. They have the first contact with the prospect",
      "back": "Ans: B\nThey have the first opportunity to qualify a prospect for insurance\nExplanation: B: They have the first opportunity to qualify a prospect for insurance"
    },
    {
      "id": "C12",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "A submission is\na. An application for insurance\nb. Written information provided to the underwriter\nc. Verbal information provided to the underwriter\nd. A proposal for insurance which has been presented to the underwriter for consideration\ne. None of the above",
      "back": "Ans: D\nA proposal for insurance which has been presented to the underwriter for consideration\nExplanation: D: A proposal for insurance which has been presented to the underwriter for consideration"
    },
    {
      "id": "C13",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "What is the purpose of conducting a fact find or survey?\na. To reduce errors and omissions claims\nb. To assist in the identification of loss exposures\nc. To eliminate the purchase of coverages not needed\nd. A and c\ne. B and c",
      "back": "Ans: E\nB and c\nExplanation: E: B and c"
    },
    {
      "id": "C14",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Fire resistive means\na. A building has met minimum standards in terms of hours it can withstand a controlled test fire\nb. A building which is constructed of non-combustible materials\nc. A building which is constructed of concrete block with the roof, floors and interior framing constructed of wood or other combustible materials\nd. A building which is constructed of heavy timber\ne. None of the above",
      "back": "Ans: A\nA building has met minimum standards in terms of hours it can withstand a controlled test fire\nExplanation: A: A building has met minimum standards in terms of hours it can withstand a controlled test fire"
    },
    {
      "id": "C15",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "When a building is more than 25 years old additional information is normally requested by the underwriter. Which of the following items is not part of this information?\na. Over-current protection, such as circuit breakers or fuses\nb. The roof\nc. The plumbing and heating\nd. The detachment\ne. The wiring",
      "back": "Ans: D\nThe detachment\nExplanation: D: The detachment"
    },
    {
      "id": "C16",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "The primary function of an underwriter is\na. To classify risks according to their probability for loss as a class\nb. To determine the rate or premium to be charged\nc. To select those risks most likely to suffer a loss\nd. To provide policyholders’ service",
      "back": "Ans: C\nTo select those risks most likely to suffer a loss\nExplanation: C: To select those risks most likely to suffer a loss"
    },
    {
      "id": "C17",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "An underwriter must assess the hazards of a risk which can increase the chance of losses. In addition to the physical hazards, the existence of potential moral hazards is also determined. Which of the following conditions is not considered a moral hazard?\na. The financial condition of the insured\nb. The housekeeping\nc. The associates of the insured\nd. All of the above\ne. None of the above",
      "back": "Ans: B\nThe housekeeping\nExplanation: B: The housekeeping"
    },
    {
      "id": "C18",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Physical hazards are:\na. Subjective characteristics of the applicant that may cause a peril to occur\nb. Characteristics of the risk itself\nc. Characteristics of the environment in which the risk is located\nd. Conditions relating to the use of tangible property which may cause a peril to occur\ne. All of the above",
      "back": "Ans: D\nConditions relating to the use of tangible property which may cause a peril to occur\nExplanation: D: Conditions relating to the use of tangible property which may cause a peril to occur"
    },
    {
      "id": "C19",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Underwriters may use external sources of information to supplement the information provided on an application. Which of the following is not an external source of information?\na. The broker’s production records\nb. Financial rating services\nc. Consumer investigation reports\nd. Government records\ne. The broker",
      "back": "Ans: A\nThe broker’s production records\nExplanation: A: The broker’s production records"
    },
    {
      "id": "C20",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "The purpose of an inspection report is\na. To provide data on the physical characteristics of the risk\nb. To provide an indication of the character of the applicant or insured\nc. To provide the insurer with a list of mandatory recommendations\nd. To provide the insurer with a list of suggested recommendations\ne. All of the above",
      "back": "Ans: E\nAll of the above\nExplanation: E: All of the above"
    },
    {
      "id": "C21",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "One of the statutory requirements pertaining to contracts of insurance is that insurers state the policy period on the declarations page. The insurance acts of the common law provinces state that the coverage commences at a specific time on the effective date of the policy. Select the effective time.\na. 12:01 am standard time at the address of the broker\nb. 12:01 am standard time at the address of the named insured as stated on the declarations page\nc. 12:01 pm standard time at the address of the location insured\nd. 12:01 am standard time at the address of the insurer’s head office\ne. 12:01 pm standard time at the address of the named insured as stated on the declaration page",
      "back": "Ans: B\n12:01 am standard time at the address of the named insured as stated on the declarations page\nExplanation: B: 12:01 am standard time at the address of the named insured as stated on the declarations page"
    },
    {
      "id": "C22",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The removal clause is one of the extensions of coverage provided in the fire policy of the following provisions which one is not part of the removal clause:\na. The insurer extends coverage for 30 days when property is at a location not indicated on the declarations page, and which is a newly acquired location of the insured\nb. The insurer extends coverage when property is at a location not indicated on teh declarations page and which was necessarily removed to prevent loss\nc. The insurer extends coverage at an unnamed location for a maximum of 7 days or until expiry of the policy, whichever is the least\nd. In the event of a loss at an unnamed location the amount of payment is restricted to the amount of insurance remaining after the payment of any losses at the location insured\ne. None of the above",
      "back": "Ans: A\nThe insurer extends coverage for 30 days when property is at a location not indicated on the declarations page, and which is a newly acquired location of the insured\nExplanation: A, Coverage is not automatically extended to newly acquired location of the Insured. This clause will only respond when property was necessarily removed to protect insured property from loss or further loss."
    },
    {
      "id": "C23",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The peril of explosion in the fire and extended coverage form excludes explosions due to:\na. natural , coal or manufactured gas\nb. Pressure vessels with a maximum internal working pressure of no more than 15 pounds per square inch\nc. Pressure vessels with a maximum internal working pressure in excess of 15 pounds per square inch\nd. Damage to insured stock or equipment that is caused by an explosion occurring during pressure testing\ne. All of the above",
      "back": "Ans: C\nPressure vessels with a maximum internal working pressure in excess of 15 pounds per square inch\nExplanation: C: Pressure vessels with a maximum internal working pressure in excess of 15 pounds per square inch"
    },
    {
      "id": "C24",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Fire and extended coverage insures loss or damage caused by riot, vandalism and malicious acts. Select the conditions that constitute a riot\na. There was clear and present danger or, or which would result in damage to property or injury to persons\nb. There was a group of no less than two persons involved causing injury or damage\nc. There was an act or acts of violence or threatened violence\nd. There were at least three or more persons involved, even though only one may have caused damage or injury\ne. A, c & d",
      "back": "Ans: E\nA, c & d\nExplanation: E: A, c & d"
    },
    {
      "id": "C25",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The broad form policy\na. Is the most extensive standard coverage from available\nb. Insures against all risks except those that are specifically excluded\nc. Excludes all losses that are partially or totally in the insured’s control\nd. Includes losses directly caused by a named peril\ne. All of the above",
      "back": "Ans: E\nAll of the above\nExplanation: E: All of the above"
    },
    {
      "id": "C26",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Inherent vice is considered to be\na. A criminal act perpetrated by the insured or their employees\nb. Claiming for multiple damages under a single claim\nc. The same as moral hazard\nd. Something within a commodity or other kind of property that causes it to spoil over time\ne. Poor or negligent management",
      "back": "Ans: D\nSomething within a commodity or other kind of property that causes it to spoil over time\nExplanation: D, inherent vice is something which causes the spoilage of perishable goods."
    },
    {
      "id": "C27",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Loss due to delay or loss of market is not covered because\na. It is an uninsurable risk\nb. It is a trade risk\nc. It is directly under the control of the insured\nd. It is cumulative damage, and this policy covers single occurrence damage only\ne. It is an indirect loss",
      "back": "Ans: E\nIt is an indirect loss\nExplanation: E, The Broad Form Policy covers direct loss only."
    },
    {
      "id": "C28",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following properties are not excluded in the broad form?\na. Lottery tickets, tickets, or token for public transit\nb. Unlicensed automobiles used on the insured’s premises\nc. Property in the custody of a sales representative outside the insured’s premises\nd. Boats and watercraft, not for sale\ne. Property on loan or on rental or sold under a conditional sale, installment payment or other deferred payment plan",
      "back": "Ans: B\nUnlicensed automobiles used on the insured’s premises\nExplanation: B, Unlicensed vehicles that are used exclusively on the premises are insured."
    },
    {
      "id": "C29",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following losses is insured under the broad form policy?\na. Damage to insured’s building caused by the explosion of a steam boiler\nb. Damage to equipment caused by the rupture of a hot water heater with an internal diameter of 20 inches which is used for production purposes\nc. Bursting of a pressure vessel with an internal pressure over 15 pounds per square inch\nd. Damage caused by the explosion of a hot water heater with diameter of 24 inches and an internal pressure of over 25 pounds per square inch used for domestic purposes\ne. Damage due to mechanical breakdown of machinery",
      "back": "Ans: D\nDamage caused by the explosion of a hot water heater with diameter of 24 inches and an internal pressure of over 25 pounds per square inch used for domestic purposes\nExplanation: D, Explosion of a hot water heater with an internal diameter of 24 inches or less is covered regardless of the internal pressure, provided the use is strictly for domestic purposes."
    },
    {
      "id": "C30",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Extensions of coverage\na. Broaden the scope of coverage\nb. Increase the insurer’s liability for loss\nc. Are added to the policy at the request of the insured\nd. Are not subject to a deductible\ne. Are provided strictly at the discretion of the insurer",
      "back": "Ans: A\nBroaden the scope of coverage\nExplanation: A: Broaden the scope of coverage"
    },
    {
      "id": "C31",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "An endorsement\na. Is a separate policy, issued to cover previously excluded items\nb. Is approval in principle of the terms of the policy\nc. Changes the terms or conditions of the policy\nd. Adds additional coverage to what is already\ne. Is a preliminary agreement by the insurer to pay the insured’s claim",
      "back": "Ans: A\nIs a separate policy, issued to cover previously excluded items\nExplanation: A: Is a separate policy, issued to cover previously excluded items"
    },
    {
      "id": "C32",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "To get coverage for breakdown of computer hardware, the insured must\na. Have a valid maintenance contract for the equipment\nb. There is no coverage for mechanical breakdown\nc. Must get a boiler and machinery policy\nd. Must have replacement cost endorsement\ne. Must have an electronic data processing policy",
      "back": "Ans: A\nHave a valid maintenance contract for the equipment\nExplanation: A, Even with an Electronic Data Processing Policy, the Insurer can refuse to cover the loss if the Insured does not have a valid maintenance contract."
    },
    {
      "id": "C33",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "The accounts receivable form does not cover\na. Collection expenses that arise due to the loss, for debt collection by collection agencies\nb. Outstanding debts that cannot be collected as a result of the loss\nc. Reasonable expenses incurred in re-establishing the accounts receivable records\nd. Interest charges on money that the insured was forced to borrow due to an impaired cash flow\ne. The actual costs of copying accounts receivable information from other source documents",
      "back": "Ans: E\nThe actual costs of copying accounts receivable information from other source documents\nExplanation: E, The costs of copying the information from other sources are covered under the standard commercial property forms."
    },
    {
      "id": "C34",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "The boiler and machinery policies cover losses arising out of\na. Explosions\nb. Interruption of business operations\nc. Accidents\nd. Spoilage\ne. All of the above",
      "back": "Ans: C\nAccidents\nExplanation: C, These policies cover loss due to accidents to objects. An accident is defined as the sudden and accidental breakdown of an object, with simultaneous physical damage."
    },
    {
      "id": "C35",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Expediting expenses refer to\na. The cost of shipping goods via canada post\nb. Debris removal\nc. An extra payment by the insured to speed up approval of the policy\nd. Payments to the insured to help them return to business as quickly as possible\ne. Expenses incurred in recreating the accounts receivable records",
      "back": "Ans: D\nPayments to the insured to help them return to business as quickly as possible\nExplanation: D, Expediting Expenses are paid out under the Boiler and Machinery policies, to pay for reasonable expenses incurred in making the necessary temporary repairs, and expediting the permanent repairs."
    },
    {
      "id": "C36",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Losses incurred to the stock, when the cooler breaks down in a dairy are covered if:\na. They are caused because of a lightning strike\nb. The insured has a consequential loss assumption clause\nc. The storage facility is off the premises\nd. It was due to the neglectful act of an employee\ne. It was due to the malicious act of an employee",
      "back": "Ans: B\nThe insured has a consequential loss assumption clause\nExplanation: B, The Consequential Loss Assumption Clause covers loss to stock due to a change in temperature, which was a result of damage to the cooling apparatus."
    },
    {
      "id": "C37",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which is not true in respect to the by-laws coverages?\na. The insured must also have the replacement cost endorsement to eliminate the effects of depreciation\nb. The broker should be aware of the various by-laws affecting his or her clients\nc. The basis of settlement is actual cash value\nd. The insured should select an amount of insurance that is sufficient to bring the building up to the new standards\ne. The insured is permitted to rebuild at a different location",
      "back": "Ans: E\nThe insured is permitted to rebuild at a different location\nExplanation: E, There is a same site restriction, which would have to be waived if the by-laws no longer permitted the existing type of building to be erected on the site."
    },
    {
      "id": "C38",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Should the stock of a sales representative be stolen out of his home\na. The loss is covered under the home owner’s policy\nb. The loss is covered under the sales representative coverage\nc. The loss is covered only if the home is listed as a location on the declarations page\nd. The loss is covered under the installment sales contract floater\ne. The loss is covered under the standard commercial property insurance policy",
      "back": "Ans: B\nThe loss is covered under the sales representative coverage\nExplanation: B, The Sales Representative Coverage will pay for losses in the Sales Representative's home."
    },
    {
      "id": "C39",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "The peak season endorsement covers which of the following\na. Peak periods where there are increases in stock\nb. Regularly fluctuating stock amounts\nc. Occasions when the insured informs the insurer of the increase in stock\nd. A and b\ne. All of the above",
      "back": "Ans: A\nPeak periods where there are increases in stock\nExplanation: A, This coverage is only for businesses that experience increases in stock on a few, well-defined occasions, which are detailed in the policy, so that the coverage is automatically in place on those dates."
    },
    {
      "id": "C40",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which is not true concerning the replacement cost endorse ment?\na. There is no replacement cost endorsement for stock\nb. It is site specific\nc. Delays in replacement may mean that the insured is disqualified from coverage\nd. If like property cannot be obtained, the policy will pay for new property that is as similar as possible\ne. Payments cannot be greater than what is actually spent in replacing the property, even if the value of the property is greater than the expenses",
      "back": "Ans: A\nThere is no replacement cost endorsement for stock\nExplanation: A, There is a Replacement Cost Endorsement available for stock, although it is less common, and applies to selected items only."
    },
    {
      "id": "C41",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Building?\na. 3. War, Invasion, act of foreign enemy\nb. owner/employees control it, the weakness is they can forget to\nc. Excludes jewellery, fur, paintings, livestock, etc\nd. Property is itemized\ne. Equipment",
      "back": "Ans: E\nEquipment\nExplanation: E: Equipment"
    },
    {
      "id": "C42",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Stock?\na. can be endorsed.\nb. Inherent Vice - something within a commodity that causes demise over time\nc. 3 ways to insure commercial property\nd. when income is produced from down buildings, net annual rent\ne. Rental value",
      "back": "Ans: C\n3 ways to insure commercial property\nExplanation: C: 3 ways to insure commercial property"
    },
    {
      "id": "C43",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3 ways to insure commercial property?\na. 13. Difference between reinsurance and subscription\nb. Identify coverages needed, help determine cvgs needed\nc. definition differs from legal, there has to be marks of forcible entry or exit.\nd. Scheduled - items specifically identified on policy\ne. each insurer contracts with the insured for a specific limit of liability. If one",
      "back": "Ans: D\nScheduled - items specifically identified on policy\nExplanation: D: Scheduled - items specifically identified on policy"
    },
    {
      "id": "C44",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Scheduled?\na. Property is itemized\nb. 3. Rate-Making - factors that influence the premium are application info, internal and\nc. items specifically identified on policy\nd. Replacement value\ne. Does not apply if property is insured by the owner unless he is obligated to insure it",
      "back": "Ans: C\nitems specifically identified on policy\nExplanation: C: items specifically identified on policy"
    },
    {
      "id": "C45",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Scheduled - items specifically identified on policy?\na. on standard policy, vacant/unoccupied is not covered after 30 days.\nb. if repaired with due diligence and dispatch, the insured is entitled to claim all costs\nc. loss does not apply to first $1000 of any loss and does not\nd. POED - A single limit of insurance is stated on the policy\ne. c) Damage to electrical devices caused by artificially generated electrical currants.",
      "back": "Ans: D\nPOED - A single limit of insurance is stated on the policy\nExplanation: D: POED - A single limit of insurance is stated on the policy"
    },
    {
      "id": "C46",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes POED?\na. A single limit of insurance is stated on the policy\nb. Reinsurance\nc. Stock Burglary Rider - insures stock and equipment against actual/attempted burglary, robbery\nd. if not, the insurer will reduce the payable amount.\ne. p) Bylaws - no coverage for increased cost through enforcement of bylaw",
      "back": "Ans: A\nA single limit of insurance is stated on the policy\nExplanation: A: A single limit of insurance is stated on the policy"
    },
    {
      "id": "C47",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes All property (Blanket)?\na. document issued by insurer that adds coverages.\nb. b) Property at locations which to the knowledge of the insured are vacant/shut\nc. protects the interests of business that sells goods\nd. all property owned by the insured is covered by a single limit of insurance\ne. Limit of Insurance Required/Premium Adjustement Provision",
      "back": "Ans: D\nall property owned by the insured is covered by a single limit of insurance\nExplanation: D: all property owned by the insured is covered by a single limit of insurance"
    },
    {
      "id": "C48",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Stock?\na. designed to insured movable equipment owned by\nb. Must make application for refund within 12 months of expiry of policy\nc. Pre-employment - written application, security checks, investigation of personal finances,\nd. It sets the parameters of coverage on stock to items that are usual to the insured’s business\ne. Increase in cost of construction",
      "back": "Ans: D\nIt sets the parameters of coverage on stock to items that are usual to the insured’s business\nExplanation: D: It sets the parameters of coverage on stock to items that are usual to the insured’s business"
    },
    {
      "id": "C49",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Similar property belonging to others?\na. Excludes mechanical breakdown and centrifugal force\nb. Ordinary Payroll - Limited Coverage - 90 or 180 day Option\nc. 2. Contractor’s Equipment Floater - designed to insured movable equipment owned by\nd. When the insured is under obligation to keep insured or for which he is legally liable\ne. 3. War, Invasion, act of foreign enemy",
      "back": "Ans: D\nWhen the insured is under obligation to keep insured or for which he is legally liable\nExplanation: D: When the insured is under obligation to keep insured or for which he is legally liable"
    },
    {
      "id": "C50",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 5: Misc. Property Forms",
      "front": "Which of the following best describes Contractual obligations for the stock of suppliers?\na. Liable for loss to costumer’s property when ordinary care is breached\nb. extends coverage to off premises use of tools. Has two forms\nc. Exercise ordinary care as a bailee for hire\nd. Rust/corrosion\ne. if not, the insurer will reduce the payable amount.",
      "back": "Ans: C\nExercise ordinary care as a bailee for hire\nExplanation: C: Exercise ordinary care as a bailee for hire"
    },
    {
      "id": "C51",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 5: Misc. Property Forms",
      "front": "Which of the following best describes Exercise ordinary care as a bailee for hire?\na. leased/ borrowed / loaned equipment\nb. All insurers share in premiums and losses\nc. explosion of boilers\nd. Subscription\ne. financial statement is used. But it is important to",
      "back": "Ans: A\nleased/ borrowed / loaned equipment\nExplanation: A: leased/ borrowed / loaned equipment"
    },
    {
      "id": "C52",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes leased/ borrowed / loaned equipment?\na. No bearing on the amount of payment made by the insurer\nb. 2. They don’t stand alone - they take form of an endorsement\nc. Contractor’s tools and equipment\nd. Items that are covered\ne. Wear/tear/loss due to the designed operation",
      "back": "Ans: D\nItems that are covered\nExplanation: D: Items that are covered"
    },
    {
      "id": "C53",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Items that are covered?\na. Loss of value of the undamaged portion of the building\nb. Equipment\nc. 3. Personal Property of Officers and Employees - allows personal property to fit into the\nd. document issued by insurer that adds coverages.\ne. 1. Risk Selection",
      "back": "Ans: B\nEquipment\nExplanation: B: Equipment"
    },
    {
      "id": "C54",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Equipment?\na. Cash register used in insured’s business\nb. 9. Flood\nc. Pre-employment - written application, security checks, investigation of personal finances,\nd. owner controls it and do not send to a control center.\ne. Impact losses only",
      "back": "Ans: A\nCash register used in insured’s business\nExplanation: A: Cash register used in insured’s business"
    },
    {
      "id": "C55",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Cash register used in insured’s business?\na. lack of habitual presence. Complete with contents but owner is absent.\nb. limited to Canada and continental US\nc. 2. Forcible entry into protected enclosures\nd. Portable wall dividers separating work areas in a sales office\ne. 1 year after expiry to make a claim.",
      "back": "Ans: D\nPortable wall dividers separating work areas in a sales office\nExplanation: D: Portable wall dividers separating work areas in a sales office"
    },
    {
      "id": "C56",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Building?\na. Two bundles of shingles stored in the insured’s basement that were left over after a roof was re-shingled\nb. Loading - rate over and above the fire rate\nc. Equipment\nd. contents removed also\ne. Identification - any employee who has special skills not easily replaced is not ordinary",
      "back": "Ans: A\nTwo bundles of shingles stored in the insured’s basement that were left over after a roof was re-shingled\nExplanation: A: Two bundles of shingles stored in the insured’s basement that were left over after a roof was re-shingled"
    },
    {
      "id": "C57",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Stock?\na. POED - A single limit of insurance is stated on the policy\nb. if insured had similar policies before,\nc. Plastic bags used by a business to package\nd. will not ignite or burn when subjected to fire\ne. Not provided while on locations leased or owned by insured",
      "back": "Ans: C\nPlastic bags used by a business to package\nExplanation: C: Plastic bags used by a business to package"
    },
    {
      "id": "C58",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Plastic bags used by a business to package?\na. same as above, but no guard is dispatched.\nb. methods used to secure access when business is closed.\nc. Covers acceptance of money orders not honored upon presentation.\nd. Customer’s funishings held on consignment sale bases by local furniture store\ne. a central station ensures it is turned on at arranged times.",
      "back": "Ans: D\nCustomer’s funishings held on consignment sale bases by local furniture store\nExplanation: D: Customer’s funishings held on consignment sale bases by local furniture store"
    },
    {
      "id": "C59",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Sales brochures?\na. a) Earthquake - loss caused by earthquake. Except for ensuing loss or damage which\nb. Data Exclusion\nc. 3 ways of valuing property\nd. Between the primary insurer and the reinsurer\ne. Separate payments are provided from all companies to the clamant",
      "back": "Ans: C\n3 ways of valuing property\nExplanation: C: 3 ways of valuing property"
    },
    {
      "id": "C60",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3 ways of valuing property?\na. 1. Tenant’s Improvements\nb. Equipment\nc. Method used to insure commercial building, equipment and stock under a single limit of insurance\nd. ACV - repair, replace or rebuild less depreciation\ne. considered in control of insured and are trade risks. Except if fire",
      "back": "Ans: D\nACV - repair, replace or rebuild less depreciation\nExplanation: D: ACV - repair, replace or rebuild less depreciation"
    },
    {
      "id": "C61",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes ACV?\na. repair, replace or rebuild less depreciation\nb. Not greater than either of 2% of the amount of insurance or $5,000\nc. No coverage when storing property of others, which can be endorsed through a\nd. Perils Excluded\ne. If the insured peril is the cause of pollution, the loss is NOT excluded",
      "back": "Ans: A\nrepair, replace or rebuild less depreciation\nExplanation: A: repair, replace or rebuild less depreciation"
    },
    {
      "id": "C62",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes ACV - repair, replace or rebuild less depreciation?\na. Replacement Value - repair, replace or rebuild without deduction for depreciation\nb. Fact-Find Survey uses\nc. financial statement is used. But it is important to\nd. Option 1 - Ordinary Payroll - Limited Coverage - 90 or 180 day Option\ne. a promise that certain facts are true and will remain so.",
      "back": "Ans: A\nReplacement Value - repair, replace or rebuild without deduction for depreciation\nExplanation: A: Replacement Value - repair, replace or rebuild without deduction for depreciation"
    },
    {
      "id": "C63",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Replacement Value?\na. expert opinion of licensed real estate appraiser\nb. repair, replace or rebuild without deduction for depreciation\nc. 2. Contractor’s Equipment Floater - designed to insured movable equipment owned by\nd. 1. Tenant’s Improvements\ne. describes buildings that have met min standards hours",
      "back": "Ans: B\nrepair, replace or rebuild without deduction for depreciation\nExplanation: B: repair, replace or rebuild without deduction for depreciation"
    },
    {
      "id": "C64",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Book Value?\na. p) Bylaws - no coverage for increased cost through enforcement of bylaw\nb. Limit of Insurance Required/Premium Adjustement Provision\nc. No bearing on the amount of payment made by the insurer\nd. original purchase price less depreciation or other write-offs (not including inflation)\ne. estimated annual rental value of unoccupied portions",
      "back": "Ans: D\noriginal purchase price less depreciation or other write-offs (not including inflation)\nExplanation: D: original purchase price less depreciation or other write-offs (not including inflation)"
    },
    {
      "id": "C65",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Book Value Method?\na. Pays costs for auditors to certify and prove the loss.\nb. must reflect maximum values\nc. No bearing on the amount of payment made by the insurer\nd. Loss to systems (hardware)\ne. the insured must file a statement of values with the",
      "back": "Ans: C\nNo bearing on the amount of payment made by the insurer\nExplanation: C: No bearing on the amount of payment made by the insurer"
    },
    {
      "id": "C66",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Not appropriate for insurance purposes?\na. Book value can be reduced to zero\nb. something that naturally causes its own demise over time. Like\nc. f) Trade losses\nd. used in low risk commercial operations. The owner\ne. 4. Building Damage by Theft - provides coverage for damage to that part of the building",
      "back": "Ans: A\nBook value can be reduced to zero\nExplanation: A: Book value can be reduced to zero"
    },
    {
      "id": "C67",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Book value can be reduced to zero?\na. Can be combined with Earthquake (“Flake”)\nb. Cost of making goods that are faulty and improper design/workmanship/material\nc. 3 approaches for actual cash value\nd. Market Value\ne. Straight line / Plateau accelerated method",
      "back": "Ans: C\n3 approaches for actual cash value\nExplanation: C: 3 approaches for actual cash value"
    },
    {
      "id": "C68",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3 approaches for actual cash value?\na. Underground, muskeg, blasting, dynamite.\nb. cost of repair, replace or rebuild minus depreciation\nc. Available in limited or broad form. Insures values of materials and cost of labour.\nd. Cost Approach\ne. Insurers will pay a loss even when they cannot tie an employee to a loss.",
      "back": "Ans: D\nCost Approach\nExplanation: D: Cost Approach"
    },
    {
      "id": "C69",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Cost Approach?\na. ONLY applies to building damage\nb. May not have adequate coverage, may not be broad enough, may be invalid due to\nc. h) Rodents/insects/vermin - unless its directly by a peril\nd. Subtract the rate of depreciation from RC\ne. Ordinary Payroll Expense - has two options.",
      "back": "Ans: D\nSubtract the rate of depreciation from RC\nExplanation: D: Subtract the rate of depreciation from RC"
    },
    {
      "id": "C70",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Subtract the rate of depreciation from RC?\na. Straight line / Plateau accelerated method\nb. step into the shoes of the party compensated and sue\nc. k) Nuclear incident - except for ensuing loss caused by named peril.\nd. determine the R/C of the property, then subtract rate of\ne. 1. Physical protection - steel doors, locks, bars",
      "back": "Ans: A\nStraight line / Plateau accelerated method\nExplanation: A: Straight line / Plateau accelerated method"
    },
    {
      "id": "C71",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Straight line / Plateau accelerated method?\na. amount of loss is influenced by economic conditions and trends.\nb. owner/employees control it, the weakness is they can forget to\nc. owner controls it and do not send to a control center.\nd. when income is produced from down buildings, net annual rent\ne. Market Value",
      "back": "Ans: E\nMarket Value\nExplanation: E: Market Value"
    },
    {
      "id": "C72",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Market Value?\na. Expert opinion\nb. Subtract the rate of depreciation from RC\nc. considered in control of insured and are trade risks. Except if fire\nd. will continue during the interruption such as accounts payables, mortgage,\ne. will not ignite or burn when subjected to fire",
      "back": "Ans: A\nExpert opinion\nExplanation: A: Expert opinion"
    },
    {
      "id": "C73",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Expert opinion?\na. Primary duty is to select risks most profitable to the company. Improper screening can\nb. Portable wall dividers separating work areas in a sales office\nc. Replacement Value - repair, replace or rebuild without deduction for depreciation\nd. except for sale as stock and except on the premises\ne. Licensed real estate appraiser",
      "back": "Ans: E\nLicensed real estate appraiser\nExplanation: E: Licensed real estate appraiser"
    },
    {
      "id": "C74",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Licensed real estate appraiser?\na. Market value of before / after the loss\nb. All risks coverage, including damage to letterwork.\nc. a) Wear and tear, rust and corrosion, gradual deterioration\nd. Other Excluded Losses\ne. Subtract the rate of depreciation from RC",
      "back": "Ans: A\nMarket value of before / after the loss\nExplanation: A: Market value of before / after the loss"
    },
    {
      "id": "C75",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes The land?\na. Income approach\nb. Applies while being conveyed to other location\nc. All insurers share in premiums and losses\nd. Primary duty is to select risks most profitable to the company. Improper screening can\ne. if insured had similar policies before,",
      "back": "Ans: A\nIncome approach\nExplanation: A: Income approach"
    },
    {
      "id": "C76",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Income approach?\na. Access was prohibited by civil authority\nb. 1. Risk Selection\nc. By-Laws Coverage - when complying to by-laws results in an increase in time to\nd. 3. War, Invasion, act of foreign enemy\ne. run -down buildings = net annual rent with a capitalization rate applied to it",
      "back": "Ans: E\nrun -down buildings = net annual rent with a capitalization rate applied to it\nExplanation: E: run -down buildings = net annual rent with a capitalization rate applied to it"
    },
    {
      "id": "C77",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes True to the Owner?\na. 1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or\nb. certain hazards or conditions to all buildings that influence their\nc. Clear and present danger\nd. The insureds claim the previous three methods have failed to consider their special circumstances\ne. profits form will be more suitable for subsequent loss of customers",
      "back": "Ans: D\nThe insureds claim the previous three methods have failed to consider their special circumstances\nExplanation: D: The insureds claim the previous three methods have failed to consider their special circumstances"
    },
    {
      "id": "C78",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Broad Evidence Rue?\na. Premium is provisional - adjusted based on reported values at the end of the\nb. Pays costs for auditors to certify and prove the loss.\nc. Ordinary Payroll Expense - has two options.\nd. Ties together all four of the above approaches and considers:\ne. fair and reasonable price property would be on the market minus",
      "back": "Ans: D\nTies together all four of the above approaches and considers:\nExplanation: D: Ties together all four of the above approaches and considers:"
    },
    {
      "id": "C79",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes RC less depreciation?\na. Cash price value in a fair market, allow for depreciation\nb. Loss is restricted to sudden backing up of brown water.\nc. can be endorsed.\nd. Market value\ne. enter the insured’s premises at all reasonable times to inspect.",
      "back": "Ans: D\nMarket value\nExplanation: D: Market value"
    },
    {
      "id": "C80",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 7: Business Interruption",
      "front": "Which of the following best describes Market value?\na. Rental value\nb. Premium is provisional - adjusted based on reported values at the end of the\nc. k) Nuclear incident - except for ensuing loss caused by named peril.\nd. 1. Extra Expense Endorsement Form\ne. can be endorsed, but having to comply with building by-laws is not",
      "back": "Ans: A\nRental value\nExplanation: A: Rental value"
    },
    {
      "id": "C81",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 7: Business Interruption",
      "front": "Which of the following best describes Rental value?\na. Rider - document issued by insurer that adds coverages.\nb. Assessed valuation\nc. ONLY applies to building damage\nd. can be endorsed.\ne. Applies while being conveyed to other location",
      "back": "Ans: B\nAssessed valuation\nExplanation: B: Assessed valuation"
    },
    {
      "id": "C82",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Location?\na. Specialized policy forms have been developed: automobiles, money and securities\nb. Contains 5 Insuring Agreements (insured can select any or all coverages and are continuous\nc. Obsolescence\nd. Both the owner of the property and the bailee has insurable interest\ne. methods used to secure access when business is closed.",
      "back": "Ans: C\nObsolescence\nExplanation: C: Obsolescence"
    },
    {
      "id": "C83",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Obsolescence?\na. excluded due to high exposure\nb. but has premium adjustments and reporting.\nc. Resale success\nd. Fact-Find Survey uses\ne. if not all met, are on ACV",
      "back": "Ans: C\nResale success\nExplanation: C: Resale success"
    },
    {
      "id": "C84",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Resale success?\na. the insurer retains the right to step into the shoes of the insured and sue\nb. a central station ensures it is turned on at arranged times.\nc. Actual cash value\nd. Labour standards/notice of layoff periods\ne. 3. Personal Property of Officers and Employees - allows personal property to fit into the",
      "back": "Ans: C\nActual cash value\nExplanation: C: Actual cash value"
    },
    {
      "id": "C85",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Actual cash value?\na. 1. Tool Floater Rider - extends coverage to off premises use of tools. Has two forms\nb. Cash price value in a fair market, allow for depreciation\nc. Securities is limited to ACV on the business day of the loss. Other\nd. named insured, policy period, identifies nine crime coverage options\ne. actual annual rents",
      "back": "Ans: B\nCash price value in a fair market, allow for depreciation\nExplanation: B: Cash price value in a fair market, allow for depreciation"
    },
    {
      "id": "C86",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes All property?\na. safety paper, protect blank cheques, controlled use of fax.\nb. ACV - repair, replace or rebuild less depreciation\nc. but has premium adjustments and reporting.\nd. Insurance covers >two items / locations\ne. Prompt recovery of loss.",
      "back": "Ans: D\nInsurance covers >two items / locations\nExplanation: D: Insurance covers >two items / locations"
    },
    {
      "id": "C87",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Insurance covers >two items / locations?\na. 1. Extra Expense Endorsement Form\nb. 2 Coverage Limits\nc. Pays all claims\nd. fair rental value of occupied portions of the building.\ne. One aggregate amount",
      "back": "Ans: E\nOne aggregate amount\nExplanation: E: One aggregate amount"
    },
    {
      "id": "C88",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes One aggregate amount?\na. No separate coverage amounts for each item\nb. c) Damage to electrical devices caused by artificially generated electrical currants.\nc. Assessed valuation\nd. Covers actual cost of reproduction\ne. Production Machinery - covers any complete machine with processes forms,",
      "back": "Ans: A\nNo separate coverage amounts for each item\nExplanation: A: No separate coverage amounts for each item"
    },
    {
      "id": "C89",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes No separate coverage amounts for each item?\na. Must make application for refund within 12 months of expiry of policy\nb. actual annual rents\nc. Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are\nd. Replacement value\ne. Perils Excluded",
      "back": "Ans: D\nReplacement value\nExplanation: D: Replacement value"
    },
    {
      "id": "C90",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Replacement value?\na. wrongful taking by force or fear. Includes unlawful act witnessed by custodian\nb. Specialized policy forms have been developed: automobiles, money and securities\nc. e) Animals/fish/birds - except when due to named peril or theft/attempted theft\nd. This covers for what named perils and broad form do not cover - explosion of boilers\ne. Cash value to replace",
      "back": "Ans: E\nCash value to replace\nExplanation: E: Cash value to replace"
    },
    {
      "id": "C91",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Cash value to replace?\na. lacks an essential element to be enforceable by law\nb. Separate payments are provided from all companies to the clamant\nc. Coverage only at premises\nd. Scheduled coverage\ne. portion applies to in transit or within other premises",
      "back": "Ans: D\nScheduled coverage\nExplanation: D: Scheduled coverage"
    },
    {
      "id": "C92",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Scheduled coverage?\na. check roof, wiring, breakers, plumbing, heating\nb. Inherent Vice - something that naturally causes its own demise over time. Like\nc. Cash price value in a fair market, allow for depreciation\nd. 6. Equipment Breakdown\ne. Property is itemized",
      "back": "Ans: E\nProperty is itemized\nExplanation: E: Property is itemized"
    },
    {
      "id": "C93",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Property is itemized?\na. Coverage limit for each item\nb. ONLY applies to building damage. Does not apply to property\nc. A bailee is someone who has temporary custody of personal property of another for a\nd. c) Damage to electrical devices caused by artificially generated electrical currants.\ne. 4. Inflation Protection - increases building insurance during the policy period to reflect",
      "back": "Ans: A\nCoverage limit for each item\nExplanation: A: Coverage limit for each item"
    },
    {
      "id": "C94",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Coverage limit for each item?\na. 1 - Access was prohibited by civil authority\nb. maximum payable for any one accident\nc. Wear/tear/loss due to the designed operation\nd. most extensive form. The policy is defined by exclusions\ne. Property of every description",
      "back": "Ans: E\nProperty of every description\nExplanation: E: Property of every description"
    },
    {
      "id": "C95",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Property of every description?\na. can be endorsed, but having to comply with building by-laws is not\nb. Method used to insure commercial building, equipment and stock under a single limit of insurance\nc. covers loss of income to owners of tenanted\nd. 3 ways of valuing property\ne. m) Loss or damage to pressel vessel greater than 15 PSI. Unless its less than 24 inches",
      "back": "Ans: B\nMethod used to insure commercial building, equipment and stock under a single limit of insurance\nExplanation: B: Method used to insure commercial building, equipment and stock under a single limit of insurance"
    },
    {
      "id": "C96",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Tenant’s improvements?\na. not insured.\nb. used to guard interior and restrict entry where valuables are stored.\nc. Additions or changes to rented premises by a tenant at his/her own expense.\nd. Excludes: glass, lettering, ornamentation, tapes/foils to the glass\ne. Must make application for refund within 12 months of expiry of policy",
      "back": "Ans: C\nAdditions or changes to rented premises by a tenant at his/her own expense.\nExplanation: C: Additions or changes to rented premises by a tenant at his/her own expense."
    },
    {
      "id": "C97",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Improvements or betterments?\na. each rider identifies and defines classes of property such as\nb. Common Hazards - certain hazards or conditions to all buildings that influence their\nc. Wear/tear/loss due to the designed operation\nd. indirect and not direct.\ne. Difference between package and manuscript policies",
      "back": "Ans: E\nDifference between package and manuscript policies\nExplanation: E: Difference between package and manuscript policies"
    },
    {
      "id": "C98",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Combine?\na. Difference between package and manuscript policies\nb. Insured must confirm amount collected is less than outstanding and they are unable to\nc. For tenants who have assumed responsibility for crime at the premises. Also for building\nd. No coverage for loss/damage caused by explosion of boilers.\ne. Under 1 form",
      "back": "Ans: E\nUnder 1 form\nExplanation: E: Under 1 form"
    },
    {
      "id": "C99",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Under 1 form?\na. Variety of coverages needed by offices and small mercantile operations\nb. c. This also includes contents shipped by Parcel Post. The amount of insurance is\nc. One aggregate amount\nd. Characteristics\ne. types of losses expected from everyday operation",
      "back": "Ans: A\nVariety of coverages needed by offices and small mercantile operations\nExplanation: A: Variety of coverages needed by offices and small mercantile operations"
    },
    {
      "id": "C100",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Manuscript?\na. items specifically identified on policy\nb. Same as commercial building and stock named perils\nc. For risks that have a specialized exposure\nd. May need valid maintenance contract\ne. Inherent vice",
      "back": "Ans: C\nFor risks that have a specialized exposure\nExplanation: C: For risks that have a specialized exposure"
    },
    {
      "id": "C101",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes For risks that have a specialized exposure?\na. Extensions Available\nb. e) Animals/fish/birds - except when due to named peril or theft/attempted theft\nc. period of vacancy specified on form. Duration is on underwriter’s discretion\nd. 2. Debris Removal Clause\ne. No standard coverage from exists",
      "back": "Ans: E\nNo standard coverage from exists\nExplanation: E: No standard coverage from exists"
    },
    {
      "id": "C102",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes No standard coverage from exists?\na. Offered on an optional basis\nb. except for ensuing loss caused by named peril.\nc. 2 - Peril causing damage to the neighbor was insured under the insured’s own policy.\nd. 13. Difference between reinsurance and subscription\ne. there is a need to project lost income for up to two years.",
      "back": "Ans: D\n13. Difference between reinsurance and subscription\nExplanation: D: 13. Difference between reinsurance and subscription"
    },
    {
      "id": "C103",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 13. Difference between reinsurance and subscription?\na. Resale success\nb. describes buildings that have met min standards hours\nc. all insurers share in both premiums collected and losses incurred. The contract\nd. Reinsurance\ne. owner controls system and is not required to inform the",
      "back": "Ans: D\nReinsurance\nExplanation: D: Reinsurance"
    },
    {
      "id": "C104",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Reinsurance?\na. steel doors, locks, bars\nb. Loading - rate over and above the fire rate\nc. All insurers share in premiums and losses\nd. excluded due to high exposure\ne. determine the R/C of the property, then subtract rate of",
      "back": "Ans: C\nAll insurers share in premiums and losses\nExplanation: C: All insurers share in premiums and losses"
    },
    {
      "id": "C105",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes All insurers share in premiums and losses?\na. Covers expenses such as renting temporary premises, renovations, moving expenses,\nb. Between the primary insurer and the reinsurer\nc. Cash price value in a fair market, allow for depreciation\nd. Non combustible - will not ignite or burn when subjected to fire\ne. includes unlawful taking from a vault or safe",
      "back": "Ans: B\nBetween the primary insurer and the reinsurer\nExplanation: B: Between the primary insurer and the reinsurer"
    },
    {
      "id": "C106",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Between the primary insurer and the reinsurer?\na. Expert opinion\nb. Resale success\nc. Controlled by the primary insurer\nd. expert opinion of licensed real estate appraiser\ne. Unoccupied - lack of habitual presence. Complete with contents but owner is absent.",
      "back": "Ans: C\nControlled by the primary insurer\nExplanation: C: Controlled by the primary insurer"
    },
    {
      "id": "C107",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Controlled by the primary insurer?\na. generally organized information for a purpose\nb. Ensures loss of money/securities within premise or any banking premise\nc. Pays all claims\nd. Property is itemized\ne. ACV - repair, replace or rebuild less depreciation",
      "back": "Ans: C\nPays all claims\nExplanation: C: Pays all claims"
    },
    {
      "id": "C108",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Pays all claims?\na. Each insurer contracts with the insured for a specific limit of liability\nb. Amount of insurance specified on the declarations page for the lost or damaged property\nc. Subscription\nd. Peril causing damage to the neighbor was insured under the insured’s own policy.\ne. 1. Reinstatement Clause - insureds will have as much insurance after a loss as they did",
      "back": "Ans: C\nSubscription\nExplanation: C: Subscription"
    },
    {
      "id": "C109",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Subscription?\na. p) Bylaws - no coverage for increased cost through enforcement of bylaw\nb. the inertia of a body that tends to move away from center it revolves\nc. Each insurer contracts with the insured for a specific limit of liability\nd. 1. Ensures same perils as property policy\ne. lack of habitual presence. Complete with contents but owner is absent.",
      "back": "Ans: C\nEach insurer contracts with the insured for a specific limit of liability\nExplanation: C: Each insurer contracts with the insured for a specific limit of liability"
    },
    {
      "id": "C110",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Each insurer has its own policy?\na. Separate payments are provided from all companies to the clamant\nb. No separate coverage amounts for each item\nc. indirect and not direct.\nd. Increase in cost of construction\ne. Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system",
      "back": "Ans: A\nSeparate payments are provided from all companies to the clamant\nExplanation: A: Separate payments are provided from all companies to the clamant"
    },
    {
      "id": "C111",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Pays or denies, others don't have to follow?\na. 3. Rate-Making - factors that influence the premium are application info, internal and\nb. only expenses deemed to be necessary to the resumption of\nc. Replacement shall be on the same or adjacent site\nd. Equipment\ne. 14. Reinsurance contracts are preferred by most brokers?",
      "back": "Ans: E\n14. Reinsurance contracts are preferred by most brokers?\nExplanation: E: 14. Reinsurance contracts are preferred by most brokers?"
    },
    {
      "id": "C112",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 14. Reinsurance contracts are preferred by most brokers??\na. Simpler to deal with an insurer protected by reinsurance\nb. estimated annual rental value of unoccupied portions\nc. 1. Removal Clause\nd. insures equipment and stock other than at the specific location.\ne. Ordinary Payroll Exclusion",
      "back": "Ans: A\nSimpler to deal with an insurer protected by reinsurance\nExplanation: A: Simpler to deal with an insurer protected by reinsurance"
    },
    {
      "id": "C113",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Interest of the insured?\na. expert opinion of licensed real estate appraiser\nb. k) Nuclear incident - except for ensuing loss caused by named peril.\nc. Subrogation - step into the shoes of the party compensated and sue\nd. Amount of insurance specified on the declarations page for the lost or damaged property\ne. A bailee is someone who has temporary custody of personal property of another for a",
      "back": "Ans: D\nAmount of insurance specified on the declarations page for the lost or damaged property\nExplanation: D: Amount of insurance specified on the declarations page for the lost or damaged property"
    },
    {
      "id": "C114",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Losses are smaller than conducting a full inventory?\na. This covers for what named perils and broad form do not cover - explosion of boilers\nb. not insured.\nc. Not greater than either of 2% of the amount of insurance or $5,000\nd. 26. Three obligations placed upon insureds by the Property Protection Systems clause\ne. written application, security checks, investigation of personal finances,",
      "back": "Ans: C\nNot greater than either of 2% of the amount of insurance or $5,000\nExplanation: C: Not greater than either of 2% of the amount of insurance or $5,000"
    },
    {
      "id": "C115",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Replace the standard clause?\na. On premises only\nb. building material stored at a location away from the project\nc. 19. The requirements of the Stated Amount Co-insurance Clause?\nd. Detachment - distance between insured property and other commercially rated\ne. each insurer contracts with the insured for a specific limit of liability. If one",
      "back": "Ans: C\n19. The requirements of the Stated Amount Co-insurance Clause?\nExplanation: C: 19. The requirements of the Stated Amount Co-insurance Clause?"
    },
    {
      "id": "C116",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "front": "Which of the following best describes Potential to be catastrophic: earthquakes, flood?\na. the insured has a legal duty to take steps to mitigate\nb. any employee who has special skills not easily replaced is not ordinary\nc. direct security for individual items.\nd. lack of habitual presence. Complete with contents but owner is absent.\ne. Specialized policy forms have been developed: automobiles, money and securities",
      "back": "Ans: E\nSpecialized policy forms have been developed: automobiles, money and securities\nExplanation: E: Specialized policy forms have been developed: automobiles, money and securities"
    },
    {
      "id": "C117",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 22. Explain the provisions of the reinstatement clause?\na. Insured shall have as much insurance after a loss as they did before it\nb. certain hazards or conditions to all buildings that influence their\nc. duplicating sensitive data/storing off premises, requiring two\nd. Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are\ne. Insured is liable only for cost of replacing, repairing, constructing or the property on the",
      "back": "Ans: A\nInsured shall have as much insurance after a loss as they did before it\nExplanation: A: Insured shall have as much insurance after a loss as they did before it"
    },
    {
      "id": "C118",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Sprinkler or other fire extinguishing system?\na. group of insurers participating in a policy\nb. Excludes jewellery, fur, paintings, livestock, etc\nc. Fire detection system\nd. 3 ways to insure commercial property\ne. covers merchandise and goods sold by the insured and",
      "back": "Ans: C\nFire detection system\nExplanation: C: Fire detection system"
    },
    {
      "id": "C119",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Fire detection system?\na. 1. Temporary Locations - insures equipment and stock other than at the specific location.\nb. Insures goods usual to the business.\nc. Equipment\nd. Insures the records of debts owed to the insured.\ne. Intrusion detection system",
      "back": "Ans: E\nIntrusion detection system\nExplanation: E: Intrusion detection system"
    },
    {
      "id": "C120",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Intrusion detection system?\na. Cash value to replace\nb. Testing/other construction\nc. loss of profit, gross earnings, rental income.\nd. 26. Three obligations placed upon insureds by the Property Protection Systems clause\ne. insures stock and equipment against actual/attempted burglary, robbery",
      "back": "Ans: D\n26. Three obligations placed upon insureds by the Property Protection Systems clause\nExplanation: D: 26. Three obligations placed upon insureds by the Property Protection Systems clause"
    },
    {
      "id": "C121",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Shall notify the insurer forthwith?\na. Blank value only if property is not replaced or reproduced\nb. Perils Excluded\nc. Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system\nd. DIRECT DAMAGE FORMS\ne. 3 coverages",
      "back": "Ans: C\nAny interruption to, or flaw or defect, coming to the knowledge of the insured in any such system\nExplanation: C: Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system"
    },
    {
      "id": "C122",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes CHAPTER 1: INTRODUCTION?\na. owner controls system and is not required to inform the\nb. insures stock and equipment against actual/attempted burglary, robbery\nc. Straight line / Plateau accelerated method\nd. o) Settling/Expansion/Contraction - ONLY applies to building damage\ne. Three Ways Property Can Be Valued:",
      "back": "Ans: E\nThree Ways Property Can Be Valued:\nExplanation: E: Three Ways Property Can Be Valued:"
    },
    {
      "id": "C123",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Three Ways Property Can Be Valued:?\na. preparation of original policy, changes requiring endorsements, billing\nb. Endorsements Available for:\nc. any employee who has special skills not easily replaced is not ordinary\nd. duplicating sensitive data/storing off premises, requiring two\ne. 1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation",
      "back": "Ans: E\n1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation\nExplanation: E: 1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": "C124",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 1. Actual Cash Value?\na. 1. Consequential Loss Assumption Clause - Cold Storage\nb. cost of repair, replace or rebuild minus depreciation\nc. changes requested effective only when consented to by the insurer.\nd. Misc. Forms\ne. designed to insured movable equipment owned by",
      "back": "Ans: B\ncost of repair, replace or rebuild minus depreciation\nExplanation: B: cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": "C125",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 2. Replacement Value?\na. direct security for individual items.\nb. Ordinary Payroll Expense - has two options.\nc. same as above, without depreciation deduction.\nd. step into the shoes of the party compensated and sue\ne. Provides means of ensuring predictable increases in stock values in advance.",
      "back": "Ans: C\nsame as above, without depreciation deduction.\nExplanation: C: same as above, without depreciation deduction."
    },
    {
      "id": "C126",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3. Book Value?\na. Money in vending machine or coin-operated machines\nb. original purchase price minus depreciation and other write-offs. Not\nc. 1 - Access was prohibited by civil authority\nd. allows personal property to fit into the\ne. the insured has a legal duty to take steps to mitigate",
      "back": "Ans: B\noriginal purchase price minus depreciation and other write-offs. Not\nExplanation: B: original purchase price minus depreciation and other write-offs. Not"
    },
    {
      "id": "C127",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Calculation of ACV?\na. Sudden, unusual and faulty release of smoke.\nb. each insurer contracts with the insured for a specific limit of liability. If one\nc. b) Flood - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,\nd. 1. Formula/Cost Approach - determine the R/C of the property, then subtract rate of\ne. deterioration caused by ordinary and reasonable use of subject matter.",
      "back": "Ans: D\n1. Formula/Cost Approach - determine the R/C of the property, then subtract rate of\nExplanation: D: 1. Formula/Cost Approach - determine the R/C of the property, then subtract rate of"
    },
    {
      "id": "C128",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 1. Formula/Cost Approach?\na. Provides coverage when valuable papers need to be recreated\nb. determine the R/C of the property, then subtract rate of\nc. charged based on annual receipts, and is provisional. Insured required to\nd. repair, replace or rebuild less depreciation\ne. ONLY applies to building damage. Does not apply to property",
      "back": "Ans: B\ndetermine the R/C of the property, then subtract rate of\nExplanation: B: determine the R/C of the property, then subtract rate of"
    },
    {
      "id": "C129",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 2. Market Value/Direct Sales Approach?\na. expert opinion of licensed real estate appraiser\nb. No coverage when storing property of others, which can be endorsed through a\nc. All insurers share in premiums and losses\nd. explosion of boilers\ne. Prompt recovery of loss.",
      "back": "Ans: A\nexpert opinion of licensed real estate appraiser\nExplanation: A: expert opinion of licensed real estate appraiser"
    },
    {
      "id": "C130",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3. Income Approach?\na. when income is produced from down buildings, net annual rent\nb. 1. Reinstatement Clause - insureds will have as much insurance after a loss as they did\nc. EXTENSIONS OF COVERAGE\nd. alerts broker to possible loss exposures, ensures needed coverages are not\ne. Peril causing damage to the neighbor was insured under the insured’s own policy.",
      "back": "Ans: A\nwhen income is produced from down buildings, net annual rent\nExplanation: A: when income is produced from down buildings, net annual rent"
    },
    {
      "id": "C131",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 4. True to Owner?\na. A bailee is someone who has temporary custody of personal property of another for a\nb. Excludes: glass, lettering, ornamentation, tapes/foils to the glass\nc. repair, replace or rebuild without deduction for depreciation\nd. when insureds claim the previous three methods have failed to\ne. can select individual employees with different limits. Discovery period of 2",
      "back": "Ans: D\nwhen insureds claim the previous three methods have failed to\nExplanation: D: when insureds claim the previous three methods have failed to"
    },
    {
      "id": "C132",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 5. Broad Evidence Rule?\na. Equipment\nb. ties together all four of the above.\nc. Ordinary Payroll Exclusion\nd. 19. The requirements of the Stated Amount Co-insurance Clause?\ne. magnetic door, window contacts, motion detectors",
      "back": "Ans: B\nties together all four of the above.\nExplanation: B: ties together all four of the above."
    },
    {
      "id": "C133",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Reinsurance?\na. excluded due to high exposure\nb. Scheduled - when property is itemized with a limit each\nc. provides coverage for damage to that part of the building\nd. all insurers share in both premiums collected and losses incurred. The contract\ne. 3. War, Invasion, act of foreign enemy",
      "back": "Ans: D\nall insurers share in both premiums collected and losses incurred. The contract\nExplanation: D: all insurers share in both premiums collected and losses incurred. The contract"
    },
    {
      "id": "C134",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Subscription?\na. 3 ways to insure commercial property\nb. alerts broker to possible loss exposures, ensures needed coverages are not\nc. Assessed valuation\nd. each insurer contracts with the insured for a specific limit of liability. If one\ne. determine the R/C of the property, then subtract rate of",
      "back": "Ans: D\neach insurer contracts with the insured for a specific limit of liability. If one\nExplanation: D: each insurer contracts with the insured for a specific limit of liability. If one"
    },
    {
      "id": "C135",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Stated Amount of Co-Insurance Clause?\na. All risks coverage, including damage to letterwork.\nb. Actual or attempted robbery of custodian\nc. For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating\nd. method used to insure commercial building, stock and\ne. the insured must file a statement of values with the",
      "back": "Ans: E\nthe insured must file a statement of values with the\nExplanation: E: the insured must file a statement of values with the"
    },
    {
      "id": "C136",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Additional Clauses:?\na. 3 ways to insure commercial property\nb. 4. Building Damage by Theft - provides coverage for damage to that part of the building\nc. 1. Physical protection - steel doors, locks, bars\nd. Loss to systems (hardware)\ne. 1. Reinstatement Clause - insureds will have as much insurance after a loss as they did",
      "back": "Ans: E\n1. Reinstatement Clause - insureds will have as much insurance after a loss as they did\nExplanation: E: 1. Reinstatement Clause - insureds will have as much insurance after a loss as they did"
    },
    {
      "id": "C137",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 1. Reinstatement Clause?\na. types of losses expected from everyday operation\nb. there is a need to project lost income for up to two years.\nc. insureds will have as much insurance after a loss as they did\nd. Both the owner of the property and the bailee has insurable interest\ne. the inertia of a body that tends to move away from center it revolves",
      "back": "Ans: C\ninsureds will have as much insurance after a loss as they did\nExplanation: C: insureds will have as much insurance after a loss as they did"
    },
    {
      "id": "C138",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 2. Subrogation?\na. Difference between package and manuscript policies\nb. 6. Vacancy Permit - on standard policy, vacant/unoccupied is not covered after 30 days.\nc. the insurer retains the right to step into the shoes of the insured and sue\nd. including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,\ne. repair, replace or rebuild without deduction for depreciation",
      "back": "Ans: C\nthe insurer retains the right to step into the shoes of the insured and sue\nExplanation: C: the insurer retains the right to step into the shoes of the insured and sue"
    },
    {
      "id": "C139",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3. Property Protection Systems?\na. Usually covers if its named perils/theft - this extends the definition to other causes of\nb. this extends the definition to other causes of\nc. definition differs from legal, there has to be marks of forcible entry or exit.\nd. insured needs to notify of any interruption to, or flaw or\ne. Caused by faulty workmanship, errors in material and design.",
      "back": "Ans: D\ninsured needs to notify of any interruption to, or flaw or\nExplanation: D: insured needs to notify of any interruption to, or flaw or"
    },
    {
      "id": "C140",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 4. Premium Adjustment?\na. must keep records of all insured property for verification.\nb. unless its directly by a peril\nc. owner/employees control it, the weakness is they can forget to\nd. Premium charged is based on the completed value of the project.\ne. Applicable to stock",
      "back": "Ans: E\nApplicable to stock\nExplanation: E: Applicable to stock"
    },
    {
      "id": "C141",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Applicable to stock?\na. the insured is obligated to restart operations either\nb. Allows over-insured clause for premium refund. Claim must be within 6 months.\nc. except for ensuing loss caused by named peril.\nd. A bailee is someone who has temporary custody of personal property of another for a\ne. p) Bylaws - no coverage for increased cost through enforcement of bylaw",
      "back": "Ans: B\nAllows over-insured clause for premium refund. Claim must be within 6 months.\nExplanation: B: Allows over-insured clause for premium refund. Claim must be within 6 months."
    },
    {
      "id": "C142",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 5. Verification of Values?\na. 2 Coverage Limits\nb. Scheduled - when property is itemized with a limit each\nc. enter the insured’s premises at all reasonable times to inspect.\nd. Covers actual cost of reproduction\ne. the insured is obligated to restart operations either",
      "back": "Ans: C\nenter the insured’s premises at all reasonable times to inspect.\nExplanation: C: enter the insured’s premises at all reasonable times to inspect."
    },
    {
      "id": "C143",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 6. Valuations?\na. will not ignite or burn when subjected to fire\nb. Under 1 form\nc. used to guard interior and restrict entry where valuables are stored.\nd. insurer retains the right to inspect premises at reasonable times.\ne. Defines basis for valuation of losses for different CLASS of property",
      "back": "Ans: E\nDefines basis for valuation of losses for different CLASS of property\nExplanation: E: Defines basis for valuation of losses for different CLASS of property"
    },
    {
      "id": "C144",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Unsold Stock - ACV?\na. Sold Stock - selling price less the discounts\nb. 1 year after expiry to make a claim.\nc. Property of every description\nd. except when due to named peril or theft/attempted theft\ne. 13. Difference between reinsurance and subscription",
      "back": "Ans: A\nSold Stock - selling price less the discounts\nExplanation: A: Sold Stock - selling price less the discounts"
    },
    {
      "id": "C145",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Sold Stock?\na. selling price less the discounts\nb. 3. Impact by aircraft/land vehicle\nc. Three Ways Property Can Be Valued:\nd. This can also be a Transportation Floater Rider (Limited Form) - provided on named perils.\ne. Tenant’s improvements - additions or charges rented property at the expense of the",
      "back": "Ans: A\nselling price less the discounts\nExplanation: A: selling price less the discounts"
    },
    {
      "id": "C146",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Property of Others Special Basis of Settlement?\na. Licensed real estate appraiser\nb. Very detailed application form\nc. 1. Tenant’s Improvements\nd. convertible, valuable, portable.\ne. A bailee is someone who has temporary custody of personal property of another for a",
      "back": "Ans: C\n1. Tenant’s Improvements\nExplanation: C: 1. Tenant’s Improvements"
    },
    {
      "id": "C147",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 1. Tenant’s Improvements?\na. Scheduled - items specifically identified on policy\nb. 1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation\nc. if repaired with due diligence and dispatch, the insured is entitled to claim all costs\nd. Can be combined with Earthquake (“Flake”)\ne. Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system",
      "back": "Ans: C\nif repaired with due diligence and dispatch, the insured is entitled to claim all costs\nExplanation: C: if repaired with due diligence and dispatch, the insured is entitled to claim all costs"
    },
    {
      "id": "C148",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 2. Records?\na. period of vacancy specified on form. Duration is on underwriter’s discretion\nb. 2. Forcible entry into protected enclosures\nc. Extensions Available\nd. Excludes: glass, lettering, ornamentation, tapes/foils to the glass\ne. Manually maintained records are blank value only + costs to copy from other source",
      "back": "Ans: E\nManually maintained records are blank value only + costs to copy from other source\nExplanation: E: Manually maintained records are blank value only + costs to copy from other source"
    },
    {
      "id": "C149",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Chapter 1 KEY TERMS?\na. Actual Cash Value - fair and reasonable price property would be on the market minus\nb. g) Smoke from cumulative agricultural or industrial operations\nc. Insurers will pay a loss even when they cannot tie an employee to a loss.\nd. b) Flood - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,\ne. Insures goods usual to the business.",
      "back": "Ans: A\nActual Cash Value - fair and reasonable price property would be on the market minus\nExplanation: A: Actual Cash Value - fair and reasonable price property would be on the market minus"
    },
    {
      "id": "C150",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Actual Cash Value?\na. Canadian Currency Clause - all losses are paid in CAD\nb. Expert opinion\nc. each rider identifies and defines classes of property such as\nd. Rider - document issued by insurer that adds coverages.\ne. fair and reasonable price property would be on the market minus",
      "back": "Ans: E\nfair and reasonable price property would be on the market minus\nExplanation: E: fair and reasonable price property would be on the market minus"
    },
    {
      "id": "C151",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes depreciation?\na. f) Trade losses\nb. Insured needs to keep records in the receptacle described on the form when not in use\nc. Between the primary insurer and the reinsurer\nd. All insurers share in premiums and losses\ne. All property (blanket) - policy of insurance that covers two or more items without listing",
      "back": "Ans: E\nAll property (blanket) - policy of insurance that covers two or more items without listing\nExplanation: E: All property (blanket) - policy of insurance that covers two or more items without listing"
    },
    {
      "id": "C152",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes All property (blanket)?\na. You can endorse temporary storage at insured’s warehouse or loading station\nb. On premises only\nc. policy of insurance that covers two or more items without listing\nd. 1. Standard Bill of Lading - reflects amount liable under the tariff\ne. Cash price value in a fair market, allow for depreciation",
      "back": "Ans: C\npolicy of insurance that covers two or more items without listing\nExplanation: C: policy of insurance that covers two or more items without listing"
    },
    {
      "id": "C153",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes separate amounts each?\na. Scheduled - when property is itemized with a limit each\nb. rate over and above the fire rate\nc. No bearing on the amount of payment made by the insurer\nd. there is a need to project lost income for up to two years.\ne. fair and reasonable price property would be on the market minus",
      "back": "Ans: A\nScheduled - when property is itemized with a limit each\nExplanation: A: Scheduled - when property is itemized with a limit each"
    },
    {
      "id": "C154",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Scheduled?\na. provides a solution to over-insurance by allowing a refund of the\nb. e) Animals/fish/birds - except when due to named peril or theft/attempted theft\nc. if not, the insurer will reduce the payable amount.\nd. Grouping risks based on categories on their probability for a loss.\ne. when property is itemized with a limit each",
      "back": "Ans: E\nwhen property is itemized with a limit each\nExplanation: E: when property is itemized with a limit each"
    },
    {
      "id": "C155",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Replacement Value?\na. failure in working mechanism\nb. 3. Released Bill of Lading - releases the carrier from liability of goods. Used when value of\nc. 1. Ensures same perils as property policy\nd. the cash value or cost to replace an item\ne. Damage from neglect of shipper, bad packaging, rough handling",
      "back": "Ans: D\nthe cash value or cost to replace an item\nExplanation: D: the cash value or cost to replace an item"
    },
    {
      "id": "C156",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Property of every description?\na. Rider - document issued by insurer that adds coverages.\nb. covers the cost of removing debris of the property after loss. Shall not\nc. methods used to secure access when business is closed.\nd. location specific, restrictions apply.\ne. method used to insure commercial building, stock and",
      "back": "Ans: E\nmethod used to insure commercial building, stock and\nExplanation: E: method used to insure commercial building, stock and"
    },
    {
      "id": "C157",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes equipment under one limit?\na. includes following perils\nb. Not greater than either of 2% of the amount of insurance or $5,000\nc. Manually maintained records are blank value only + costs to copy from other source\nd. Tenant’s improvements - additions or charges rented property at the expense of the\ne. includes all means of taking without consent",
      "back": "Ans: D\nTenant’s improvements - additions or charges rented property at the expense of the\nExplanation: D: Tenant’s improvements - additions or charges rented property at the expense of the"
    },
    {
      "id": "C158",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Tenant’s improvements?\na. additions or charges rented property at the expense of the\nb. When damage is to media/data ONLY, business interruption is limited to 30 days max\nc. Insurers will pay a loss even when they cannot tie an employee to a loss.\nd. EXCLUDES liability due to cessation of work, theft/attempted theft, flood or\ne. Securities is limited to ACV on the business day of the loss. Other",
      "back": "Ans: A\nadditions or charges rented property at the expense of the\nExplanation: A: additions or charges rented property at the expense of the"
    },
    {
      "id": "C159",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Condition?\na. a condition imposed to do or not do something\nb. c. This also includes contents shipped by Parcel Post. The amount of insurance is\nc. the inertia of a body that tends to move away from center it revolves\nd. lacks an essential element to be enforceable by law\ne. Can be combined with Earthquake (“Flake”)",
      "back": "Ans: A\na condition imposed to do or not do something\nExplanation: A: a condition imposed to do or not do something"
    },
    {
      "id": "C160",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Warranty?\na. Theft from window display area inside the premises while premises are open\nb. indirect and not direct.\nc. a promise that certain facts are true and will remain so.\nd. Rider - document issued by insurer that adds coverages.\ne. Applies off premises but only the lesser of 10% or $5000",
      "back": "Ans: C\na promise that certain facts are true and will remain so.\nExplanation: C: a promise that certain facts are true and will remain so."
    },
    {
      "id": "C161",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Fraudulent Misrepresentation?\na. 1. Consequential Loss Assumption Clause - Cold Storage\nb. Pays all claims\nc. a false statement made knowing to be false\nd. loss does not apply to first $1000 of any loss and does not\ne. adjusted based on reported values at the end of the",
      "back": "Ans: C\na false statement made knowing to be false\nExplanation: C: a false statement made knowing to be false"
    },
    {
      "id": "C162",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Material Fact?\na. 4. Continues beyond expiry.\nb. Defines basis for valuation of losses for different CLASS of property\nc. selling price less the discounts\nd. Ties together all four of the above approaches and considers:\ne. a fact which if the insurer knew about, would affect the decision to insure",
      "back": "Ans: E\na fact which if the insurer knew about, would affect the decision to insure\nExplanation: E: a fact which if the insurer knew about, would affect the decision to insure"
    },
    {
      "id": "C163",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes it or not?\na. Very detailed application form\nb. Obsolescence\nc. c. This also includes contents shipped by Parcel Post. The amount of insurance is\nd. Loading - rate over and above the fire rate\ne. Subrogation - step into the shoes of the party compensated and sue",
      "back": "Ans: E\nSubrogation - step into the shoes of the party compensated and sue\nExplanation: E: Subrogation - step into the shoes of the party compensated and sue"
    },
    {
      "id": "C164",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Subrogation?\na. Insured shall have as much insurance after a loss as they did before it\nb. step into the shoes of the party compensated and sue\nc. most extensive form. The policy is defined by exclusions\nd. Insures goods usual to the business.\ne. 1. Extra Expense Endorsement Form",
      "back": "Ans: B\nstep into the shoes of the party compensated and sue\nExplanation: B: step into the shoes of the party compensated and sue"
    },
    {
      "id": "C165",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Subscription Policy?\na. Actual Cash Value - fair and reasonable price property would be on the market minus\nb. 1. Removal Clause\nc. group of insurers participating in a policy\nd. Market value\ne. Rust/corrosion",
      "back": "Ans: C\ngroup of insurers participating in a policy\nExplanation: C: group of insurers participating in a policy"
    },
    {
      "id": "C166",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Void contract?\na. lacks an essential element to be enforceable by law\nb. o) Settling/Expansion/Contraction - ONLY applies to building damage\nc. Items that are covered\nd. Rental value\ne. Insured must confirm amount collected is less than outstanding and they are unable to",
      "back": "Ans: A\nlacks an essential element to be enforceable by law\nExplanation: A: lacks an essential element to be enforceable by law"
    },
    {
      "id": "C167",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes CHAPTER 2: UNDERWRITING?\na. o) Settling/Expansion/Contraction - ONLY applies to building damage\nb. must be insured separately\nc. A bailee is someone who has temporary custody of personal property of another for a\nd. 26. Three obligations placed upon insureds by the Property Protection Systems clause\ne. Fact-Find Survey uses",
      "back": "Ans: E\nFact-Find Survey uses\nExplanation: E: Fact-Find Survey uses"
    },
    {
      "id": "C168",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Fact-Find Survey uses?\na. Sold Stock - selling price less the discounts\nb. Identify coverages needed, help determine cvgs needed\nc. location specific, restrictions apply.\nd. Between the primary insurer and the reinsurer\ne. Locally Supervised - owner/employees control it, the weakness is they can forget to",
      "back": "Ans: B\nIdentify coverages needed, help determine cvgs needed\nExplanation: B: Identify coverages needed, help determine cvgs needed"
    },
    {
      "id": "C169",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Identify coverages needed, help determine cvgs needed?\na. maximum payable for any one accident\nb. Checklist - alerts broker to possible loss exposures, ensures needed coverages are not\nc. No coverage for loss/damage caused by explosion of boilers.\nd. outlines the basic rules\ne. a central station ensures it is turned on at arranged times.",
      "back": "Ans: B\nChecklist - alerts broker to possible loss exposures, ensures needed coverages are not\nExplanation: B: Checklist - alerts broker to possible loss exposures, ensures needed coverages are not"
    },
    {
      "id": "C170",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Checklist?\na. A bailee is someone who has temporary custody of personal property of another for a\nb. notify insurer ASAP, provide sworn proof of loss\nc. changes requested effective only when consented to by the insurer.\nd. Extensions Available\ne. alerts broker to possible loss exposures, ensures needed coverages are not",
      "back": "Ans: E\nalerts broker to possible loss exposures, ensures needed coverages are not\nExplanation: E: alerts broker to possible loss exposures, ensures needed coverages are not"
    },
    {
      "id": "C171",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Physical and Other Qualities of Commercial Risks?\na. each rider identifies and defines classes of property such as\nb. Building materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,\nc. all property owned by the insured is covered by a single limit of insurance\nd. magnetic door, window contacts, motion detectors\ne. o) Settling/Expansion/Contraction - ONLY applies to building damage",
      "back": "Ans: B\nBuilding materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,\nExplanation: B: Building materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,"
    },
    {
      "id": "C172",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Building materials best to worst?\na. Available in limited or broad form. Insures values of materials and cost of labour.\nb. Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are\nc. fire-resistive, non combustible, heavy timber, ordinary,\nd. 1. Ensures same perils as property policy\ne. all insurers share in both premiums collected and losses incurred. The contract",
      "back": "Ans: C\nfire-resistive, non combustible, heavy timber, ordinary,\nExplanation: C: fire-resistive, non combustible, heavy timber, ordinary,"
    },
    {
      "id": "C173",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes frame?\na. Central Station Supervised - a central station ensures it is turned on at arranged times.\nb. ties together all four of the above.\nc. For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating\nd. Detachment - distance between insured property and other commercially rated\ne. Caused by faulty workmanship, errors in material and design.",
      "back": "Ans: C\nFor buildings over 25+ years - check roof, wiring, breakers, plumbing, heating\nExplanation: C: For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating"
    },
    {
      "id": "C174",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes For buildings over 25+ years?\na. covers restaurant loss of income if a major customer is lost\nb. 1. Fire/Lightning\nc. This clause extends coverage under the commercial property to include\nd. Acts of violence or threatened violence must be present\ne. check roof, wiring, breakers, plumbing, heating",
      "back": "Ans: E\ncheck roof, wiring, breakers, plumbing, heating\nExplanation: E: check roof, wiring, breakers, plumbing, heating"
    },
    {
      "id": "C175",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Underwriting Activities?\na. Cash price value in a fair market, allow for depreciation\nb. unless its directly by a peril\nc. 1. Risk Selection\nd. Provides means of ensuring predictable increases in stock values in advance.\ne. alerts broker to possible loss exposures, ensures needed coverages are not",
      "back": "Ans: C\n1. Risk Selection\nExplanation: C: 1. Risk Selection"
    },
    {
      "id": "C176",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes 1. Risk Selection?\na. includes following perils\nb. Primary duty is to select risks most profitable to the company. Improper screening can\nc. Coverage only at premises\nd. expert opinion of licensed real estate appraiser\ne. each rider identifies and defines classes of property such as",
      "back": "Ans: B\nPrimary duty is to select risks most profitable to the company. Improper screening can\nExplanation: B: Primary duty is to select risks most profitable to the company. Improper screening can"
    },
    {
      "id": "C177",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes 2. Risk Classification?\na. Resale success\nb. Grouping risks based on categories on their probability for a loss.\nc. Pays costs for auditors to certify and prove the loss.\nd. owner controls system and is not required to inform the\ne. 2. Debris Removal Clause",
      "back": "Ans: B\nGrouping risks based on categories on their probability for a loss.\nExplanation: B: Grouping risks based on categories on their probability for a loss."
    },
    {
      "id": "C178",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Helps determine proper premium?\na. b) Flood - including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,\nb. 1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or\nc. materials to store data\nd. 3. Rate-Making - factors that influence the premium are application info, internal and\ne. Resale success",
      "back": "Ans: D\n3. Rate-Making - factors that influence the premium are application info, internal and\nExplanation: D: 3. Rate-Making - factors that influence the premium are application info, internal and"
    },
    {
      "id": "C179",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes 3. Rate-Making?\na. a false statement made knowing to be false\nb. factors that influence the premium are application info, internal and\nc. increases building insurance during the policy period to reflect\nd. 2. Electronic protection - magnetic door, window contacts, motion detectors\ne. is the insured or a partner of the insured or any employee with care outside",
      "back": "Ans: B\nfactors that influence the premium are application info, internal and\nExplanation: B: factors that influence the premium are application info, internal and"
    },
    {
      "id": "C180",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Organization?\na. wrongful taking by force or fear. Includes unlawful act witnessed by custodian\nb. steel doors, locks, bars\nc. Hard Market - characterized by an increase in the loss ratio bought on by low rates in a\nd. can be for single projects or installation. But will be mostly issued on an\ne. Insurers will pay a loss even when they cannot tie an employee to a loss.",
      "back": "Ans: C\nHard Market - characterized by an increase in the loss ratio bought on by low rates in a\nExplanation: C: Hard Market - characterized by an increase in the loss ratio bought on by low rates in a"
    },
    {
      "id": "C181",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Hard Market?\na. Ordinary Payroll Exclusion\nb. items specifically identified on policy\nc. characterized by an increase in the loss ratio bought on by low rates in a\nd. the inertia of a body that tends to move away from center it revolves\ne. will continue during the interruption such as accounts payables, mortgage,",
      "back": "Ans: C\ncharacterized by an increase in the loss ratio bought on by low rates in a\nExplanation: C: characterized by an increase in the loss ratio bought on by low rates in a"
    },
    {
      "id": "C182",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Soft Market?\na. fire-resistive, non combustible, heavy timber, ordinary,\nb. intense competition between insurers resulting in unusually low rates.\nc. owner controls system and is not required to inform the\nd. Each insurer contracts with the insured for a specific limit of liability\ne. fair and reasonable price property would be on the market minus",
      "back": "Ans: B\nintense competition between insurers resulting in unusually low rates.\nExplanation: B: intense competition between insurers resulting in unusually low rates."
    },
    {
      "id": "C183",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 4. Policy Service?\na. By-Laws Exclusion - can be endorsed, but having to comply with building by-laws is not\nb. By-Laws Coverage - when complying to by-laws results in an increase in time to\nc. Obsolescence\nd. Contains 5 Insuring Agreements (insured can select any or all coverages and are continuous\ne. preparation of original policy, changes requiring endorsements, billing",
      "back": "Ans: E\npreparation of original policy, changes requiring endorsements, billing\nExplanation: E: preparation of original policy, changes requiring endorsements, billing"
    },
    {
      "id": "C184",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes of premiums?\na. By-Laws Exclusion - can be endorsed, but having to comply with building by-laws is not\nb. Three Ways Property Can Be Valued:\nc. Chapter 2 KEY TERMS\nd. when complying to by-laws results in an increase in time to\ne. Additions or changes to rented premises by a tenant at his/her own expense.",
      "back": "Ans: C\nChapter 2 KEY TERMS\nExplanation: C: Chapter 2 KEY TERMS"
    },
    {
      "id": "C185",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Chapter 2 KEY TERMS?\na. 1. Risk Selection\nb. Common Hazards - certain hazards or conditions to all buildings that influence their\nc. Wages In Lieu of Notice Endorsement - coverage can be provided for the wages of\nd. Scheduled - when property is itemized with a limit each\ne. including waves, tidal waves, tsunamis. Does not apply to loss directly from fire,",
      "back": "Ans: B\nCommon Hazards - certain hazards or conditions to all buildings that influence their\nExplanation: B: Common Hazards - certain hazards or conditions to all buildings that influence their"
    },
    {
      "id": "C186",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Common Hazards?\na. Adds coverage for other perils and is available on blanket or scheduled basis.\nb. certain hazards or conditions to all buildings that influence their\nc. Subscription\nd. Covers property at location not indicated only when it is necessary to\ne. 3. Builder’s Risk - available in broad form or named perils",
      "back": "Ans: B\ncertain hazards or conditions to all buildings that influence their\nExplanation: B: certain hazards or conditions to all buildings that influence their"
    },
    {
      "id": "C187",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes potential for loss?\na. All risks basis\nb. Detachment - distance between insured property and other commercially rated\nc. the amount of insurance is only an estimate, the amount of payment\nd. 2 - Peril causing damage to the neighbor was insured under the insured’s own policy.\ne. Data Exclusion",
      "back": "Ans: B\nDetachment - distance between insured property and other commercially rated\nExplanation: B: Detachment - distance between insured property and other commercially rated"
    },
    {
      "id": "C188",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Detachment?\na. Insures goods usual to the business.\nb. indirect and not direct.\nc. distance between insured property and other commercially rated\nd. Ties together all four of the above approaches and considers:\ne. negotiated when standard bill does not accurately reflect value of",
      "back": "Ans: C\ndistance between insured property and other commercially rated\nExplanation: C: distance between insured property and other commercially rated"
    },
    {
      "id": "C189",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Fire resistive/resistant?\na. No coverage for vehicles belonging to operating under insured or their\nb. Damage from neglect of shipper, bad packaging, rough handling\nc. No coverage when storing property of others, which can be endorsed through a\nd. portion applies to in transit or within other premises\ne. describes buildings that have met min standards hours",
      "back": "Ans: E\ndescribes buildings that have met min standards hours\nExplanation: E: describes buildings that have met min standards hours"
    },
    {
      "id": "C190",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes withstanding controlled fire?\na. Non combustible - will not ignite or burn when subjected to fire\nb. Money in vending machine or coin-operated machines\nc. covers restaurant loss of income if a major customer is lost\nd. Manually maintained records are blank value only + costs to copy from other source\ne. Adds coverage for other perils and is available on blanket or scheduled basis.",
      "back": "Ans: A\nNon combustible - will not ignite or burn when subjected to fire\nExplanation: A: Non combustible - will not ignite or burn when subjected to fire"
    },
    {
      "id": "C191",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Which of the following best describes Non combustible?\na. charged based on annual receipts, and is provisional. Insured required to\nb. Covers actual cost of reproduction\nc. will not ignite or burn when subjected to fire\nd. Non combustible - will not ignite or burn when subjected to fire\ne. All risks basis",
      "back": "Ans: C\nwill not ignite or burn when subjected to fire\nExplanation: C: will not ignite or burn when subjected to fire"
    },
    {
      "id": "C192",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes CHAPTER 3: COMMERCIAL PROPERTY POLICY?\na. FIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model\nb. Cash value to replace\nc. Unoccupied - lack of habitual presence. Complete with contents but owner is absent.\nd. Includes expenses for removing debris of insured property or property blown into\ne. Total Limits of property in the custody of all sales",
      "back": "Ans: A\nFIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model\nExplanation: A: FIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model"
    },
    {
      "id": "C193",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes FIRE POLICY?\na. narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model\nb. Perils Excluded\nc. 3 ways to insure commercial property\nd. Does not apply if property is insured by the owner unless he is obligated to insure it\ne. Income approach",
      "back": "Ans: A\nnarrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model\nExplanation: A: narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model"
    },
    {
      "id": "C194",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes manufactured gas?\na. Replacement value\nb. Primary duty is to select risks most profitable to the company. Improper screening can\nc. Ordinary Payroll - Limited Coverage - 90 or 180 day Option\nd. Perils Excluded\ne. Usually covers if its named perils/theft - this extends the definition to other causes of",
      "back": "Ans: D\nPerils Excluded\nExplanation: D: Perils Excluded"
    },
    {
      "id": "C195",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Perils Excluded?\na. Scheduled - items specifically identified on policy\nb. 1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or\nc. Replacement shall be on the same or adjacent site\nd. Contractor’s tools and equipment\ne. Actual Cash Value - fair and reasonable price property would be on the market minus",
      "back": "Ans: B\n1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or\nExplanation: B: 1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or"
    },
    {
      "id": "C196",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 2. Application of heat?\na. if business is sold, coverage does not extend to the new\nb. ONLY applies to building damage\nc. considered in control of insured and are trade risks. Except if fire\nd. Grouping risks based on categories on their probability for a loss.\ne. Provides means of ensuring predictable increases in stock values in advance.",
      "back": "Ans: C\nconsidered in control of insured and are trade risks. Except if fire\nExplanation: C: considered in control of insured and are trade risks. Except if fire"
    },
    {
      "id": "C197",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes spreads beyond excluded property to other property insured?\na. Portable wall dividers separating work areas in a sales office\nb. narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model\nc. deterioration caused by ordinary and reasonable use of subject matter.\nd. duplicating sensitive data/storing off premises, requiring two\ne. 3. War, Invasion, act of foreign enemy",
      "back": "Ans: E\n3. War, Invasion, act of foreign enemy\nExplanation: E: 3. War, Invasion, act of foreign enemy"
    },
    {
      "id": "C198",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3. War, Invasion, act of foreign enemy?\na. Items that are covered\nb. explosion of boilers\nc. portion applies to in transit or within other premises\nd. owner controls it and do not send to a control center.\ne. 4. Nuclear Incident. Except for loss or damage directly results from named peril",
      "back": "Ans: E\n4. Nuclear Incident. Except for loss or damage directly results from named peril\nExplanation: E: 4. Nuclear Incident. Except for loss or damage directly results from named peril"
    },
    {
      "id": "C199",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Property Excluded?\na. Pays costs for auditors to certify and prove the loss.\nb. coverage can be provided for the wages of\nc. document issued by insurer that adds coverages.\nd. 3. Impact by aircraft/land vehicle\ne. 1. Money, Bullion, Precious Metals, Securities, Stamps - excluded due to high exposure",
      "back": "Ans: E\n1. Money, Bullion, Precious Metals, Securities, Stamps - excluded due to high exposure\nExplanation: E: 1. Money, Bullion, Precious Metals, Securities, Stamps - excluded due to high exposure"
    },
    {
      "id": "C200",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 1. Money, Bullion, Precious Metals, Securities, Stamps?\na. Perils insured - perils such as kidnapping, robbery, safe burglary and forgery are\nb. g) Automobiles/watercraft - only insured if held on sale as stock or unlicensed for\nc. failure in electrical mechanism\nd. covers the cost of removing debris of the property after loss. Shall not\ne. excluded due to high exposure",
      "back": "Ans: E\nexcluded due to high exposure\nExplanation: E: excluded due to high exposure"
    },
    {
      "id": "C201",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 2. Automobiles/Watercraft?\na. certain hazards or conditions to all buildings that influence their\nb. except for sale as stock and except on the premises\nc. if business is sold, coverage does not extend to the new\nd. k) Nuclear incident - except for ensuing loss caused by named peril.\ne. Pays costs for auditors to certify and prove the loss.",
      "back": "Ans: B\nexcept for sale as stock and except on the premises\nExplanation: B: except for sale as stock and except on the premises"
    },
    {
      "id": "C202",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes unlicensed used as in the business?\na. can be endorsed.\nb. Property sold under written deferred payment plan agreement\nc. period of vacancy specified on form. Duration is on underwriter’s discretion\nd. Controlled by the primary insurer\ne. 3. Property at locations with the knowledge is vacant or unoccupied for more than 30",
      "back": "Ans: E\n3. Property at locations with the knowledge is vacant or unoccupied for more than 30\nExplanation: E: 3. Property at locations with the knowledge is vacant or unoccupied for more than 30"
    },
    {
      "id": "C203",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes Extensions of Coverage?\na. 1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation\nb. Actual or attempted robbery of custodian\nc. 1. Removal Clause - Covers property at location not indicated only when it is necessary to\nd. All risks basis\ne. will continue during the interruption such as accounts payables, mortgage,",
      "back": "Ans: C\n1. Removal Clause - Covers property at location not indicated only when it is necessary to\nExplanation: C: 1. Removal Clause - Covers property at location not indicated only when it is necessary to"
    },
    {
      "id": "C204",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes 1. Removal Clause?\na. Loss to systems (hardware)\nb. Covers property at location not indicated only when it is necessary to\nc. Rental value\nd. Fact-Find Survey uses\ne. contents removed also",
      "back": "Ans: B\nCovers property at location not indicated only when it is necessary to\nExplanation: B: Covers property at location not indicated only when it is necessary to"
    },
    {
      "id": "C205",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes 2. Debris Removal?\na. 2 Coverage Limits\nb. Covers actual cost of reproduction\nc. 3 coverages\nd. covers the cost of removing debris of the property after loss. Shall not\ne. Blank value only if property is not replaced or reproduced",
      "back": "Ans: D\ncovers the cost of removing debris of the property after loss. Shall not\nExplanation: D: covers the cost of removing debris of the property after loss. Shall not"
    },
    {
      "id": "C206",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes NAMED PERILS?\na. failure in working mechanism\nb. ONLY applies to building damage\nc. includes following perils\nd. Applies off premises but only the lesser of 10% or $5000\ne. No coverage through aircraft taxied or moved",
      "back": "Ans: C\nincludes following perils\nExplanation: C: includes following perils"
    },
    {
      "id": "C207",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes NAMED PERILS - includes following perils?\na. Inherent Vice - something that naturally causes its own demise over time. Like\nb. Inherent vice\nc. Determining the need - assess potential for interruption due to loss.\nd. 1. Fire/Lightning\ne. 1. Forcible entry into building",
      "back": "Ans: D\n1. Fire/Lightning\nExplanation: D: 1. Fire/Lightning"
    },
    {
      "id": "C208",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes 1. Fire/Lightning?\na. rate over and above the fire rate\nb. a) Wear and tear, rust and corrosion, gradual deterioration\nc. on standard policy, vacant/unoccupied is not covered after 30 days.\nd. 2. Explosion\ne. magnetic door, window contacts, motion detectors",
      "back": "Ans: D\n2. Explosion\nExplanation: D: 2. Explosion"
    },
    {
      "id": "C209",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes 2. Explosion?\na. Market value of before / after the loss\nb. the cash value or cost to replace an item\nc. Cost Approach\nd. describes buildings that have met min standards hours\ne. No coverage for loss/damage caused by explosion of boilers.",
      "back": "Ans: E\nNo coverage for loss/damage caused by explosion of boilers.\nExplanation: E: No coverage for loss/damage caused by explosion of boilers."
    },
    {
      "id": "C210",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes manually portable gas cylinders?\na. Straight line / Plateau accelerated method\nb. Resale success\nc. Expert opinion\nd. intense competition between insurers resulting in unusually low rates.\ne. Excludes mechanical breakdown and centrifugal force",
      "back": "Ans: E\nExcludes mechanical breakdown and centrifugal force\nExplanation: E: Excludes mechanical breakdown and centrifugal force"
    },
    {
      "id": "C211",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Excludes mechanical breakdown and centrifugal force?\na. k) Nuclear incident - except for ensuing loss caused by named peril.\nb. Same as commercial building and stock named perils\nc. 6. Espionage\nd. Subscription\ne. 3. Impact by aircraft/land vehicle",
      "back": "Ans: E\n3. Impact by aircraft/land vehicle\nExplanation: E: 3. Impact by aircraft/land vehicle"
    },
    {
      "id": "C212",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes 3. Impact by aircraft/land vehicle?\na. the cash value or cost to replace an item\nb. when income is produced from down buildings, net annual rent\nc. Impact losses only\nd. run -down buildings = net annual rent with a capitalization rate applied to it\ne. Income approach",
      "back": "Ans: C\nImpact losses only\nExplanation: C: Impact losses only"
    },
    {
      "id": "C213",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes Impact losses only?\na. negotiated when standard bill does not accurately reflect value of\nb. No coverage for cumulative damage\nc. Allows over-insured clause for premium refund. Claim must be within 6 months.\nd. Insures while in custody of sales rep\ne. ONLY applies to building damage",
      "back": "Ans: B\nNo coverage for cumulative damage\nExplanation: B: No coverage for cumulative damage"
    },
    {
      "id": "C214",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes No coverage for cumulative damage?\na. No coverage for vehicles belonging to operating under insured or their\nb. 3. Builder’s Risk - available in broad form or named perils\nc. Cold Storage\nd. Cash value to replace\ne. This Covers: Amounts which cannot be collected AND Interest changes on any loan",
      "back": "Ans: A\nNo coverage for vehicles belonging to operating under insured or their\nExplanation: A: No coverage for vehicles belonging to operating under insured or their"
    },
    {
      "id": "C215",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 6: Crime Insurance",
      "front": "Which of the following best describes employees?\na. insured is entitled to 30 days notice of cancellation, 15 days if it is\nb. Expert opinion\nc. Increase in cost of construction\nd. No coverage through aircraft taxied or moved\ne. 3 coverages",
      "back": "Ans: D\nNo coverage through aircraft taxied or moved\nExplanation: D: No coverage through aircraft taxied or moved"
    },
    {
      "id": "C216",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes No coverage through aircraft taxied or moved?\na. Increase in cost of construction\nb. EXTENSIONS OF COVERAGE\nc. Policy deductible is applied to each and every loss\nd. each insurer contracts with the insured for a specific limit of liability. If one\ne. Cash value to replace",
      "back": "Ans: C\nPolicy deductible is applied to each and every loss\nExplanation: C: Policy deductible is applied to each and every loss"
    },
    {
      "id": "C217",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes 4. Riot/Vandalism/Malicious Acts?\na. Additions or changes to rented premises by a tenant at his/her own expense.\nb. Mechanical/electrical breakdown\nc. Loss of value of the undamaged portion of the building\nd. Acts of violence or threatened violence must be present\ne. POED - A single limit of insurance is stated on the policy",
      "back": "Ans: D\nActs of violence or threatened violence must be present\nExplanation: D: Acts of violence or threatened violence must be present"
    },
    {
      "id": "C218",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following best describes No less than 3 people involved?\na. Wear/tear/loss due to the designed operation\nb. Clear and present danger\nc. actual annual rents\nd. Must make application for refund within 12 months of expiry of policy\ne. Applies off premises but only the lesser of 10% or $5000",
      "back": "Ans: B\nClear and present danger\nExplanation: B: Clear and present danger"
    },
    {
      "id": "C219",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "front": "Which of the following best describes Clear and present danger?\na. contents removed also\nb. Scheduled - when property is itemized with a limit each\nc. When damage is to media/data ONLY, business interruption is limited to 30 days max\nd. Excludes mechanical breakdown and centrifugal force\ne. EXCLUDES liability due to cessation of work, theft/attempted theft, flood or",
      "back": "Ans: E\nEXCLUDES liability due to cessation of work, theft/attempted theft, flood or\nExplanation: E: EXCLUDES liability due to cessation of work, theft/attempted theft, flood or"
    },
    {
      "id": "C220",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Which of the following best describes 5. Smoke?\na. Cost of making goods that are faulty and improper design/workmanship/material\nb. used in low risk commercial operations. The owner\nc. adjusted based on reported values at the end of the\nd. Sudden, unusual and faulty release of smoke.\ne. the insurer retains the right to step into the shoes of the insured and sue",
      "back": "Ans: D\nSudden, unusual and faulty release of smoke.\nExplanation: D: Sudden, unusual and faulty release of smoke."
    },
    {
      "id": "C221",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to Three Ways Property Can Be Valued:?\na. Electronic Data Processing\nb. Actual Cash Value - cost of repair, replace or rebuild minus depreciation\nc. Must identify peak seasons ahead of time.\nd. All risks basis\ne. Perils broader.",
      "back": "Ans: B\nActual Cash Value - cost of repair, replace or rebuild minus depreciation\nExplanation: B: Actual Cash Value - cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": "C222",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to Three Ways Property Can Be Valued:?\na. Ensures same perils as property policy\nb. Replacement Value - same as above, without depreciation deduction.\nc. Fire/Lightning\nd. Does not apply if property is insured by the owner unless he is obligated to insure it\ne. Installation Floater Rider",
      "back": "Ans: B\nReplacement Value - same as above, without depreciation deduction.\nExplanation: B: Replacement Value - same as above, without depreciation deduction."
    },
    {
      "id": "C223",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to Defines basis for valuation of losses for different CLASS of property?\na. Insures loss due to forgery of cheque, draft, or any written promise.\nb. Unsold Stock - ACV\nc. Determining the type - 2 key factors\nd. Either owner or contractor can purchase this.\ne. Adds coverage for other perils and is available on blanket or scheduled basis.",
      "back": "Ans: B\nUnsold Stock - ACV\nExplanation: B: Unsold Stock - ACV"
    },
    {
      "id": "C224",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to Defines basis for valuation of losses for different CLASS of property?\na. Sold Stock - selling price less the discounts\nb. Premium charged is based on the completed value of the project.\nc. Determining the need - assess potential for interruption due to loss.\nd. Coverage only at premises\ne. No coverage for breakdown of refrigeration.",
      "back": "Ans: A\nSold Stock - selling price less the discounts\nExplanation: A: Sold Stock - selling price less the discounts"
    },
    {
      "id": "C225",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to separate amounts each?\na. Pays costs for auditors to certify and prove the loss.\nb. Either owner or contractor can purchase this.\nc. Scheduled - when property is itemized with a limit each\nd. Wear and tear - deterioration caused by ordinary and reasonable use of subject matter.\ne. Increase in cost of construction",
      "back": "Ans: C\nScheduled - when property is itemized with a limit each\nExplanation: C: Scheduled - when property is itemized with a limit each"
    },
    {
      "id": "C226",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to separate amounts each?\na. Peak Season Endorsement\nb. Sign Form\nc. Dishonest/criminal act for insured or its employees. Except for bailees\nd. This Covers: Amounts which cannot be collected AND Interest changes on any loan\ne. Replacement Value - the cash value or cost to replace an item",
      "back": "Ans: E\nReplacement Value - the cash value or cost to replace an item\nExplanation: E: Replacement Value - the cash value or cost to replace an item"
    },
    {
      "id": "C227",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to - Condition - a condition imposed to do or not do something?\na. Must select the amount of insurance for EACH vehicle. Coverage in VEHICLE\nb. Form A - has one limit for all employees. Discovery period of 1 year.\nc. Warranty - a promise that certain facts are true and will remain so.\nd. Mechanical Breakdown - failure in working mechanism\ne. Coverage is less expensive.",
      "back": "Ans: C\nWarranty - a promise that certain facts are true and will remain so.\nExplanation: C: Warranty - a promise that certain facts are true and will remain so."
    },
    {
      "id": "C228",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to - Condition - a condition imposed to do or not do something?\na. Shoplifting\nb. Electronic Data Processing\nc. Both the owner of the property and the bailee has insurable interest\nd. Contract of indemnity - amount of loss is influenced by economic conditions and trends.\ne. Fraudulent Misrepresentation - a false statement made knowing to be false",
      "back": "Ans: E\nFraudulent Misrepresentation - a false statement made knowing to be false\nExplanation: E: Fraudulent Misrepresentation - a false statement made knowing to be false"
    },
    {
      "id": "C229",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to it or not?\na. Contract of indemnity - amount of loss is influenced by economic conditions and trends.\nb. When damage is to media/data ONLY, business interruption is limited to 30 days max\nc. Types of good must be stated on the form.\nd. Repair or replace with property of like kind and quality\ne. Subrogation - step into the shoes of the party compensated and sue",
      "back": "Ans: E\nSubrogation - step into the shoes of the party compensated and sue\nExplanation: E: Subrogation - step into the shoes of the party compensated and sue"
    },
    {
      "id": "C230",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Which of the following applies to it or not?\na. Employee Dishonesty\nb. Subscription Policy - group of insurers participating in a policy\nc. By-Laws\nd. Kidnapping\ne. Book Value - original purchase price minus depreciation and other write-offs. Not",
      "back": "Ans: B\nSubscription Policy - group of insurers participating in a policy\nExplanation: B: Subscription Policy - group of insurers participating in a policy"
    },
    {
      "id": "FCF1",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ by the insured is covered by a single limit of insurance",
      "back": "Ans: All property owned\nExplanation: A: All property owned by the insured is covered by a single limit of insurance"
    },
    {
      "id": "FCF2",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ to equipment insured under her own policy",
      "back": "Ans: Must be added\nExplanation: C: Must be added to equipment insured under her own policy"
    },
    {
      "id": "FCF3",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The _____, the interest of the insured, and the amount of insurance specified, whichever is the least",
      "back": "Ans: actual cash value\nExplanation: C: The actual cash value, the interest of the insured, and the amount of insurance specified, whichever is the least"
    },
    {
      "id": "FCF4",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: loss less than\nExplanation: D: The loss is less than 2% of the amount of insurance and less than $5000"
    },
    {
      "id": "FCF5",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The _____ clause does not require the insured to insure values to 100%",
      "back": "Ans: stated amount co-insurance\nExplanation: B, only the standard co-insurance clause permits the amount of insurance to be less than 100% of the value of the property insured"
    },
    {
      "id": "FCF6",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Notify insurer immediately\nExplanation: A: Notify the insurer immediately when becoming aware of any interruption, flaw or defect in property protection systems"
    },
    {
      "id": "FCF7",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: insured fails disclose\nExplanation: B: The insured fails to disclose previous claims"
    },
    {
      "id": "FCF8",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Complete the missing wording: _____",
      "back": "Ans: They have first\nExplanation: B: They have the first opportunity to qualify a prospect for insurance"
    },
    {
      "id": "FCF9",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Complete the missing wording: _____",
      "back": "Ans: proposal insurance which\nExplanation: D: A proposal for insurance which has been presented to the underwriter for consideration"
    },
    {
      "id": "FCF10",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "A _____ minimum standards in terms of hours it can withstand a controlled test fire",
      "back": "Ans: building has met\nExplanation: A: A building has met minimum standards in terms of hours it can withstand a controlled test fire"
    },
    {
      "id": "FCF11",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "To _____ most likely to suffer a loss",
      "back": "Ans: select those risks\nExplanation: C: To select those risks most likely to suffer a loss"
    },
    {
      "id": "FCF12",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Conditions relating use\nExplanation: D: Conditions relating to the use of tangible property which may cause a peril to occur"
    },
    {
      "id": "FCF13",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 2: Underwriting",
      "front": "Complete the missing wording: _____",
      "back": "Ans: All above\nExplanation: E: All of the above"
    },
    {
      "id": "FCF14",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "12:01 _____ at the address of the named insured as stated on the declarations page",
      "back": "Ans: am standard time\nExplanation: B: 12:01 am standard time at the address of the named insured as stated on the declarations page"
    },
    {
      "id": "FCF15",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "The _____ for 30 days when property is at a location not indicated on the declarations page, and which is a newly acquired location of the insured",
      "back": "Ans: insurer extends coverage\nExplanation: A, Coverage is not automatically extended to newly acquired location of the Insured. This clause will only respond when property was necessarily removed to protect insured property from loss or further loss."
    },
    {
      "id": "FCF16",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Pressure vessels maximum\nExplanation: C: Pressure vessels with a maximum internal working pressure in excess of 15 pounds per square inch"
    },
    {
      "id": "FCF17",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Something within commodity\nExplanation: D, inherent vice is something which causes the spoilage of perishable goods."
    },
    {
      "id": "FCF18",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: It indirect loss\nExplanation: E, The Broad Form Policy covers direct loss only."
    },
    {
      "id": "FCF19",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ on the insured’s premises",
      "back": "Ans: Unlicensed automobiles used\nExplanation: B, Unlicensed vehicles that are used exclusively on the premises are insured."
    },
    {
      "id": "FCF20",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ the explosion of a hot water heater with diameter of 24 inches and an internal pressure of over 25 pounds per square inch used for domestic purposes",
      "back": "Ans: Damage caused by\nExplanation: D, Explosion of a hot water heater with an internal diameter of 24 inches or less is covered regardless of the internal pressure, provided the use is strictly for domestic purposes."
    },
    {
      "id": "FCF21",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Broaden scope coverage\nExplanation: A: Broaden the scope of coverage"
    },
    {
      "id": "FCF22",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: separate policy issued\nExplanation: A: Is a separate policy, issued to cover previously excluded items"
    },
    {
      "id": "FCF23",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Have valid maintenance\nExplanation: A, Even with an Electronic Data Processing Policy, the Insurer can refuse to cover the loss if the Insured does not have a valid maintenance contract."
    },
    {
      "id": "FCF24",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: actual costs copying\nExplanation: E, The costs of copying the information from other sources are covered under the standard commercial property forms."
    },
    {
      "id": "FCF25",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Payments insured help\nExplanation: D, Expediting Expenses are paid out under the Boiler and Machinery policies, to pay for reasonable expenses incurred in making the necessary temporary repairs, and expediting the permanent repairs."
    },
    {
      "id": "FCF26",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: insured has consequential\nExplanation: B, The Consequential Loss Assumption Clause covers loss to stock due to a change in temperature, which was a result of damage to the cooling apparatus."
    },
    {
      "id": "FCF27",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: insured permitted rebuild\nExplanation: E, There is a same site restriction, which would have to be waived if the by-laws no longer permitted the existing type of building to be erected on the site."
    },
    {
      "id": "FCF28",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: loss covered under\nExplanation: B, The Sales Representative Coverage will pay for losses in the Sales Representative's home."
    },
    {
      "id": "FCF29",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "_____ there are increases in stock",
      "back": "Ans: Peak periods where\nExplanation: A, This coverage is only for businesses that experience increases in stock on a few, well-defined occasions, which are detailed in the policy, so that the coverage is automatically in place on those dates."
    },
    {
      "id": "FCF30",
      "type": "flashcard",
      "source": "Original quiz",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "Complete the missing wording: _____",
      "back": "Ans: There no replacement\nExplanation: A, There is a Replacement Cost Endorsement available for stock, although it is less common, and applies to selected items only."
    },
    {
      "id": "FCF31",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: ways insure commercial\nExplanation: C: 3 ways to insure commercial property"
    },
    {
      "id": "FCF32",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - items specifically identified on policy",
      "back": "Ans: Scheduled\nExplanation: D: Scheduled - items specifically identified on policy"
    },
    {
      "id": "FCF33",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ on policy",
      "back": "Ans: items specifically identified\nExplanation: C: items specifically identified on policy"
    },
    {
      "id": "FCF34",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - A single limit of insurance is stated on the policy",
      "back": "Ans: POED\nExplanation: D: POED - A single limit of insurance is stated on the policy"
    },
    {
      "id": "FCF35",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: single limit insurance\nExplanation: A: A single limit of insurance is stated on the policy"
    },
    {
      "id": "FCF36",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: It sets parameters\nExplanation: D: It sets the parameters of coverage on stock to items that are usual to the insured’s business"
    },
    {
      "id": "FCF37",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: insured under obligation\nExplanation: D: When the insured is under obligation to keep insured or for which he is legally liable"
    },
    {
      "id": "FCF38",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 5: Misc. Property Forms",
      "front": "_____ as a bailee for hire",
      "back": "Ans: Exercise ordinary care\nExplanation: C: Exercise ordinary care as a bailee for hire"
    },
    {
      "id": "FCF39",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 5: Misc. Property Forms",
      "front": "Complete the missing wording: _____",
      "back": "Ans: leased/ borrowed loaned\nExplanation: A: leased/ borrowed / loaned equipment"
    },
    {
      "id": "FCF40",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Items that covered\nExplanation: D: Items that are covered"
    },
    {
      "id": "FCF41",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ in insured’s business",
      "back": "Ans: Cash register used\nExplanation: A: Cash register used in insured’s business"
    },
    {
      "id": "FCF42",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ separating work areas in a sales office",
      "back": "Ans: Portable wall dividers\nExplanation: D: Portable wall dividers separating work areas in a sales office"
    },
    {
      "id": "FCF43",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Two bundles shingles\nExplanation: A: Two bundles of shingles stored in the insured’s basement that were left over after a roof was re-shingled"
    },
    {
      "id": "FCF44",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ by a business to package",
      "back": "Ans: Plastic bags used\nExplanation: C: Plastic bags used by a business to package"
    },
    {
      "id": "FCF45",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ on consignment sale bases by local furniture store",
      "back": "Ans: Customer’s funishings held\nExplanation: D: Customer’s funishings held on consignment sale bases by local furniture store"
    },
    {
      "id": "FCF46",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: ways valuing property\nExplanation: C: 3 ways of valuing property"
    },
    {
      "id": "FCF47",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - repair, replace or rebuild less depreciation",
      "back": "Ans: ACV\nExplanation: D: ACV - repair, replace or rebuild less depreciation"
    },
    {
      "id": "FCF48",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: repair replace rebuild\nExplanation: A: repair, replace or rebuild less depreciation"
    },
    {
      "id": "FCF49",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - repair, replace or rebuild without deduction for depreciation",
      "back": "Ans: Replacement Value\nExplanation: A: Replacement Value - repair, replace or rebuild without deduction for depreciation"
    },
    {
      "id": "FCF50",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ less depreciation or other write-offs (not including inflation)",
      "back": "Ans: original purchase price\nExplanation: D: original purchase price less depreciation or other write-offs (not including inflation)"
    },
    {
      "id": "FCF51",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: No bearing amount\nExplanation: C: No bearing on the amount of payment made by the insurer"
    },
    {
      "id": "FCF52",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ be reduced to zero",
      "back": "Ans: Book value can\nExplanation: A: Book value can be reduced to zero"
    },
    {
      "id": "FCF53",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: approaches actual cash\nExplanation: C: 3 approaches for actual cash value"
    },
    {
      "id": "FCF54",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Subtract rate depreciation\nExplanation: D: Subtract the rate of depreciation from RC"
    },
    {
      "id": "FCF55",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Straight line Plateau\nExplanation: A: Straight line / Plateau accelerated method"
    },
    {
      "id": "FCF56",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ appraiser",
      "back": "Ans: Licensed real estate\nExplanation: E: Licensed real estate appraiser"
    },
    {
      "id": "FCF57",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Market value before\nExplanation: A: Market value of before / after the loss"
    },
    {
      "id": "FCF58",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: run down buildings\nExplanation: E: run -down buildings = net annual rent with a capitalization rate applied to it"
    },
    {
      "id": "FCF59",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: insureds claim previous\nExplanation: D: The insureds claim the previous three methods have failed to consider their special circumstances"
    },
    {
      "id": "FCF60",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ four of the above approaches and considers:",
      "back": "Ans: Ties together all\nExplanation: D: Ties together all four of the above approaches and considers:"
    },
    {
      "id": "FCF61",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ in a fair market, allow for depreciation",
      "back": "Ans: Cash price value\nExplanation: B: Cash price value in a fair market, allow for depreciation"
    },
    {
      "id": "FCF62",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Insurance covers two\nExplanation: D: Insurance covers >two items / locations"
    },
    {
      "id": "FCF63",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ amounts for each item",
      "back": "Ans: No separate coverage\nExplanation: A: No separate coverage amounts for each item"
    },
    {
      "id": "FCF64",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Cash value replace\nExplanation: E: Cash value to replace"
    },
    {
      "id": "FCF65",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Property itemized\nExplanation: E: Property is itemized"
    },
    {
      "id": "FCF66",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Coverage limit each\nExplanation: A: Coverage limit for each item"
    },
    {
      "id": "FCF67",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Property every description\nExplanation: E: Property of every description"
    },
    {
      "id": "FCF68",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Method used insure\nExplanation: B: Method used to insure commercial building, equipment and stock under a single limit of insurance"
    },
    {
      "id": "FCF69",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Additions changes rented\nExplanation: C: Additions or changes to rented premises by a tenant at his/her own expense."
    },
    {
      "id": "FCF70",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ and manuscript policies",
      "back": "Ans: Difference between package\nExplanation: E: Difference between package and manuscript policies"
    },
    {
      "id": "FCF71",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Under form\nExplanation: E: Under 1 form"
    },
    {
      "id": "FCF72",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Variety coverages needed\nExplanation: A: Variety of coverages needed by offices and small mercantile operations"
    },
    {
      "id": "FCF73",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "For _____ a specialized exposure",
      "back": "Ans: risks that have\nExplanation: C: For risks that have a specialized exposure"
    },
    {
      "id": "FCF74",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ from exists",
      "back": "Ans: No standard coverage\nExplanation: E: No standard coverage from exists"
    },
    {
      "id": "FCF75",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "13. _____ and subscription",
      "back": "Ans: Difference between reinsurance\nExplanation: D: 13. Difference between reinsurance and subscription"
    },
    {
      "id": "FCF76",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ in premiums and losses",
      "back": "Ans: All insurers share\nExplanation: C: All insurers share in premiums and losses"
    },
    {
      "id": "FCF77",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Between primary insurer\nExplanation: B: Between the primary insurer and the reinsurer"
    },
    {
      "id": "FCF78",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Controlled by primary\nExplanation: C: Controlled by the primary insurer"
    },
    {
      "id": "FCF79",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ with the insured for a specific limit of liability",
      "back": "Ans: Each insurer contracts\nExplanation: C: Each insurer contracts with the insured for a specific limit of liability"
    },
    {
      "id": "FCF80",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Separate payments provided\nExplanation: A: Separate payments are provided from all companies to the clamant"
    },
    {
      "id": "FCF81",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Reinsurance contracts preferred\nExplanation: E: 14. Reinsurance contracts are preferred by most brokers?"
    },
    {
      "id": "FCF82",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Simpler deal insurer\nExplanation: A: Simpler to deal with an insurer protected by reinsurance"
    },
    {
      "id": "FCF83",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Amount insurance specified\nExplanation: D: Amount of insurance specified on the declarations page for the lost or damaged property"
    },
    {
      "id": "FCF84",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ either of 2% of the amount of insurance or $5,000",
      "back": "Ans: Not greater than\nExplanation: C: Not greater than either of 2% of the amount of insurance or $5,000"
    },
    {
      "id": "FCF85",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: requirements Stated Amount\nExplanation: C: 19. The requirements of the Stated Amount Co-insurance Clause?"
    },
    {
      "id": "FCF86",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 4: Additional Commercial Property Coverages",
      "front": "_____ have been developed: automobiles, money and securities",
      "back": "Ans: Specialized policy forms\nExplanation: E: Specialized policy forms have been developed: automobiles, money and securities"
    },
    {
      "id": "FCF87",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ as much insurance after a loss as they did before it",
      "back": "Ans: Insured shall have\nExplanation: A: Insured shall have as much insurance after a loss as they did before it"
    },
    {
      "id": "FCF88",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "26. _____ upon insureds by the Property Protection Systems clause",
      "back": "Ans: Three obligations placed\nExplanation: D: 26. Three obligations placed upon insureds by the Property Protection Systems clause"
    },
    {
      "id": "FCF89",
      "type": "flashcard",
      "source": "Notes docx",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Any interruption flaw\nExplanation: C: Any interruption to, or flaw or defect, coming to the knowledge of the insured in any such system"
    },
    {
      "id": "FCF90",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ Can Be Valued:",
      "back": "Ans: Three Ways Property\nExplanation: E: Three Ways Property Can Be Valued:"
    },
    {
      "id": "FCF91",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - cost of repair, replace or rebuild minus depreciation",
      "back": "Ans: 1. Actual Cash Value\nExplanation: E: 1. Actual Cash Value - cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": "FCF92",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: cost repair replace\nExplanation: B: cost of repair, replace or rebuild minus depreciation"
    },
    {
      "id": "FCF93",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____, without depreciation deduction.",
      "back": "Ans: same as above\nExplanation: C: same as above, without depreciation deduction."
    },
    {
      "id": "FCF94",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ minus depreciation and other write-offs. Not",
      "back": "Ans: original purchase price\nExplanation: B: original purchase price minus depreciation and other write-offs. Not"
    },
    {
      "id": "FCF95",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - determine the R/C of the property, then subtract rate of",
      "back": "Ans: 1. Formula/Cost Approach\nExplanation: D: 1. Formula/Cost Approach - determine the R/C of the property, then subtract rate of"
    },
    {
      "id": "FCF96",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: determine R/C property\nExplanation: B: determine the R/C of the property, then subtract rate of"
    },
    {
      "id": "FCF97",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: expert opinion licensed\nExplanation: A: expert opinion of licensed real estate appraiser"
    },
    {
      "id": "FCF98",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: income produced from\nExplanation: A: when income is produced from down buildings, net annual rent"
    },
    {
      "id": "FCF99",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ four of the above.",
      "back": "Ans: ties together all\nExplanation: B: ties together all four of the above."
    },
    {
      "id": "FCF100",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ in both premiums collected and losses incurred. The contract",
      "back": "Ans: all insurers share\nExplanation: D: all insurers share in both premiums collected and losses incurred. The contract"
    },
    {
      "id": "FCF101",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ with the insured for a specific limit of liability. If one",
      "back": "Ans: each insurer contracts\nExplanation: D: each insurer contracts with the insured for a specific limit of liability. If one"
    },
    {
      "id": "FCF102",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "the _____ a statement of values with the",
      "back": "Ans: insured must file\nExplanation: E: the insured must file a statement of values with the"
    },
    {
      "id": "FCF103",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - insureds will have as much insurance after a loss as they did",
      "back": "Ans: 1. Reinstatement Clause\nExplanation: E: 1. Reinstatement Clause - insureds will have as much insurance after a loss as they did"
    },
    {
      "id": "FCF104",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ as much insurance after a loss as they did",
      "back": "Ans: insureds will have\nExplanation: C: insureds will have as much insurance after a loss as they did"
    },
    {
      "id": "FCF105",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: insurer retains right\nExplanation: C: the insurer retains the right to step into the shoes of the insured and sue"
    },
    {
      "id": "FCF106",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: insured needs notify\nExplanation: D: insured needs to notify of any interruption to, or flaw or"
    },
    {
      "id": "FCF107",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Applicable stock\nExplanation: E: Applicable to stock"
    },
    {
      "id": "FCF108",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ for premium refund. Claim must be within 6 months.",
      "back": "Ans: Allows over-insured clause\nExplanation: B: Allows over-insured clause for premium refund. Claim must be within 6 months."
    },
    {
      "id": "FCF109",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: enter insured’s premises\nExplanation: C: enter the insured’s premises at all reasonable times to inspect."
    },
    {
      "id": "FCF110",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Defines basis valuation\nExplanation: E: Defines basis for valuation of losses for different CLASS of property"
    },
    {
      "id": "FCF111",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - selling price less the discounts",
      "back": "Ans: Sold Stock\nExplanation: A: Sold Stock - selling price less the discounts"
    },
    {
      "id": "FCF112",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ the discounts",
      "back": "Ans: selling price less\nExplanation: A: selling price less the discounts"
    },
    {
      "id": "FCF113",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: if repaired due\nExplanation: C: if repaired with due diligence and dispatch, the insured is entitled to claim all costs"
    },
    {
      "id": "FCF114",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ are blank value only + costs to copy from other source",
      "back": "Ans: Manually maintained records\nExplanation: E: Manually maintained records are blank value only + costs to copy from other source"
    },
    {
      "id": "FCF115",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - fair and reasonable price property would be on the market minus",
      "back": "Ans: Actual Cash Value\nExplanation: A: Actual Cash Value - fair and reasonable price property would be on the market minus"
    },
    {
      "id": "FCF116",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: fair reasonable price\nExplanation: E: fair and reasonable price property would be on the market minus"
    },
    {
      "id": "FCF117",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - policy of insurance that covers two or more items without listing",
      "back": "Ans: All property (blanket)\nExplanation: E: All property (blanket) - policy of insurance that covers two or more items without listing"
    },
    {
      "id": "FCF118",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: policy insurance that\nExplanation: C: policy of insurance that covers two or more items without listing"
    },
    {
      "id": "FCF119",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - when property is itemized with a limit each",
      "back": "Ans: Scheduled\nExplanation: A: Scheduled - when property is itemized with a limit each"
    },
    {
      "id": "FCF120",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: property itemized limit\nExplanation: E: when property is itemized with a limit each"
    },
    {
      "id": "FCF121",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: cash value cost\nExplanation: D: the cash value or cost to replace an item"
    },
    {
      "id": "FCF122",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - additions or charges rented property at the expense of the",
      "back": "Ans: Tenant’s improvements\nExplanation: D: Tenant’s improvements - additions or charges rented property at the expense of the"
    },
    {
      "id": "FCF123",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: additions charges rented\nExplanation: A: additions or charges rented property at the expense of the"
    },
    {
      "id": "FCF124",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: condition imposed do\nExplanation: A: a condition imposed to do or not do something"
    },
    {
      "id": "FCF125",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "a _____ facts are true and will remain so.",
      "back": "Ans: promise that certain\nExplanation: C: a promise that certain facts are true and will remain so."
    },
    {
      "id": "FCF126",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "a _____ knowing to be false",
      "back": "Ans: false statement made\nExplanation: C: a false statement made knowing to be false"
    },
    {
      "id": "FCF127",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "a _____ the insurer knew about, would affect the decision to insure",
      "back": "Ans: fact which if\nExplanation: E: a fact which if the insurer knew about, would affect the decision to insure"
    },
    {
      "id": "FCF128",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - step into the shoes of the party compensated and sue",
      "back": "Ans: Subrogation\nExplanation: E: Subrogation - step into the shoes of the party compensated and sue"
    },
    {
      "id": "FCF129",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: step into shoes\nExplanation: B: step into the shoes of the party compensated and sue"
    },
    {
      "id": "FCF130",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: group insurers participating\nExplanation: C: group of insurers participating in a policy"
    },
    {
      "id": "FCF131",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: lacks essential element\nExplanation: A: lacks an essential element to be enforceable by law"
    },
    {
      "id": "FCF132",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____, help determine cvgs needed",
      "back": "Ans: Identify coverages needed\nExplanation: B: Identify coverages needed, help determine cvgs needed"
    },
    {
      "id": "FCF133",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - alerts broker to possible loss exposures, ensures needed coverages are not",
      "back": "Ans: Checklist\nExplanation: B: Checklist - alerts broker to possible loss exposures, ensures needed coverages are not"
    },
    {
      "id": "FCF134",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: alerts broker possible\nExplanation: E: alerts broker to possible loss exposures, ensures needed coverages are not"
    },
    {
      "id": "FCF135",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ - fire-resistive, non combustible, heavy timber, ordinary,",
      "back": "Ans: Building materials best to worst\nExplanation: B: Building materials best to worst - fire-resistive, non combustible, heavy timber, ordinary,"
    },
    {
      "id": "FCF136",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Complete the missing wording: _____",
      "back": "Ans: fire-resistive non combustible\nExplanation: C: fire-resistive, non combustible, heavy timber, ordinary,"
    },
    {
      "id": "FCF137",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - check roof, wiring, breakers, plumbing, heating",
      "back": "Ans: For buildings over 25+ years\nExplanation: C: For buildings over 25+ years - check roof, wiring, breakers, plumbing, heating"
    },
    {
      "id": "FCF138",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: check roof wiring\nExplanation: E: check roof, wiring, breakers, plumbing, heating"
    },
    {
      "id": "FCF139",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Primary duty select\nExplanation: B: Primary duty is to select risks most profitable to the company. Improper screening can"
    },
    {
      "id": "FCF140",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ on categories on their probability for a loss.",
      "back": "Ans: Grouping risks based\nExplanation: B: Grouping risks based on categories on their probability for a loss."
    },
    {
      "id": "FCF141",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ - factors that influence the premium are application info, internal and",
      "back": "Ans: 3. Rate-Making\nExplanation: D: 3. Rate-Making - factors that influence the premium are application info, internal and"
    },
    {
      "id": "FCF142",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ the premium are application info, internal and",
      "back": "Ans: factors that influence\nExplanation: B: factors that influence the premium are application info, internal and"
    },
    {
      "id": "FCF143",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ - characterized by an increase in the loss ratio bought on by low rates in a",
      "back": "Ans: Hard Market\nExplanation: C: Hard Market - characterized by an increase in the loss ratio bought on by low rates in a"
    },
    {
      "id": "FCF144",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "Complete the missing wording: _____",
      "back": "Ans: characterized by increase\nExplanation: C: characterized by an increase in the loss ratio bought on by low rates in a"
    },
    {
      "id": "FCF145",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ insurers resulting in unusually low rates.",
      "back": "Ans: intense competition between\nExplanation: B: intense competition between insurers resulting in unusually low rates."
    },
    {
      "id": "FCF146",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: preparation original policy\nExplanation: E: preparation of original policy, changes requiring endorsements, billing"
    },
    {
      "id": "FCF147",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Chapter KEY TERMS\nExplanation: C: Chapter 2 KEY TERMS"
    },
    {
      "id": "FCF148",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ - certain hazards or conditions to all buildings that influence their",
      "back": "Ans: Common Hazards\nExplanation: B: Common Hazards - certain hazards or conditions to all buildings that influence their"
    },
    {
      "id": "FCF149",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: certain hazards conditions\nExplanation: B: certain hazards or conditions to all buildings that influence their"
    },
    {
      "id": "FCF150",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ - distance between insured property and other commercially rated",
      "back": "Ans: Detachment\nExplanation: B: Detachment - distance between insured property and other commercially rated"
    },
    {
      "id": "FCF151",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ property and other commercially rated",
      "back": "Ans: distance between insured\nExplanation: C: distance between insured property and other commercially rated"
    },
    {
      "id": "FCF152",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "_____ have met min standards hours",
      "back": "Ans: describes buildings that\nExplanation: E: describes buildings that have met min standards hours"
    },
    {
      "id": "FCF153",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ - will not ignite or burn when subjected to fire",
      "back": "Ans: Non combustible\nExplanation: A: Non combustible - will not ignite or burn when subjected to fire"
    },
    {
      "id": "FCF154",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 2: Underwriting",
      "front": "_____ or burn when subjected to fire",
      "back": "Ans: will not ignite\nExplanation: C: will not ignite or burn when subjected to fire"
    },
    {
      "id": "FCF155",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "_____ - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model",
      "back": "Ans: FIRE POLICY\nExplanation: A: FIRE POLICY - narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model"
    },
    {
      "id": "FCF156",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 3: Commercial Property Policy",
      "front": "_____ from the 1920s-40s. Rarely used now. Serves as a model",
      "back": "Ans: narrowly defined sold\nExplanation: A: narrowly defined sold from the 1920s-40s. Rarely used now. Serves as a model"
    },
    {
      "id": "FCF157",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Loss damage destruction\nExplanation: B: 1. Loss, damage, destruction of electrical devices. Except for directly caused by fire or"
    },
    {
      "id": "FCF158",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: considered control insured\nExplanation: C: considered in control of insured and are trade risks. Except if fire"
    },
    {
      "id": "FCF159",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: War Invasion act\nExplanation: E: 3. War, Invasion, act of foreign enemy"
    },
    {
      "id": "FCF160",
      "type": "flashcard",
      "source": "Study Sheet PDF",
      "chapter": "Chapter 1: Introduction",
      "front": "Complete the missing wording: _____",
      "back": "Ans: Nuclear Incident Except\nExplanation: E: 4. Nuclear Incident. Except for loss or damage directly results from named peril"
    }
  ]
};
